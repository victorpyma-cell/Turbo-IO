import Foundation

@main struct HyMTTranslationTests {
    @MainActor static func main() async throws {
        guard CommandLine.arguments.count == 3 else { fatalError("supply original and adapted model") }
        for code in ["en_US","en-US","EN_us"] { precondition(CaptionHyMTTranslation.languageName(code) == "English") }
        for code in ["zh_CN","zh-Hans-CN","cmn_CN"] { precondition(CaptionHyMTTranslation.languageName(code) == "Chinese") }
        for code in ["zh_TW","zh_Hant_HK","zh-Hant","cmn-Hant-TW"] { precondition(CaptionHyMTTranslation.languageName(code) == "Traditional Chinese") }
        for code in ["yue_HK","yue-Hant-HK","yue_CN","zh-yue-HK"] { precondition(CaptionHyMTTranslation.languageName(code) == "Cantonese") }
        precondition(CaptionHyMTTranslation.languageName("unknown_US") == nil)
        precondition(CaptionHyMTTranslation.displayText("请等待下一班火车。",target:"zh_Hant") == "請等待下一班火車。")
        precondition(CaptionHyMTTranslation.displayText("請等待下一班火車。",target:"zh_CN") == "请等待下一班火车。")
        precondition(CaptionHyMTTranslation.displayText("Hello 3.14",target:"en_US") == "Hello 3.14")
        let engine = CaptionHyMTTranslation()
        do {
            try await engine.load(url: URL(fileURLWithPath: CommandLine.arguments[1]))
            fatalError("original ID-42 model must be rejected by SHA gate")
        } catch HyMTFailure.invalidModel {}
        try await engine.load(url: URL(fileURLWithPath: CommandLine.arguments[2]),threads:2)
        precondition(engine.loaded)
        var partials: [String] = []
        let text = try await engine.translate("Please turn left at the next intersection.", source: "en_US", target: "zh_CN") { partials.append($0) }
        precondition(!text.isEmpty)
        precondition(!partials.isEmpty && partials.allSatisfy { text.hasPrefix($0) })
        precondition(engine.lastTiming!.firstTokenMS > 0)
        print("Swift translation: \(text)")
        do {
            _ = try await engine.translate("hello", source: "en", target: "unknown")
            fatalError("unsupported language must fail")
        } catch HyMTFailure.unsupportedLanguage {}
        let running = Task { try await engine.translate("Please stand behind the yellow line and wait for the next train.", source: "en", target: "zh") }
        try await Task.sleep(for: .milliseconds(20))
        do {
            _ = try await engine.translate("hello", source: "en", target: "zh")
            fatalError("busy must fail, not silently enqueue")
        } catch HyMTFailure.busy {}
        engine.cancel()
        do { _ = try await running.value; fatalError("cancelled work must not return text") }
        catch HyMTFailure.native(let status) { precondition(status == TIO_HY_CANCELLED) }
        catch is CancellationError {}
        let recovery = try await engine.translate("Thank you.", source: "en", target: "zh")
        precondition(!recovery.isEmpty)
        let cantonese = try await engine.translate("唔該，最近嘅地鐵站喺邊度？",source:"yue_Hant_HK",target:"en_US")
        precondition(!cantonese.isEmpty)
        print("Cantonese to English: \(cantonese)")
        var traditionalPartials: [String] = []
        let traditional = try await engine.translate("Please wait for the next train.",source:"en_US",target:"zh_Hant") { traditionalPartials.append($0) }
        precondition(!traditional.isEmpty)
        precondition(traditional.contains("請") && traditional.contains("車"))
        precondition(!traditional.contains("请") && !traditional.contains("车"))
        precondition(!traditionalPartials.isEmpty && traditionalPartials.allSatisfy { !$0.contains("请") && !$0.contains("车") })
        print("English to Traditional Chinese: \(traditional)")
        let sameLanguage = try await engine.translate("请等待下一班火车。",source:"zh_Hant",target:"zh_Hant")
        precondition(sameLanguage == "請等待下一班火車。")
        engine.unload()
        precondition(!engine.loaded)
        print("PASS Swift locale mapping, Cantonese/Traditional Chinese inference, SHA gate, worker bridge, busy, cancel, recovery, unload")
    }
}

#import "OfflineSpeech.h"
#import <dlfcn.h>
id TIOCreateOfflineSpeech(void) {
    NSAssert(NSThread.isMainThread,@"Speech belongs to the main queue");
    if(@available(iOS 26.0,*)){
        static void *handle;
        if(!handle)handle=dlopen([[NSBundle.mainBundle.privateFrameworksPath stringByAppendingPathComponent:@"TurboRealtime.dylib"] fileSystemRepresentation],RTLD_NOW|RTLD_LOCAL);
        Class cls=handle?NSClassFromString(@"TIOLocalNarrator"):Nil;
        if([cls respondsToSelector:@selector(make)])return [cls make];
    }
    return nil;
}

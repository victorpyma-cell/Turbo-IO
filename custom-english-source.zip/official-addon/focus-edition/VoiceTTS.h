#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *TIOVoiceTTSService(void);
FOUNDATION_EXPORT BOOL TIOVoiceTTSServiceURLValid(NSString *url);
FOUNDATION_EXPORT NSString *TIOVoiceTTSChunk(NSString *pending, BOOL final, NSUInteger *consumed);
FOUNDATION_EXPORT BOOL TIOVoiceTTSEcho(NSString *transcript, NSString *response);

@interface TIOVoiceTTS : NSObject
@property(nonatomic) BOOL localMode;
@property(nonatomic,readonly) BOOL isActive;
- (BOOL)isPlaybackEcho:(NSString *)text;
- (instancetype)initWithKeyProvider:(NSString *(^)(void))keyProvider;
- (void)beginTurn;
- (void)appendFullText:(NSString *)text finished:(BOOL)finished;
- (void)cancel;
- (NSString *)status;
+ (NSString *)audioRoute;
@end

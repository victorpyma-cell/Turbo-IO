#import <Foundation/Foundation.h>
@interface NSObject (TIOOfflineSpeechSelectors)
+ (id)make;
- (void)appendText:(NSString *)text finished:(BOOL)finished;
- (void)stop;
- (void)pause;
- (void)resume;
- (BOOL)isPaused;
- (BOOL)isActive;
- (NSString *)status;
@end
FOUNDATION_EXPORT id TIOCreateOfflineSpeech(void);

#import "VoiceTTS.h"
#include <assert.h>
int main(void){@autoreleasepool{
    assert(TIOVoiceTTSEcho(@"Ray Neo, your AI assistant",@"Hello. RayNeo, your AI assistant is ready."));
    assert(TIOVoiceTTSEcho(@"Nevermind",@"You can say nevermind to leave."));
    assert(!TIOVoiceTTSEcho(@"Stop reading now",@"Today's weather is sunny."));
    assert(!TIOVoiceTTSEcho(@"Hi",@"Hi, I am RayNeo."));
    assert(!TIOVoiceTTSEcho(@"Actual new question",@""));
    NSUInteger used=0;
    assert([TIOVoiceTTSChunk(@"Hello. This is your assistant.",NO,&used) isEqual:@"Hello."]&&used==6);
    assert(!TIOVoiceTTSChunk(@"An unfinished phrase",NO,&used)&&used==0);
    assert([TIOVoiceTTSChunk(@"An unfinished phrase",YES,&used) isEqual:@"An unfinished phrase"]);
    puts("PASS production playback echo filtering and sentence buffering");
}return 0;}

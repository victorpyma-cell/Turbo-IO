#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
root="$PWD/build/essentials/parakeet"
revision=eabcd9e36dab48f1f7180165396d84b9688650e0
mkdir -p "$root"
if [[ ! -d "$root/FluidAudio/.git" ]]; then
  git clone https://github.com/FluidInference/FluidAudio.git "$root/FluidAudio"
  git -C "$root/FluidAudio" checkout --detach "$revision"
fi
[[ $(git -C "$root/FluidAudio" rev-parse HEAD) == "$revision" ]]
git -C "$root/FluidAudio" diff --exit-code
git -C "$root/FluidAudio" diff --cached --exit-code
xcrun swift build --package-path "$root/FluidAudio" --scratch-path "$root/build" \
  --configuration release --build-system swiftbuild --triple arm64-apple-ios26.0 \
  --sdk "$(xcrun --sdk iphoneos --show-sdk-path)" --disable-default-traits --product FluidAudio
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('build/essentials/parakeet')
matches=list((root/'build').rglob('Release-iphoneos/FluidAudio.o'))
assert len(matches)==1, 'Unexpected FluidAudio build products'
products=matches[0].parent
(root/'products-path.txt').write_text(str(products.resolve()))
shutil.copytree(products/'FluidAudio_FluidAudio.bundle',Path('build/essentials/resources/FluidAudio_FluidAudio.bundle'),dirs_exist_ok=True)
PY

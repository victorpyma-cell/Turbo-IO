#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <assert.h>
static NSUserDefaults *Prefs;
static NSUInteger APICalls, AccountCalls, Cancels;
static NSString *ReceivedQuestion;
static NSArray *ReceivedHistory;
static void (^AccountUpdate)(NSString *,BOOL,NSString *);
@interface FakeAccountRequest : NSObject
- (void)cancel;
@end
@implementation FakeAccountRequest
- (void)cancel { Cancels++; }
@end
static id TIOStartChatGPTAnswer(NSString *question,NSArray *history,void (^update)(NSString *,BOOL,NSString *)) {
    AccountCalls++;ReceivedQuestion=question;ReceivedHistory=history;AccountUpdate=[update copy];return [FakeAccountRequest new];
}
static NSURL *TIOValidateEndpoint(NSString *text){return [NSURL URLWithString:text];}
static NSString *ReadKey(NSString *host){return @"fixture-key";}
static NSDictionary *TIOChatRequestWithHistory(NSString *model,NSString *question,NSArray *history){return @{};}
static void TIOImportKnowledgeConnection(void) {}
static BOOL TIOKnowledgeEnabled(void) { return NO; }
@interface TIOKnowledgeClient : NSObject
- (void)cancel;
- (void)refreshLast:(void(^)(NSDictionary *,NSString *))done;
- (void)query:(NSDictionary *)input completion:(void(^)(NSDictionary *,NSString *))done;
@end
@implementation TIOKnowledgeClient
- (void)cancel {}
- (void)refreshLast:(void(^)(NSDictionary *,NSString *))done { done(@{},nil); }
- (void)query:(NSDictionary *)input completion:(void(^)(NSDictionary *,NSString *))done { done(@{},nil); }
@end
@interface TIOWebChatRequest : NSObject
@property(nonatomic,copy) void (^update)(NSString *,BOOL,NSString *);
@property(nonatomic) BOOL finished,newsMode;
@property(nonatomic,copy) void (^cancelKnowledge)(void);
@property(nonatomic,copy) void (^knowledgeQuery)(NSDictionary *,BOOL,void(^)(NSDictionary *));
- (void)cancel;
- (void)startEndpoint:(NSURL *)url key:(NSString *)key payload:(NSDictionary *)payload searchKey:(NSString *)searchKey;
@end
@implementation TIOWebChatRequest
- (void)cancel { self.finished=YES;self.update=nil; }
- (void)startEndpoint:(NSURL *)url key:(NSString *)key payload:(NSDictionary *)payload searchKey:(NSString *)searchKey { if(self.finished)return;APICalls++;if(self.update)self.update(@"custom reply",YES,nil); }
@end
// Generated from the actual Addon.m class, so callback/cancellation tests cover production code.
#include "TIORequest-under-test.inc"
int main(void){@autoreleasepool{
    Prefs=[[NSUserDefaults alloc]initWithSuiteName:@"TurboIO.fixture.tests"];
    [Prefs setInteger:3 forKey:@"mode"];
    TIORequest *request=[TIORequest new];request.history=@[@{@"role":@"user",@"content":@"Previous question"}];
    __block NSUInteger replies=0;request.update=^(NSString *text,BOOL done,NSString *error){assert(!error);replies++;};
    [request startQuestion:@"Current question"];
    assert(AccountCalls==1&&APICalls==0&&[ReceivedQuestion isEqual:@"Current question"]&&ReceivedHistory.count==1);
    AccountUpdate(@"partial",NO,nil);AccountUpdate(@"full reply",YES,nil);assert(replies==2);
    [request cancel];assert(Cancels==1);AccountUpdate(@"stale",YES,nil);assert(replies==2);
    [Prefs setInteger:2 forKey:@"mode"];[Prefs setObject:@"https://fixture.example/v1/chat/completions" forKey:@"endpoint"];[Prefs setObject:@"fixture-model" forKey:@"model"];
    request=[TIORequest new]; // Both providers create a fresh one-shot request per turn.
    request.update=^(NSString *text,BOOL done,NSString *error){assert([text isEqual:@"custom reply"]&&done&&!error);replies++;};
    [request startQuestion:@"API question"];assert(APICalls==1&&AccountCalls==1&&replies==3);
    [Prefs removePersistentDomainForName:@"TurboIO.fixture.tests"];
    puts("PASS: production request routes ChatGPT/custom API, retains callbacks/history, cancels and suppresses stale replies");
}return 0;}

import Foundation
@preconcurrency import AVFAudio
@preconcurrency import WhisperKit

actor WhisperWorker {
    private var pipeline: WhisperKit?
    func load(allowDownload:Bool) async throws {
        let saved=UserDefaults.standard.string(forKey:"NovaWhisperModelFolder")
        if let saved,FileManager.default.fileExists(atPath:saved) {
            pipeline=try await WhisperKit(modelFolder:saved,verbose:false,load:true,download:false)
        } else {
            guard allowDownload else { throw RealtimeError("Tap Prepare speech language to download the on-device Whisper base model first.") }
            let folder=try await WhisperKit.download(variant:"openai_whisper-base")
            let loaded=try await WhisperKit(modelFolder:folder.path,verbose:false,load:true,download:false)
            pipeline=loaded;UserDefaults.standard.set(folder.path,forKey:"NovaWhisperModelFolder")
        }
    }
    func transcribe(_ audio:[Float],language:String) async throws -> String {
        guard let pipeline else { throw RealtimeError("Whisper is not prepared.") }
        try Task.checkCancellation()
        var options=DecodingOptions(language:language)
        options.temperatureFallbackCount=0;options.sampleLength=128;options.concurrentWorkerCount=1
        let result=try await pipeline.transcribe(audioArray:audio,decodeOptions:options)
        try Task.checkCancellation()
        return result.map(\.text).joined(separator:" ").trimmingCharacters(in:.whitespacesAndNewlines)
    }
}

@MainActor final class CaptionWhisperSpeech {
    var onText:((TranscriptPiece)->Void)?
    var onFailure:((String)->Void)?
    private var worker:WhisperWorker?,task:Task<Void,Never>?,pending=[Float]()
    private var generation=0,language="en",duration=0.0,start=0.0,silence=0.0
    static var languages:[Locale] { Constants.languageCodes.filter{$0 != "yue"}.sorted().map{Locale(identifier:$0)} }
    func prepare(language:String,download:Bool) async throws {
        let worker=WhisperWorker()
        try await worker.load(allowDownload:download);try Task.checkCancellation()
        self.worker=worker;self.language=String(SpeechLocalePolicy.key(language).split(separator:"-").first ?? "en")
    }
    func offer(_ buffer:AVAudioPCMBuffer) {
        guard let samples=buffer.floatChannelData?[0] else { return }
        let audio=Array(UnsafeBufferPointer(start:samples,count:Int(buffer.frameLength)))
        pending.append(contentsOf:audio);duration+=Double(audio.count)/16000
        let energy=audio.reduce(Float(0)){$0+$1*$1}/Float(max(1,audio.count))
        silence=energy<0.00004 ? silence+Double(audio.count)/16000 : 0
        guard pending.count<=16000*16 else { stop();onFailure?("On-device Whisper fell behind. Choose Parakeet or Apple recognition.");return }
        drain()
    }
    private func drain() {
        guard task==nil,let worker,pending.count>=16000,(silence>=0.35||pending.count>=16000*6) else { return }
        let count=min(pending.count,16000*8),audio=Array(pending.prefix(count));pending.removeFirst(count)
        let begin=start,end=start+Double(count)/16000,epoch=generation;start=end;silence=0
        // Ignore silence rather than inventing a transcript for an empty chunk.
        guard audio.contains(where:{abs($0)>0.01}) else { return }
        task=Task { [weak self] in
            do {
                let text=try await worker.transcribe(audio,language:language)
                guard let self,self.generation==epoch,!Task.isCancelled else { return }
                if !text.isEmpty { self.onText?(TranscriptPiece(start:begin,end:end,text:text,final:true)) }
                self.task=nil;self.drain()
            } catch {
                guard let self,self.generation==epoch,!Task.isCancelled else { return }
                self.stop();self.onFailure?(error.localizedDescription)
            }
        }
    }
    func stop() { generation+=1;task?.cancel();task=nil;worker=nil;pending.removeAll();duration=0;start=0;silence=0 }
}

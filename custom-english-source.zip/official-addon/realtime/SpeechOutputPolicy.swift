import Foundation
import NaturalLanguage

enum SpeechOutputPolicy {
    static let voices = ["af_heart", "af_bella", "am_adam", "am_michael"]
    static func language(_ text: String, override: String = "auto", fallback: String = "en-US",conversation:String? = nil) -> String {
        if override != "auto" && !override.isEmpty { return override }
        if ConversationLanguagePolicy.cantonese(text) || (conversation == "zh-HK" && ConversationLanguagePolicy.hasHan(text)) { return "zh-HK" }
        let recognizer = NLLanguageRecognizer()
        recognizer.processString(text)
        let hypotheses = recognizer.languageHypotheses(withMaximum: 2)
        if let best = hypotheses.max(by: { $0.value < $1.value }), best.value >= 0.55 {
            switch best.key.rawValue {
            case "en": return "en-US"
            case "zh-Hans": return "zh-CN"
            case "zh-Hant": return "zh-TW"
            case "ja": return "ja-JP"
            case "ko": return "ko-KR"
            default: return best.key.rawValue
            }
        }
        // Short fragments, numbers and names inherit the surrounding response.
        return fallback
    }
    static func kokoro(language: String, engine: String, text: String) -> Bool {
        guard engine != "apple", language.hasPrefix("en") else { return false }
        // Never send Han/Kana/Hangul in a mixed-language sentence to English G2P.
        return !text.unicodeScalars.contains { scalar in
            let n = scalar.value
            return (0x3400...0x9FFF).contains(n) || (0x3040...0x30FF).contains(n) || (0xAC00...0xD7AF).contains(n)
        }
    }
    static func smoothEnough(generationSeconds:Double, audioSeconds:Double, engine:String) -> Bool {
        guard generationSeconds.isFinite, audioSeconds.isFinite, audioSeconds > 0 else { return false }
        return engine == "kokoro" || (generationSeconds <= 2 && generationSeconds <= audioSeconds * 0.65)
    }
    static func voice(_ value: String?) -> String { voices.contains(value ?? "") ? value! : "af_heart" }
    static func matchesVoice(_ voiceLanguage:String, outputLanguage:String) -> Bool {
        let voice=voiceLanguage.lowercased().replacingOccurrences(of:"_",with:"-")
        let output=outputLanguage.lowercased().replacingOccurrences(of:"_",with:"-")
        let cantonese=output == "zh-hk" || output.hasPrefix("yue")
        let cantoneseVoice=voice == "zh-hk" || voice.hasPrefix("yue")
        if cantonese || cantoneseVoice { return cantonese && cantoneseVoice }
        return voice.split(separator:"-").first == output.split(separator:"-").first
    }
    static func speed(_ value: Double) -> Float { Float(value.isFinite && value > 0 ? min(1.5, max(0.75,value)) : 1.1) }
    static func chunks(_ text: String,maxCharacters:Int=240) -> [String] {
        let bounded = String(text.prefix(12000))
        let chunkLimit=min(240,max(20,maxCharacters))
        let tokenizer = NLTokenizer(unit: .sentence)
        tokenizer.string = bounded
        var result: [String] = []
        tokenizer.enumerateTokens(in: bounded.startIndex..<bounded.endIndex) { range, _ in
            var remaining = String(bounded[range]).trimmingCharacters(in: .whitespacesAndNewlines)
            while !remaining.isEmpty {
                let end = remaining.index(remaining.startIndex, offsetBy: min(chunkLimit,remaining.count))
                var cut = end
                if end != remaining.endIndex, let space = remaining[..<end].lastIndex(where: { $0.isWhitespace }) {
                    if remaining.distance(from: remaining.startIndex,to: space) > chunkLimit/3 { cut = space }
                }
                let part = String(remaining[..<cut]).trimmingCharacters(in: .whitespacesAndNewlines)
                if !part.isEmpty { result.append(part) }
                remaining = String(remaining[cut...]).trimmingCharacters(in: .whitespacesAndNewlines)
            }
            return true
        }
        return result
    }
}

import Foundation
import SwiftUI
import UIKit

@available(iOS 26.0, *)
@MainActor final class MeetingCopilot: ObservableObject {
    @Published var speechEngine = SpeechEngine.apple
    @Published var language = "en-US"
    @Published var languages: [String] = []
    @Published var provider = UserDefaults.standard.integer(forKey:"TurboMeeting.provider") == 3 ? 3 : 2 {
        didSet { UserDefaults.standard.set(provider,forKey:"TurboMeeting.provider") }
    }
    @Published var showOnGlasses = true
    @Published private(set) var running = false
    @Published private(set) var busy = false
    @Published private(set) var requesting = false
    @Published private(set) var status = "Ready"
    @Published private(set) var transcript = MeetingTranscript()
    @Published private(set) var suggestion = ""
    @Published private(set) var review = ""
    private let speech = LocalSpeech()
    private let id = UUID()
    private var generation = 0
    private var requestGeneration = 0
    private var startTask: Task<Void,Never>?
    private var stopTask: Task<Void,Never>?
    private var answerTask: Task<Void,Never>?
    private var expiry: Task<Void,Never>?
    private var hudExpiry: Task<Void,Never>?
    private var observers: [NSObjectProtocol] = []
    var active: Bool { running || busy }
    var canRequest: Bool { !busy && !requesting && !transcript.segments.isEmpty }
    func loadLanguages() async {
        languages = SpeechLocalePolicy.unique(await LocalSpeech.languages(engine:speechEngine).map(\.identifier))
        if !languages.contains(language), let first = languages.first(where:{$0.hasPrefix("en")}) ?? languages.first { language = first }
    }
    func prepareSpeech() async {
        guard !active, !requesting else { return }
        busy = true; status = "Preparing speech model…"
        defer { busy = false }
        do { try await speech.prepareLanguage(language,engine:speechEngine); status = "Speech model ready" }
        catch { status = error.localizedDescription }
    }
    func start() {
        guard !active, !requesting else { return }
        guard !TIORealtimeHost.live.running, !TIORealtimeHost.live.busy,
              !TIORealtimeHost.navigation.running, !TIORealtimeHost.navigation.acquiring else {
            status = "Stop Live Cue, captions, translation or navigation before starting Meeting Copilot."; return
        }
        generation += 1; let epoch = generation
        busy = true; status = "Starting meeting…"
        startTask = Task {
            do {
                try CueService.validateProvider(configuration(),purpose:.meeting)
                try GlassesDisplay.shared.acquire(id,enabled:showOnGlasses) { [weak self] message in self?.stop(message) }
                // A new recording clears the preceding meeting only after setup succeeds.
                speech.onText = { [weak self] piece in
                    guard let self, self.generation == epoch, self.running else { return }
                    self.transcript.ingest(piece)
                }
                speech.onFailure = { [weak self] message in self?.stop(message) }
                try await speech.start(language:language,engine:speechEngine)
                try Task.checkCancellation()
                guard generation == epoch else { return }
                transcript = MeetingTranscript(); suggestion = ""; review = ""
                running = true
                busy = false; status = "Listening · \(speech.inputName) · speakers unassigned"
                // Conservative lifecycle: no promise of unattended locked-phone capture.
                observers.append(NotificationCenter.default.addObserver(forName:UIApplication.didEnterBackgroundNotification,object:nil,queue:.main) { [weak self] _ in
                    Task { @MainActor in self?.stop("Paused when app entered background. Transcript retained.") }
                })
                UIApplication.shared.isIdleTimerDisabled = true
                expiry = Task { [weak self] in
                    try? await Task.sleep(nanoseconds:1_200_000_000_000)
                    guard !Task.isCancelled, let self, self.generation == epoch else { return }
                    self.stop("20-minute segment ended. Review or start a new segment.")
                }
            } catch { if generation == epoch { stop(error is CancellationError ? "Stopped" : error.localizedDescription) } }
        }
    }
    func stop(_ message: String = "Stopped · transcript retained") {
        guard active || requesting else { return }
        generation += 1; let epoch = generation
        running = false; busy = true; status = message
        startTask?.cancel(); startTask = nil; cancelRequest()
        expiry?.cancel(); expiry = nil; hudExpiry?.cancel(); hudExpiry = nil
        observers.forEach { NotificationCenter.default.removeObserver($0) }; observers.removeAll()
        GlassesDisplay.shared.release(id); UIApplication.shared.isIdleTimerDisabled = false
        stopTask = Task { await speech.stop(); if generation == epoch { busy = false; stopTask = nil } }
    }
    func cancelRequest() {
        requestGeneration += 1; answerTask?.cancel(); answerTask = nil; requesting = false
    }
    func configuration() -> [String:Any] {
        var configuration = TIORealtimeHost.call("provider")
        configuration["meetingMode"] = provider
        return AssistantPurpose.meeting.provider(configuration)
    }
    func request(_ kind: MeetingRequest) {
        guard canRequest else { return }
        if kind == .review && running { status = "Stop listening before reviewing the meeting."; return }
        let context = transcript.context() // Immutable snapshot; partial speech is not sent.
        guard !context.isEmpty else { return }
        cancelRequest(); let epoch = requestGeneration
        requesting = true; status = kind == .review ? "Reviewing retained transcript…" : "Finding a useful follow-up question…"
        hudExpiry?.cancel(); hudExpiry = nil
        if kind == .suggestion { suggestion = ""; GlassesDisplay.shared.update("",owner:id) }
        let selected = configuration()
        answerTask = Task {
            defer { if requestGeneration == epoch { requesting = false; answerTask = nil } }
            do {
                // Show only a complete result; partial output may later fail or change.
                let answer = try await CueService().respond(instructions:kind.instructions,prompt:"Retained transcript (speaker identities unknown):\n\(context)",maxTokens:kind == .review ? 1200 : 160,purpose:.meeting,configured:selected) { _ in }
                guard !Task.isCancelled, requestGeneration == epoch else { return }
                if kind == .review { review = answer; status = "Review ready · latest transcript excerpt only · verify before use" }
                else {
                    suggestion = String(answer.prefix(350)); status = answer.isEmpty ? "Not enough context for a useful suggestion" : "Suggested question · tap again when you need another"
                    if running && showOnGlasses {
                        GlassesDisplay.shared.update(suggestion,owner:id)
                        hudExpiry = Task { [weak self] in
                            try? await Task.sleep(nanoseconds:20_000_000_000)
                            guard !Task.isCancelled, let self, self.requestGeneration == epoch else { return }
                            GlassesDisplay.shared.update("",owner:self.id)
                        }
                    }
                }
            } catch { if requestGeneration == epoch && !Task.isCancelled { status = error.localizedDescription } }
        }
    }
    func clear() {
        guard !active, !requesting else { return }
        transcript = MeetingTranscript(); suggestion = ""; review = ""; status = "Meeting cleared"
    }
    var export: String {
        "# Meeting Copilot\n\nSpeakers unassigned. \(transcript.trimmed ? "Earlier transcript was trimmed; this is a retained portion." : "Only finalized speech from this session is included.") AI review uses only the latest excerpt, up to 12,000 characters; it may not cover all the transcript below.\n\n## AI review — verify before use\n\n\(review.isEmpty ? "No review generated." : review)\n\n## Transcript\n\n\(transcript.text)"
    }
}

@available(iOS 26.0, *)
struct MeetingCopilotPanel: View {
    @ObservedObject var meeting: MeetingCopilot
    @State private var confirmStart = false
    @State private var confirmClear = false
    var body: some View {
        Form {
            Section("Meeting setup") {
                Picker("Speech engine",selection:$meeting.speechEngine) { ForEach(SpeechEngine.allCases,id:\.self) { Text($0.rawValue).tag($0) } }.disabled(meeting.active || meeting.requesting)
                Picker("Spoken language",selection:$meeting.language) {
                    ForEach(meeting.languages,id:\.self) { Text(SpeechLocalePolicy.label($0)).tag($0) }
                    if !meeting.languages.contains(meeting.language) { Text(meeting.language).tag(meeting.language) }
                }.disabled(meeting.active || meeting.requesting)
                Picker("Copilot model",selection:$meeting.provider) { Text("Strata / Custom API").tag(2); Text("ChatGPT account").tag(3) }.disabled(meeting.active || meeting.requesting)
                Toggle("Show suggestions on glasses",isOn:$meeting.showOnGlasses).disabled(meeting.active || meeting.requesting)
                if !meeting.running { Button("Prepare speech model") { Task { await meeting.prepareSpeech() } }.disabled(meeting.active || meeting.requesting) }
            } footer: { Text("Uses the iPhone microphone. Keep this screen open and place the phone near the conversation. Configure the selected model under Models & Voice. Speaker identity is not verified; no one is labeled Me.") }
            if meeting.speechEngine == .whisper { Section { NavigationLink("Private faster-whisper connection") { WhisperSettings() } } }
            Section("Session") {
                Text(meeting.status)
                if meeting.running { Button("Stop listening",role:.destructive) { meeting.stop() } }
                else { Button("Start new meeting") { confirmStart = true }.disabled(meeting.active || meeting.requesting || meeting.languages.isEmpty) }
                Button("Suggest a question") { meeting.request(.suggestion) }.disabled(!meeting.canRequest)
                Button("Review meeting") { meeting.request(.review) }.disabled(!meeting.canRequest || meeting.running)
                if meeting.requesting { Button("Cancel model request") { meeting.cancelRequest() } }
            } footer: { Text("Transcription stays on this device with Apple, Parakeet or iPhone Whisper. Asking for a suggestion or review sends up to 12,000 characters of finalized transcript to your selected model. Private PC recognition also sends audio to your configured PC. Suggestions are optional; no tasks are created automatically.") }
            if !meeting.suggestion.isEmpty { Section("Suggested question") { Text(meeting.suggestion).textSelection(.enabled) } }
            if !meeting.review.isEmpty { Section("Meeting review · verify before use") { Text(meeting.review).textSelection(.enabled) } }
            Section("Transcript · speakers unassigned") {
                if meeting.transcript.trimmed { Text("Earlier speech was trimmed. Review and export cover only the retained portion.").foregroundStyle(.secondary) }
                Text(meeting.transcript.text.isEmpty ? "No finalized speech yet" : meeting.transcript.text).textSelection(.enabled)
                if !meeting.transcript.partial.isEmpty { Text(meeting.transcript.partial).foregroundStyle(.secondary) }
            }
            Section {
                ShareLink("Export transcript and review",item:meeting.export).disabled(meeting.transcript.segments.isEmpty || meeting.active || meeting.requesting)
                Button("Clear meeting",role:.destructive) { confirmClear = true }.disabled(meeting.active || meeting.requesting)
            } footer: { Text("Kept in memory until cleared or the app closes. Export a copy to retain it. Recording ends when you leave this screen or the app enters the background.") }
        }
        .navigationTitle("Meeting Copilot")
        .task(id:meeting.speechEngine) { await meeting.loadLanguages() }
        .onDisappear { meeting.stop() }
        .alert("Start a new meeting?",isPresented:$confirmStart) {
            Button("Cancel",role:.cancel) {}
            Button("Start") { meeting.start() }
        } message: { Text("Start when participants agree to recording. This clears the previous meeting held in memory and starts the iPhone microphone. End Lifelog and other glasses features first.") }
        .alert("Clear this meeting?",isPresented:$confirmClear) {
            Button("Cancel",role:.cancel) {}
            Button("Clear",role:.destructive) { meeting.clear() }
        } message: { Text("Removes the transcript and AI results from this module. Export first if you want to retain them.") }
    }
}

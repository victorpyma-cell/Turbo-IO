#!/bin/bash
set -euo pipefail
# Run from official-addon. This is the existing pinned CPU engine, without the
# separate English-only Parakeet stack; speech keeps the language picker.
deps="$PWD/build/essentials/hymt"
mkdir -p "$deps"
if [ ! -d "$deps/llama/.git" ]; then
  git init "$deps/llama"
  git -C "$deps/llama" remote add origin https://github.com/sjl623/llama.cpp.git
  git -C "$deps/llama" fetch --depth=1 origin 1e411d8f5a1e23525fa3265dfb4bd76265465397
  git -C "$deps/llama" checkout --detach FETCH_HEAD
fi
test "$(git -C "$deps/llama" rev-parse HEAD)" = 1e411d8f5a1e23525fa3265dfb4bd76265465397
cmake -S local-translation/src -B "$deps/ios" -DHYMT_LLAMA_SOURCE="$deps/llama" \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT=iphoneos \
  -DCMAKE_OSX_ARCHITECTURES=arm64 -DCMAKE_OSX_DEPLOYMENT_TARGET=26.0
cmake --build "$deps/ios" --target TurboHyMT -j 4

# Real inference on synthetic text, not a mocked translator. Nothing personal is uploaded.
if [ ! -f "$deps/Hy-MT2-original.gguf" ]; then
  curl --fail --location --retry 2 --output "$deps/Hy-MT2-original.download" \
    https://huggingface.co/tencent/Hy-MT2-1.8B-1.25Bit-GGUF/resolve/9df5c824a00a744fb0512a29c640466f4d97dfb0/Hy-MT2-1.8B-1.25Bit.gguf
  mv "$deps/Hy-MT2-original.download" "$deps/Hy-MT2-original.gguf"
fi
python3 local-translation/src/prepare_hymt_model.py "$deps/Hy-MT2-original.gguf" "$deps/Hy-MT2-1.8B-STQ43.gguf"
cmake -S local-translation/src -B "$deps/mac" -DHYMT_LLAMA_SOURCE="$deps/llama" -DCMAKE_BUILD_TYPE=Release
cmake --build "$deps/mac" --target hymt-tests -j 4

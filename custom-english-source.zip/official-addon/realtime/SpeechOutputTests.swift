import Foundation
@main struct SpeechOutputTests {
    static func main() {
        precondition(SpeechOutputPolicy.language("The weather is sunny today. We can walk to the park.") == "en-US")
        precondition(SpeechOutputPolicy.language("今天天气很好，我们可以去公园散步。") == "zh-CN")
        precondition(SpeechOutputPolicy.language("今日は天気が良いです。公園に行きましょう。") == "ja-JP")
        precondition(SpeechOutputPolicy.language("123",fallback:"zh-CN") == "zh-CN")
        precondition(SpeechOutputPolicy.language("Hello",override:"zh-HK") == "zh-HK")
        precondition(!SpeechOutputPolicy.kokoro(language:"en-US",engine:"auto",text:"Visit 北京 today."))
        precondition(!SpeechOutputPolicy.kokoro(language:"fr",engine:"auto",text:"Bonjour"))
        precondition(!SpeechOutputPolicy.kokoro(language:"en-US",engine:"apple",text:"Hello"))
        precondition(SpeechOutputPolicy.kokoro(language:"en-US",engine:"auto",text:"Hello."))
        precondition(SpeechOutputPolicy.voice("unknown") == "af_heart")
        precondition(SpeechOutputPolicy.matchesVoice("zh-HK",outputLanguage:"zh-HK"))
        precondition(!SpeechOutputPolicy.matchesVoice("zh-CN",outputLanguage:"zh-HK"))
        precondition(!SpeechOutputPolicy.matchesVoice("zh-HK",outputLanguage:"zh-CN"))
        precondition(SpeechOutputPolicy.matchesVoice("en-GB",outputLanguage:"en-US"))
        precondition(SpeechOutputPolicy.speed(.nan) == 1.1)
        precondition(SpeechOutputPolicy.chunks(String(repeating:"longword ",count:300)).allSatisfy { $0.count <= 240 })
        print("PASS automatic speech language, multilingual routing, voice validation, speed and bounded chunks")
    }
}

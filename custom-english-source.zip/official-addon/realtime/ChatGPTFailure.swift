import Foundation

// Keep the server's diagnosis. HTTP 400 is not evidence of an exhausted plan.
// Only bounded error fields are surfaced; never retain request bodies or tokens.
struct ChatGPTFailure: Error {
    let status: Int?
    let code: String?
    let parameter: String?
    let detail: String?
    let requestID: String?

    static func clean(_ value: Any?, secret: String? = nil, limit: Int = 600) -> String? {
        guard var text = value as? String else { return nil }
        if let secret, !secret.isEmpty { text = text.replacingOccurrences(of: secret, with: "[redacted]") }
        for pattern in [#"(?i)Bearer\s+\S+"#, #"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"#, #"\bsk-[A-Za-z0-9_-]+\b"#] {
            text = text.replacingOccurrences(of: pattern, with: "[redacted]", options: .regularExpression)
        }
        text = text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.joined(separator: " ")
        return text.isEmpty ? nil : String(text.prefix(limit))
    }

    static func http(status: Int, data: Data, requestID: String?, bearer: String) -> Self {
        let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        return parse(status: status, object: object, requestID: requestID, secret: bearer)
    }

    static func parse(status: Int?, object: [String: Any], requestID: String? = nil, secret: String? = nil) -> Self {
        let response = object["response"] as? [String: Any] ?? [:]
        let error = object["error"] as? [String: Any] ?? response["error"] as? [String: Any] ?? [:]
        let incomplete = response["incomplete_details"] as? [String: Any] ?? [:]
        return Self(status: status,
                    code: clean(error["code"] ?? object["code"] ?? incomplete["reason"], secret: secret, limit: 160),
                    parameter: clean(error["param"] ?? object["param"], secret: secret, limit: 160),
                    detail: clean(error["message"] ?? object["detail"] ?? object["message"], secret: secret),
                    requestID: clean(requestID ?? object["request_id"] as? String, secret: secret, limit: 160))
    }

    var message: String {
        var lines: [String] = []
        switch code {
        case "subscription_sharing_usage_limit_exceeded":
            lines.append("ChatGPT plan usage reached a limit. Check ChatGPT Settings > Usage; an app-specific limit may apply.")
        case "subscription_sharing_user_not_eligible":
            lines.append("ChatGPT plan usage is unavailable for this account or workspace.")
        case "subscription_sharing_unsupported_capability":
            lines.append("ChatGPT rejected an unsupported request option. This request needs an app fix.")
        default:
            if let status {
                switch status {
                case 400: lines.append("ChatGPT rejected the request (HTTP 400).")
                case 401: lines.append("ChatGPT could not authorize this request (HTTP 401).")
                case 403: lines.append("ChatGPT access was denied (HTTP 403).")
                case 429: lines.append("ChatGPT returned a rate or usage limit (HTTP 429).")
                case 500...599: lines.append("ChatGPT is temporarily unavailable (HTTP \(status)).")
                default: lines.append("ChatGPT returned HTTP \(status).")
                }
            } else { lines.append("ChatGPT did not complete this answer.") }
        }
        if let status, !lines[0].contains("HTTP") { lines.append("HTTP \(status)") }
        if let detail { lines.append(detail) }
        if let code { lines.append("Code: \(code)") }
        if let parameter { lines.append("Field: \(parameter)") }
        if let requestID { lines.append("Request: \(requestID)") }
        return lines.joined(separator: "\n")
    }
}

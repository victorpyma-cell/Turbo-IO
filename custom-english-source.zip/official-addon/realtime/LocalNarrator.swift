import Foundation
import UIKit
import AVFoundation
import KokoroCoreML

private actor KokoroWorker {
    static let shared = KokoroWorker()
    private var engine: KokoroEngine?
    func audio(_ text: String, voice: String, speed: Float) throws -> Data {
        try Task.checkCancellation()
        if engine == nil {
            guard let directory = Bundle.main.url(forResource: "TurboKokoroModels",withExtension: "bundle") else {
                throw NSError(domain:"TurboSpeech",code:1,userInfo:[NSLocalizedDescriptionKey:"Bundled Kokoro model missing"])
            }
            // CPU-only avoids GPU work after iOS locks/backgrounds the app.
            engine = try KokoroEngine(modelDirectory: directory,forceCPU: true)
        }
        let result = try engine!.synthesize(text:text,voice:voice,speed:speed)
        try Task.checkCancellation()
        guard !result.samples.isEmpty, result.samples.count <= 24_000 * 90,
              result.samples.allSatisfy({ $0.isFinite }) else {
            throw NSError(domain:"TurboSpeech",code:2,userInfo:[NSLocalizedDescriptionKey:"Invalid generated audio"])
        }
        var bytes = Data()
        func u16(_ value: UInt16) { var n=value.littleEndian; withUnsafeBytes(of:&n) { bytes.append(contentsOf:$0) } }
        func u32(_ value: UInt32) { var n=value.littleEndian; withUnsafeBytes(of:&n) { bytes.append(contentsOf:$0) } }
        let size=UInt32(result.samples.count*2)
        bytes.append(contentsOf:Array("RIFF".utf8));u32(size+36)
        bytes.append(contentsOf:Array("WAVEfmt ".utf8));u32(16);u16(1);u16(1)
        u32(24000);u32(48000);u16(2);u16(16)
        bytes.append(contentsOf:Array("data".utf8));u32(size)
        for sample in result.samples { u16(UInt16(bitPattern:Int16((max(-1,min(1,sample))*32767).rounded()))) }
        return bytes
    }
}

@MainActor
@objc(TIOLocalNarrator)
final class LocalNarrator: NSObject, AVAudioPlayerDelegate, AVSpeechSynthesizerDelegate {
    private let prefs=UserDefaults(suiteName:"io.turboio.official-private-addon")!
    private var queue:[String]=[]
    private var current:String?
    private var player:AVAudioPlayer?
    private var apple:AVSpeechSynthesizer?
    private var task:Task<Void,Never>?
    private var generation=0
    private var final=false
    private var paused=false
    private var language="en-US"
    private var prepared:Data?
    private var observers:[NSObjectProtocol]=[]
    @objc private(set) var status="Ready · Automatic language"
    @objc var isPaused:Bool { paused }
    @objc var isActive:Bool { current != nil || !queue.isEmpty }
    @objc static func make() -> LocalNarrator { LocalNarrator() }
    override init() {
        super.init()
        observers.append(NotificationCenter.default.addObserver(forName:AVAudioSession.interruptionNotification,object:nil,queue:.main) { [weak self] note in
            let kind=(note.userInfo?[AVAudioSessionInterruptionTypeKey] as? NSNumber)?.uintValue
            if kind == AVAudioSession.InterruptionType.began.rawValue {
                Task { @MainActor in self?.pause() }
            }
        })
        observers.append(NotificationCenter.default.addObserver(forName:AVAudioSession.routeChangeNotification,object:nil,queue:.main) { [weak self] note in
            let reason=(note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? NSNumber)?.uintValue
            if reason == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue {
                Task { @MainActor in self?.pause() }
            }
        })
        observers.append(NotificationCenter.default.addObserver(forName:NSNotification.Name("TurboSpeechOwner"),object:nil,queue:.main) { [weak self] note in
            Task { @MainActor in
                guard let self, (note.object as? LocalNarrator) !== self else { return }
                self.stop()
            }
        })
    }
    deinit { for observer in observers { NotificationCenter.default.removeObserver(observer) } }
    @objc(appendText:finished:)
    func append(_ text:String, finished:Bool) {
        if !isActive { NotificationCenter.default.post(name:NSNotification.Name("TurboSpeechOwner"),object:self) }
        language=SpeechOutputPolicy.language(text,override:prefs.string(forKey:"ttsLanguage") ?? "auto",fallback:language)
        let parts=SpeechOutputPolicy.chunks(text)
        guard queue.joined().count + parts.joined().count <= 12000 else { status="Speech queue limit reached"; return }
        queue.append(contentsOf:parts);final=finished
        if current == nil { next() }
    }
    @objc func stop() {
        generation += 1;task?.cancel();task=nil;prepared=nil
        player?.delegate=nil;player?.stop();player=nil
        apple?.delegate=nil;apple?.stopSpeaking(at:.immediate);apple=nil
        queue.removeAll();current=nil;paused=false;final=false;language="en-US";status="Stopped"
    }
    @objc func pause() {
        guard isActive else { return }
        paused=true;player?.pause();apple?.pauseSpeaking(at:.immediate);status="Reading paused"
    }
    @objc func resume() {
        guard paused else { return };paused=false
        if let player { player.play(); status="Reading resumed" }
        else if let apple { apple.continueSpeaking();status="Reading resumed" }
        else if let prepared { self.prepared=nil;play(prepared) }
        else if current == nil { next() }
    }
    private func next() {
        guard !paused, current == nil else { return }
        guard !queue.isEmpty else { status=final ? "Playback completed" : "Waiting for response text"; return }
        let text=queue.removeFirst();current=text
        let outputLanguage=SpeechOutputPolicy.language(text,override:prefs.string(forKey:"ttsLanguage") ?? "auto",fallback:language)
        language=outputLanguage
        let speed=SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed"))
        let voice=SpeechOutputPolicy.voice(prefs.string(forKey:"kokoroVoice"))
        if SpeechOutputPolicy.kokoro(language:outputLanguage,engine:prefs.string(forKey:"ttsOutputEngine") ?? "auto",text:text) {
            status="Kokoro · English · Preparing speech"
            let ticket=generation
            task=Task { [weak self] in
                do {
                    let data=try await KokoroWorker.shared.audio(text,voice:voice,speed:speed)
                    guard let self, self.generation == ticket, !Task.isCancelled else { return }
                    self.task=nil
                    if self.paused { self.prepared=data } else { self.play(data) }
                } catch {
                    guard let self,self.generation == ticket,!Task.isCancelled else { return }
                    self.task=nil;self.speakApple(text,language:outputLanguage,speed:speed,fallback:true)
                }
            }
        } else { speakApple(text,language:outputLanguage,speed:speed,fallback:false) }
    }
    private func play(_ data:Data) {
        do {
            try AVAudioSession.sharedInstance().setActive(true)
            let audio=try AVAudioPlayer(data:data);audio.delegate=self
            guard audio.prepareToPlay() else { throw NSError(domain:"TurboSpeech",code:3) }
            player=audio
            guard audio.play() else { throw NSError(domain:"TurboSpeech",code:4) }
            status="Kokoro · English · Reading aloud"
        } catch {
            player=nil
            if let current { speakApple(current,language:language,speed:SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed")),fallback:true) }
        }
    }
    private func speakApple(_ text:String,language:String,speed:Float,fallback:Bool) {
        let speech=AVSpeechSynthesizer();speech.delegate=self;speech.usesApplicationAudioSession=false
        let utterance=AVSpeechUtterance(string:text)
        let preferred=prefs.string(forKey:"appleSpeechVoice") ?? ""
        let candidate=AVSpeechSynthesisVoice(identifier:preferred)
        utterance.voice = candidate?.language.lowercased().hasPrefix(language.prefix(2).lowercased()) == true ? candidate : AVSpeechSynthesisVoice(language:language)
        utterance.rate=min(AVSpeechUtteranceMaximumSpeechRate,max(AVSpeechUtteranceMinimumSpeechRate,AVSpeechUtteranceDefaultSpeechRate*speed))
        apple=speech;status="Apple · \(language)\(fallback ? " · Kokoro fallback" : "") · Reading aloud"
        speech.speak(utterance)
        if paused { speech.pauseSpeaking(at:.immediate) }
    }
    private func finished() { player?.delegate=nil;player=nil;apple?.delegate=nil;apple=nil;current=nil;next() }
    func audioPlayerDidFinishPlaying(_ player:AVAudioPlayer,successfully flag:Bool) {
        guard player === self.player else { return };finished()
    }
    func audioPlayerDecodeErrorDidOccur(_ player:AVAudioPlayer,error:Error?) {
        guard player === self.player else { return };finished()
    }
    func speechSynthesizer(_ synthesizer:AVSpeechSynthesizer,didFinish utterance:AVSpeechUtterance) {
        guard synthesizer === apple else { return };finished()
    }
    func speechSynthesizer(_ synthesizer:AVSpeechSynthesizer,didCancel utterance:AVSpeechUtterance) {
        guard synthesizer === apple else { return };stop();status="Speech interrupted"
    }
}

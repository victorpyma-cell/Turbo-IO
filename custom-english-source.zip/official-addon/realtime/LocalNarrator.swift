import Foundation
import UIKit
import AVFoundation
import KokoroCoreML

private struct KokoroAudio: Sendable {
    let data:Data
    let generationSeconds:Double
    let audioSeconds:Double
}
private actor KokoroWorker {
    static let shared = KokoroWorker()
    private var engine: KokoroEngine?
    func audio(_ text: String, voice: String, speed: Float) throws -> KokoroAudio {
        let began=ProcessInfo.processInfo.systemUptime
        try Task.checkCancellation()
        if engine == nil {
            guard let directory = Bundle.main.url(forResource: "TurboKokoroModels",withExtension: "bundle") else {
                throw NSError(domain:"TurboSpeech",code:1,userInfo:[NSLocalizedDescriptionKey:"Bundled Kokoro model missing"])
            }
            // CPU-only avoids GPU work after iOS locks/backgrounds the app.
            engine = try KokoroEngine(modelDirectory: directory,forceCPU: true)
        }
        let result = try engine!.synthesize(text:text,voice:voice,speed:speed)
        try Task.checkCancellation()
        guard !result.samples.isEmpty, result.samples.count <= 24_000 * 90,
              result.samples.allSatisfy({ $0.isFinite }) else {
            throw NSError(domain:"TurboSpeech",code:2,userInfo:[NSLocalizedDescriptionKey:"Invalid generated audio"])
        }
        var bytes = Data()
        func u16(_ value: UInt16) { var n=value.littleEndian; withUnsafeBytes(of:&n) { bytes.append(contentsOf:$0) } }
        func u32(_ value: UInt32) { var n=value.littleEndian; withUnsafeBytes(of:&n) { bytes.append(contentsOf:$0) } }
        let size=UInt32(result.samples.count*2)
        bytes.append(contentsOf:Array("RIFF".utf8));u32(size+36)
        bytes.append(contentsOf:Array("WAVEfmt ".utf8));u32(16);u16(1);u16(1)
        u32(24000);u32(48000);u16(2);u16(16)
        bytes.append(contentsOf:Array("data".utf8));u32(size)
        for sample in result.samples { u16(UInt16(bitPattern:Int16((max(-1,min(1,sample))*32767).rounded()))) }
        return KokoroAudio(data:bytes,generationSeconds:ProcessInfo.processInfo.systemUptime-began,audioSeconds:Double(result.samples.count)/24000)
    }
}

@MainActor
@objc(TIOLocalNarrator)
final class LocalNarrator: NSObject, AVAudioPlayerDelegate, AVSpeechSynthesizerDelegate {
    private let prefs=UserDefaults(suiteName:"io.turboio.official-private-addon")!
    private var queue:[String]=[]
    private var current:String?
    private var player:AVAudioPlayer?
    private var apple:AVSpeechSynthesizer?
    private var task:Task<Void,Never>?
    private var deadline:Task<Void,Never>?
    private var prefetch:Task<KokoroAudio,Error>?
    private var prefetchText:String?
    private var kokoroFailed=false
    private var generation=0
    private var final=false
    private var paused=false
    private var language="en-US"
    private var prepared:Data?
    private var observers:[NSObjectProtocol]=[]
    private var backgroundTask:UIBackgroundTaskIdentifier = .invalid
    @objc private(set) var status="Ready · Automatic language"
    @objc var isPaused:Bool { paused }
    @objc var isActive:Bool { current != nil || !queue.isEmpty }
    @objc static func make() -> LocalNarrator { LocalNarrator() }
    override init() {
        super.init()
        observers.append(NotificationCenter.default.addObserver(forName:AVAudioSession.interruptionNotification,object:nil,queue:.main) { [weak self] note in
            let kind=(note.userInfo?[AVAudioSessionInterruptionTypeKey] as? NSNumber)?.uintValue
            if kind == AVAudioSession.InterruptionType.began.rawValue {
                Task { @MainActor in self?.pause() }
            }
        })
        observers.append(NotificationCenter.default.addObserver(forName:AVAudioSession.routeChangeNotification,object:nil,queue:.main) { [weak self] note in
            let reason=(note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? NSNumber)?.uintValue
            if reason == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue {
                Task { @MainActor in self?.pause() }
            }
        })
        observers.append(NotificationCenter.default.addObserver(forName:NSNotification.Name("TurboSpeechOwner"),object:nil,queue:.main) { [weak self] note in
            Task { @MainActor in
                guard let self, (note.object as? LocalNarrator) !== self else { return }
                self.stop()
            }
        })
    }
    deinit { for observer in observers { NotificationCenter.default.removeObserver(observer) } }
    @objc(appendText:finished:)
    func append(_ text:String, finished:Bool) {
        if !isActive { NotificationCenter.default.post(name:NSNotification.Name("TurboSpeechOwner"),object:self) }
        language=SpeechOutputPolicy.language(text,override:prefs.string(forKey:"ttsLanguage") ?? "auto",fallback:language)
        let parts=SpeechOutputPolicy.chunks(text)
        guard queue.joined().count + parts.joined().count <= 12000 else { status="Speech queue limit reached"; return }
        queue.append(contentsOf:parts);final=finished
        if current == nil { next() } else if player != nil { prefetchNext() }
    }
    @objc func stop() {
        generation += 1;prefetch?.cancel();prefetch=nil;prefetchText=nil;task?.cancel();task=nil;deadline?.cancel();deadline=nil;prepared=nil;kokoroFailed=false
        player?.delegate=nil;player?.stop();player=nil
        apple?.delegate=nil;apple?.stopSpeaking(at:.immediate);apple=nil
        queue.removeAll();current=nil;paused=false;final=false;language="en-US";status="Stopped";endBackgroundTask()
    }
    @objc func pause() {
        guard isActive else { return }
        paused=true;player?.pause();apple?.pauseSpeaking(at:.immediate);status="Reading paused"
    }
    @objc func resume() {
        guard paused else { return };paused=false
        if let player { player.play(); status="Reading resumed" }
        else if let apple { apple.continueSpeaking();status="Reading resumed" }
        else if let prepared { self.prepared=nil;play(prepared) }
        else if current == nil { next() }
    }
    private func next() {
        guard !paused, current == nil else { return }
        guard !queue.isEmpty else { status=final ? "Playback completed" : "Waiting for response text"; return }
        let text=queue.removeFirst();current=text
        if backgroundTask == .invalid {
            backgroundTask=UIApplication.shared.beginBackgroundTask(withName:"Turbo speech generation") { [weak self] in
                Task { @MainActor in self?.stop();self?.status="Speech stopped when background time expired" }
            }
        }
        let outputLanguage=SpeechOutputPolicy.language(text,override:prefs.string(forKey:"ttsLanguage") ?? "auto",fallback:language)
        language=outputLanguage
        let speed=SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed"))
        let voice=SpeechOutputPolicy.voice(prefs.string(forKey:"kokoroVoice"))
        if !kokoroFailed && SpeechOutputPolicy.kokoro(language:outputLanguage,engine:prefs.string(forKey:"ttsOutputEngine") ?? "auto",text:text) {
            status="Kokoro · English · Preparing speech"
            let ticket=generation
            deadline=Task { [weak self] in
                do { try await Task.sleep(nanoseconds:8_000_000_000) } catch { return }
                guard let self,self.generation == ticket,self.task != nil,!Task.isCancelled else { return }
                self.generation += 1;self.task?.cancel();self.task=nil;self.deadline=nil;self.kokoroFailed=true
                self.speakApple(text,language:outputLanguage,speed:speed,fallback:true)
            }
            let pending = prefetchText == text ? prefetch : nil
            if pending == nil { prefetch?.cancel() }
            if pending == nil { prefetch=nil;prefetchText=nil }
            task=Task { [weak self] in
                do {
                    let result:KokoroAudio
                    if let pending { result=try await pending.value } else { result=try await KokoroWorker.shared.audio(text,voice:voice,speed:speed) }
                    guard let self, self.generation == ticket, !Task.isCancelled else { return }
                    self.prefetch=nil;self.prefetchText=nil
                    self.task=nil
                    self.deadline?.cancel();self.deadline=nil
                    if !SpeechOutputPolicy.smoothEnough(generationSeconds:result.generationSeconds,audioSeconds:result.audioSeconds,engine:self.prefs.string(forKey:"ttsOutputEngine") ?? "auto") {
                        self.kokoroFailed=true;self.speakApple(text,language:outputLanguage,speed:speed,fallback:true)
                    } else if self.paused { self.prepared=result.data;self.endBackgroundTask() } else { self.play(result.data) }
                } catch {
                    guard let self,self.generation == ticket,!Task.isCancelled else { return }
                    self.prefetch?.cancel();self.prefetch=nil;self.prefetchText=nil
                    self.task=nil;self.deadline?.cancel();self.deadline=nil;self.kokoroFailed=true
                    self.speakApple(text,language:outputLanguage,speed:speed,fallback:true)
                }
            }
        } else { speakApple(text,language:outputLanguage,speed:speed,fallback:false) }
    }
    private func prefetchNext() {
        guard prefetch == nil, !kokoroFailed, let text=queue.first else { return }
        let output=SpeechOutputPolicy.language(text,override:prefs.string(forKey:"ttsLanguage") ?? "auto",fallback:language)
        guard SpeechOutputPolicy.kokoro(language:output,engine:prefs.string(forKey:"ttsOutputEngine") ?? "auto",text:text) else { return }
        let voice=SpeechOutputPolicy.voice(prefs.string(forKey:"kokoroVoice")),speed=SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed"))
        prefetchText=text
        prefetch=Task { try await KokoroWorker.shared.audio(text,voice:voice,speed:speed) }
    }
    private func play(_ data:Data) {
        do {
            try AVAudioSession.sharedInstance().setActive(true)
            let audio=try AVAudioPlayer(data:data);audio.delegate=self
            guard audio.prepareToPlay() else { throw NSError(domain:"TurboSpeech",code:3) }
            player=audio
            guard audio.play() else { throw NSError(domain:"TurboSpeech",code:4) }
            status="Kokoro · English · Reading aloud"
            prefetchNext()
            endBackgroundTask()
        } catch {
            player=nil
            if let current { speakApple(current,language:language,speed:SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed")),fallback:true) }
        }
    }
    private func speakApple(_ text:String,language:String,speed:Float,fallback:Bool) {
        prefetch?.cancel();prefetch=nil;prefetchText=nil
        let speech=AVSpeechSynthesizer();speech.delegate=self;speech.usesApplicationAudioSession=false
        let utterance=AVSpeechUtterance(string:text)
        let preferred=prefs.string(forKey:"appleSpeechVoice") ?? ""
        let candidate=AVSpeechSynthesisVoice(identifier:preferred)
        let matching=AVSpeechSynthesisVoice.speechVoices().filter { SpeechOutputPolicy.matchesVoice($0.language,outputLanguage:language) }
        let best=matching.sorted {
            if $0.language == language && $1.language != language { return true }
            if $1.language == language && $0.language != language { return false }
            return $0.quality.rawValue > $1.quality.rawValue
        }.first
        utterance.voice = candidate.map { SpeechOutputPolicy.matchesVoice($0.language,outputLanguage:language) } == true ? candidate : (best ?? AVSpeechSynthesisVoice(language:language))
        utterance.rate=min(AVSpeechUtteranceMaximumSpeechRate,max(AVSpeechUtteranceMinimumSpeechRate,AVSpeechUtteranceDefaultSpeechRate*speed))
        apple=speech;status="Apple · \(language)\(fallback ? " · Kokoro fallback" : "") · Reading aloud"
        speech.speak(utterance)
        endBackgroundTask()
        if paused { speech.pauseSpeaking(at:.immediate) }
    }
    private func finished() { player?.delegate=nil;player=nil;apple?.delegate=nil;apple=nil;current=nil;next() }
    private func endBackgroundTask() {
        if backgroundTask != .invalid { UIApplication.shared.endBackgroundTask(backgroundTask);backgroundTask = .invalid }
    }
    nonisolated func audioPlayerDidFinishPlaying(_ player:AVAudioPlayer,successfully flag:Bool) {
        Task { @MainActor [weak self] in
            guard let self,player === self.player else { return }
            if flag { self.finished() } else { self.recoverAudio() }
        }
    }
    nonisolated func audioPlayerDecodeErrorDidOccur(_ player:AVAudioPlayer,error:Error?) {
        Task { @MainActor [weak self] in
            guard let self,player === self.player else { return };self.recoverAudio()
        }
    }
    private func recoverAudio() {
        player?.delegate=nil;player?.stop();player=nil
        if let current { speakApple(current,language:language,speed:SpeechOutputPolicy.speed(prefs.double(forKey:"ttsSpeed")),fallback:true) }
        else { finished() }
    }
    nonisolated func speechSynthesizer(_ synthesizer:AVSpeechSynthesizer,didFinish utterance:AVSpeechUtterance) {
        Task { @MainActor [weak self] in
            guard let self,synthesizer === self.apple else { return };self.finished()
        }
    }
    nonisolated func speechSynthesizer(_ synthesizer:AVSpeechSynthesizer,didCancel utterance:AVSpeechUtterance) {
        Task { @MainActor [weak self] in
            guard let self,synthesizer === self.apple else { return };self.stop();self.status="Speech interrupted"
        }
    }
}

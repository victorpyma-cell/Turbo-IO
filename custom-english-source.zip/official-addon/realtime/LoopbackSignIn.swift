import Foundation
import Network

// Shared by the iPhone sign-in and a real TCP callback integration test on macOS.
@MainActor final class LoopbackSignIn {
    struct Failure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }
    private var listener: NWListener?
    private var ready: CheckedContinuation<UInt16, Error>?
    private var startupTimeout: Task<Void, Never>?
    private var connections: [ObjectIdentifier: (NWConnection, Task<Void, Never>)] = [:]
    private var callback: ((URL) -> Void)?
    private var failure: ((Error) -> Void)?
    private var expectedState = ""
    private var port: UInt16 = 0

    func start(state: String, onCallback: @escaping (URL) -> Void, onFailure: @escaping (Error) -> Void) async throws -> UInt16 {
        cancel()
        expectedState = state; callback = onCallback; failure = onFailure
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        let server = try NWListener(using: parameters)
        listener = server
        // Network.framework requires this handler before start(), even before ready.
        server.newConnectionHandler = { [weak self, weak server] connection in
            Task { @MainActor in
                guard let self, let server, self.listener === server, self.connections.count < 8 else { connection.cancel(); return }
                self.accept(connection)
            }
        }
        server.stateUpdateHandler = { [weak self, weak server] state in
            Task { @MainActor in
                guard let self, let server, self.listener === server else { return }
                switch state {
                case .ready:
                    guard let port = server.port else { self.fail(Failure(message: "No local sign-in port is available.")); return }
                    self.port = port.rawValue
                    self.startupTimeout?.cancel(); self.startupTimeout = nil
                    let pending = self.ready; self.ready = nil; pending?.resume(returning: port.rawValue)
                case .failed(let error):
                    self.fail(Failure(message: "The local sign-in listener failed (\(error)). Try signing in again."))
                case .cancelled: self.fail(CancellationError())
                default: break
                }
            }
        }
        return try await withCheckedThrowingContinuation { pending in
            ready = pending
            startupTimeout = Task { [weak self] in
                try? await Task.sleep(nanoseconds: 10_000_000_000)
                guard !Task.isCancelled else { return }
                self?.fail(Failure(message: "The local sign-in listener timed out. Try again."))
            }
            server.start(queue: .main)
        }
    }
    private func fail(_ error: Error) {
        let pending = ready; ready = nil
        let notify = failure
        cancel()
        if let pending { pending.resume(throwing: error) } else { notify?(error) }
    }
    func cancel() {
        startupTimeout?.cancel(); startupTimeout = nil
        let server = listener; listener = nil
        server?.stateUpdateHandler = nil; server?.newConnectionHandler = nil; server?.cancel()
        for (_, value) in connections { value.1.cancel(); value.0.cancel() }
        connections.removeAll(); callback = nil; failure = nil
        let pending = ready; ready = nil; pending?.resume(throwing: CancellationError())
    }
    private func finish(_ connection: NWConnection) {
        connections.removeValue(forKey: ObjectIdentifier(connection))?.1.cancel()
        connection.cancel()
    }
    private func accept(_ connection: NWConnection) {
        let deadline = Task { [weak self, weak connection] in
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            guard !Task.isCancelled, let connection else { return }
            self?.finish(connection)
        }
        connections[ObjectIdentifier(connection)] = (connection, deadline)
        connection.start(queue: .main)
        receive(connection, data: Data())
    }
    private func receive(_ connection: NWConnection, data: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 8192) { [weak self] bytes, _, complete, error in
            Task { @MainActor in
                guard let self, self.connections[ObjectIdentifier(connection)] != nil else { connection.cancel(); return }
                let all = data + (bytes ?? Data())
                guard all.count <= 8192, error == nil else { self.finish(connection); return }
                guard let request = String(data: all, encoding: .utf8), request.contains("\r\n\r\n") else {
                    if complete { self.finish(connection) } else { self.receive(connection, data: all) }; return
                }
                let first = request.components(separatedBy: "\r\n").first?.split(separator: " ") ?? []
                let origin = URL(string: "http://127.0.0.1:\(self.port)")!
                let url = first.count == 3 && first[0] == "GET" ? URL(string: String(first[1]), relativeTo: origin)?.absoluteURL : nil
                let items = url.flatMap { URLComponents(url: $0, resolvingAgainstBaseURL: false)?.queryItems } ?? []
                let valid = url?.scheme == "http" && url?.host == "127.0.0.1" && url?.port == Int(self.port) && url?.path == "/auth/callback" && items.filter({ $0.name == "state" }).count == 1 && items.first(where: { $0.name == "state" })?.value == self.expectedState && self.callback != nil
                let body = valid ? "Sign-in received. Return to Turbo IO." : "Invalid sign-in callback."
                let response = "HTTP/1.1 \(valid ? "200 OK" : "400 Bad Request")\r\nContent-Type: text/plain\r\nCache-Control: no-store\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(body)"
                let pending = valid ? self.callback : nil
                if valid { self.callback = nil }
                connection.send(content: Data(response.utf8), completion: .contentProcessed { [weak self] _ in
                    Task { @MainActor in
                        self?.finish(connection)
                        // Flush the browser response before the caller cancels the listener.
                        if let url { pending?(url) }
                    }
                })
            }
        }
    }
}

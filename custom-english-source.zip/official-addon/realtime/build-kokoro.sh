#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
root="$PWD/build/essentials/kokoro"
mkdir -p "$root"
git clone https://github.com/Jud/kokoro-coreml.git "$root/KokoroCoreML"
git -C "$root/KokoroCoreML" checkout --detach 6bfc02afb237a311caee927482e58c028edb6acb
xcrun swift build --package-path "$root/KokoroCoreML" --scratch-path "$root/ios-build" \
  --configuration release --build-system swiftbuild --triple arm64-apple-ios26.0 \
  --sdk "$(xcrun --sdk iphoneos --show-sdk-path)" --target KokoroCoreML
curl --fail --location --retry 3 https://github.com/Jud/kokoro-coreml/releases/download/models-2026-03-23/kokoro-models.tar.gz -o "$root/models.tar.gz"
python3 - <<'PY'
from pathlib import Path,PurePosixPath
import hashlib,tarfile,shutil,json
root=Path('build/essentials/kokoro')
archive=root/'models.tar.gz'
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()=='0d24bbf80526456bd8640f9f484cd1c333aee8a936e618ac44e619eafb79aec9'
model=Path('build/essentials/resources/TurboKokoroModels.bundle');model.mkdir(parents=True)
with tarfile.open(archive) as tar:
    for item in tar:
        rel=PurePosixPath(item.name)
        assert not rel.is_absolute() and '..' not in rel.parts and ':' not in item.name and '\\' not in item.name
        assert item.isdir() or item.isfile()
        if any(p.startswith('._') for p in rel.parts):continue
        if rel.parts[0] not in ('kokoro_frontend.mlmodelc','kokoro_backend.mlmodelc','voices','vocab_index.json'):continue
        destination=model/item.name
        if item.isdir():destination.mkdir(parents=True,exist_ok=True)
        else:
            destination.parent.mkdir(parents=True,exist_ok=True)
            with tar.extractfile(item) as source,destination.open('wb') as output:shutil.copyfileobj(source,output)
assert (model/'kokoro_frontend.mlmodelc').is_dir() and (model/'kokoro_backend.mlmodelc').is_dir()
for voice in ['af_heart','af_bella','am_adam','am_michael']:assert (model/'voices'/f'{voice}.bin').is_file()
matches=list((root/'ios-build').rglob('Release-iphoneos/KokoroCoreML.o'));assert len(matches)==1
products=matches[0].parent
(root/'products-path.txt').write_text(str(products.resolve()))
for bundle in products.glob('*.bundle'):shutil.copytree(bundle,Path('build/essentials/resources')/bundle.name,dirs_exist_ok=True)
licenses=Path('build/essentials/resources/TurboKokoroLicenses.bundle');licenses.mkdir(exist_ok=True)
for package in [root/'KokoroCoreML']+list((root/'ios-build/checkouts').glob('*')):
    for file in package.glob('*'):
        if file.is_file() and file.name.upper().startswith(('LICENSE','NOTICE','COPYING')):shutil.copy2(file,licenses/(package.name+'-'+file.name))
shutil.copy2(root/'KokoroCoreML/Package.resolved',licenses/'Package.resolved')
(licenses/'MODEL-NOTICE.txt').write_text('Kokoro-82M by hexgrad, Apache-2.0. https://huggingface.co/hexgrad/Kokoro-82M\nCoreML conversion by Jud, Apache-2.0. Source revision 6bfc02afb237a311caee927482e58c028edb6acb\nModel release models-2026-03-23; archive SHA256 0d24bbf80526456bd8640f9f484cd1c333aee8a936e618ac44e619eafb79aec9\n')
PY
xcrun swiftc realtime/SpeechOutputPolicy.swift realtime/SpeechOutputTests.swift -framework NaturalLanguage -o "$root/policy-tests"
"$root/policy-tests"
# Run a real CPU synthesis test with the same model on the hosted Mac.
xcrun swift build --package-path "$root/KokoroCoreML" --scratch-path "$root/mac-build" --configuration release --build-system swiftbuild --target KokoroCoreML
macProducts=$(find "$root/mac-build" -name KokoroCoreML.o -path '*/Release/*' -print | head -1 | xargs dirname)
[[ -n "$macProducts" ]]
xcrun swiftc -target "$(uname -m)-apple-macos15.0" -parse-as-library -I "$macProducts" realtime/KokoroModelTests.swift "$macProducts"/*.o \
  -framework Accelerate -framework CoreML -framework AVFoundation -o "$macProducts/kokoro-model-tests"
"$macProducts/kokoro-model-tests" "$PWD/build/essentials/resources/TurboKokoroModels.bundle"

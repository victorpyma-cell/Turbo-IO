import Foundation
import UIKit
import SwiftUI
import Translation
import Combine

@available(iOS 26.0, *)
@MainActor @objc(TIORealtimeHost) final class TIORealtimeHost: NSObject {
    private static var callback: ((String, NSDictionary) -> NSDictionary)?
    static let live = RealtimeSession()
    static let navigation = AppleNavigation()
    static let meeting = MeetingCopilot()
    private static weak var meetingController: UIViewController?
    private static weak var liveController: UIViewController?
    private static weak var navigationController: UIViewController?
    private static var voiceTask: Task<Void,Never>?
    private static var voiceGeneration = 0
    private static var voicePage: String?
    @objc(configure:) static func configure(_ callback: @escaping (String, NSDictionary) -> NSDictionary) { self.callback = callback }
    static func call(_ operation: String, _ args: [String:Any] = [:]) -> [String:Any] { callback?(operation,args as NSDictionary) as? [String:Any] ?? [:] }
    @objc(chatGPTReady) static func chatGPTReady() -> Bool {
        ChatGPTAccount.shared.isSignedIn && !(ChatGPTAccount.shared.selectedModel ?? "").isEmpty
    }
    @objc(startChatGPTQuestion:history:update:) static func startChatGPTQuestion(_ question: String, history: [[String: String]], update: @escaping (String, Bool, String?) -> Void) -> NSObject {
        ChatGPTAnswer(question: question, history: history, update: update)
    }
    @objc(startChatGPTNews:update:) static func startChatGPTNews(_ question: String, update: @escaping (String, Bool, String?) -> Void) -> NSObject {
        ChatGPTAnswer(question: question, history: [], requireSearch: true, update: update)
    }
    @objc(makeController:) static func makeController(_ page: String) -> UIViewController {
        if page == "meeting" {
            if let existing = meetingController { return existing }
            let controller = UIHostingController(rootView:MeetingCopilotPanel(meeting:meeting))
            meetingController = controller; return controller
        }
        if page == "navigate" {
            if let existing = navigationController { return existing }
            let controller = UIHostingController(rootView: NavigationPanel(nav:navigation))
            navigationController = controller; return controller
        }
        if page == "translateRoot" { if !live.running && !live.busy { live.mode = .translate }; return UIHostingController(rootView:RealtimePanel(session:live)) }
        if page == "speechOutput" { return UIHostingController(rootView:SpeechOutputPanel()) }
        if page == "nova" { return UIHostingController(rootView:NovaPanel()) }
        if page == "chatgpt" { return UIHostingController(rootView: AccountPanel()) }
        if !live.running && !live.busy { live.mode = mode(page) }
        if let existing = liveController { return existing }
        let controller = UIHostingController(rootView: RealtimePanel(session:live))
        liveController = controller; return controller
    }
    private static func mode(_ page: String) -> LiveMode { page == "standby" ? .standby : page == "translate" ? .translate : (page == "captions" ? .captions : .cue) }
    @objc(officialAudioStarted) static func officialAudioStarted() {
        cancelVoiceLaunch()
        meeting.stop("Stopped for the glasses voice assistant · transcript retained")
        if live.running || live.busy { live.stop("Stopped for the glasses voice assistant") }
        if navigation.running || navigation.acquiring || navigation.busy { navigation.stop("Stopped for the glasses voice assistant") }
    }
    private static func cancelVoiceLaunch() { voiceGeneration += 1; voiceTask?.cancel(); voiceTask = nil; voicePage = nil }
    static func closeLivePage() { if voicePage != "navigate" { cancelVoiceLaunch() }; live.stop() }
    static func closeNavigationPage() { if voicePage == "navigate" { cancelVoiceLaunch() }; navigation.stop() }
    @objc(handleVoiceCommand:) static func handleVoiceCommand(_ command: NSDictionary) -> UIViewController? {
        guard let action = command["action"] as? String, let page = command["page"] as? String else { return nil }
        if action == "stop" {
            cancelVoiceLaunch()
            if page == "all" || page == live.mode.page { live.stop("Stopped by voice") }
            if page == "all" || page == "navigate" { navigation.stop("Stopped by voice") }
            return nil
        }
        if action == "ask" { live.askNow(); return nil }
        if action == "followup" { live.followUp(command["query"] as? String ?? ""); return nil }
        guard ["start","search","open"].contains(action), ["standby","liveCue","translate","captions","navigate"].contains(page), UIApplication.shared.applicationState == .active else { return nil }
        guard !meeting.active else { meeting.stop("Stopped for a voice tool command · transcript retained"); return nil }
        cancelVoiceLaunch(); let epoch = voiceGeneration; voicePage = page
        // Commands never silently switch an already-running session to a different
        // microphone. Finish local capture and the prior display session first.
        let controller = makeController(page)
        voiceTask = Task { @MainActor [weak controller] in
            defer { if voiceGeneration == epoch { voiceTask = nil; voicePage = nil } }
            await live.stopAndWait("Switching tools…")
            navigation.stop()
            do {
                // Give the official stopWorkflow and presentation their own turns.
                // The subtitle protocol still requires a fresh start acknowledgement.
                try await Task.sleep(nanoseconds:1_200_000_000)
                guard !Task.isCancelled, voiceGeneration == epoch,
                      UIApplication.shared.applicationState == .active,
                      controller?.view.window != nil else { return }
                let phase = call("status")["phase"] as? String ?? "idle"
                guard !["stopping","uncertain"].contains(phase) else {
                    live.status = "Waiting for the glasses to exit. Repeat the command when the home screen returns."
                    navigation.status = live.status; return
                }
                if page == "navigate" {
                    if action == "search", let query = command["query"] as? String {
                        navigation.query = query; await navigation.findPlaces()
                        if !navigation.places.isEmpty { navigation.status = "Choose the intended destination, then say start navigation." }
                    } else if action == "start" {
                        if navigation.destination == nil { navigation.status = "Choose a destination, then say start navigation." }
                        else { navigation.start() }
                    }
                } else {
                    await live.loadLanguages()
                    guard !Task.isCancelled, voiceGeneration == epoch, controller?.view.window != nil else { return }
                    live.mode = mode(page); live.start()
                }
            } catch { /* A newer command or leaving the page cancels launch. */ }
        }
        return controller
    }
}

@available(iOS 26.0, *)
@MainActor final class GlassesDisplay {
    static let shared = GlassesDisplay()
    private var owner: UUID?
    private var sid = ""
    private var desired = ""
    private var sent: String?
    private var timer: Timer?
    private var failure: ((String) -> Void)?
    private var began = Date()
    private var ready = false
    func acquire(_ id: UUID, enabled: Bool, failure: @escaping (String)->Void) throws {
        guard owner == nil else { throw RealtimeError("Stop the current Live Cue, translation, or navigation session first.") }
        owner = id; self.failure = failure; desired = ""; sent = nil; ready = false
        guard enabled else { return }
        guard TIORealtimeHost.call("status")["available"] as? Bool == true,
              let session = TIORealtimeHost.call("start")["sid"] as? String, !session.isEmpty else {
            owner = nil; self.failure = nil
            throw RealtimeError("The glasses display is not ready. Connect in the RayNeo device page, end any active glasses feature, then return and start again.")
        }
        sid = session; began = Date()
        let timer = Timer(timeInterval:0.5,repeats:true) { [weak self] _ in
            Task { @MainActor in self?.flush() }
        }
        self.timer = timer; RunLoop.main.add(timer,forMode:.common)
    }
    func update(_ text: String, owner: UUID) { if self.owner == owner { desired = RealtimePolicy.hud(text); flush() } }
    private func flush() {
        guard !sid.isEmpty, let id = owner else { return }
        let status = TIORealtimeHost.call("status"), phase = status["phase"] as? String ?? ""
        if ["ready","navigation"].contains(phase) { ready = true }
        if ["idle","uncertain","stopping","stopped"].contains(phase) || Date().timeIntervalSince(began) > 1200 {
            let report = failure; release(id)
            report?("The glasses display session ended. Restart after the glasses return to their home screen."); return
        }
        if !ready && Date().timeIntervalSince(began) > 12 {
            let report = failure; release(id); report?("The glasses did not acknowledge the display request. Check the connection and restart."); return
        }
        // The display protocol needs a nonempty frame. A space replaces the
        // previous answer with a blank display while we wait for a new question.
        let frame = desired.isEmpty ? " " : desired
        guard frame != sent, status["pending"] as? Bool != true else { return }
        if TIORealtimeHost.call("text",["sid":sid,"text":frame])["ok"] as? Bool == true { sent = frame; ready = true }
    }
    func release(_ id: UUID) {
        guard owner == id else { return }
        timer?.invalidate(); timer = nil
        if !sid.isEmpty { _ = TIORealtimeHost.call("stop",["sid":sid]) }
        owner = nil; sid = ""; failure = nil; desired = ""; sent = nil; ready = false
    }
}

enum LiveMode: String, CaseIterable {
    case standby = "Listen for Nova", cue = "Live Cue", translate = "Translation", captions = "Captions"
    var page: String { self == .standby ? "standby" : self == .cue ? "liveCue" : (self == .translate ? "translate" : "captions") }
}
enum TranslationEngine: String, CaseIterable {
    case hymt = "Hy-MT2 · offline", apple = "Apple · offline", chatGPT = "ChatGPT · optional"
}

@available(iOS 26.0, *)
@MainActor final class RealtimeSession: ObservableObject {
    @Published var speechEngine = SpeechEngine(rawValue:UserDefaults.standard.string(forKey:"TurboRealtime.speechEngine") ?? "") ?? .apple {
        didSet { UserDefaults.standard.set(speechEngine.rawValue,forKey:"TurboRealtime.speechEngine") }
    }
    @Published var mode: LiveMode = .cue
    @Published var translationEngine = TranslationEngine(rawValue:UserDefaults.standard.string(forKey:"TurboRealtime.translationEngine") ?? "") ?? .hymt {
        didSet { UserDefaults.standard.set(translationEngine.rawValue,forKey:"TurboRealtime.translationEngine") }
    }
    @Published var source = UserDefaults.standard.string(forKey:"TurboRealtime.source") ?? "en-US" {
        didSet { UserDefaults.standard.set(source,forKey:"TurboRealtime.source") }
    }
    @Published var target = UserDefaults.standard.string(forKey:"TurboRealtime.target") ?? "es" {
        didSet { UserDefaults.standard.set(target,forKey:"TurboRealtime.target") }
    }
    @Published var languages: [String] = []
    @Published var translationLanguages: [String] = []
    @Published var captions = ""
    @Published var output = ""
    @Published var status = "Ready"
    @Published var running = false
    @Published var busy = false
    @Published var showOnGlasses = true
    @Published var timing = ""
    var validSpeechLanguages: [String] {
        if mode == .translate && translationEngine == .hymt { return languages.filter { CaptionHyMTTranslation.languageName($0) != nil } }
        return languages
    }
    private let speech = LocalSpeech()
    private let hymt = CaptionHyMTTranslation()
    private let id = UUID()
    private var revision = 0
    private var window = TranscriptWindow()
    private var utterance = UtteranceWindow(maxCharacters:300)
    private var voiceWindow = VoiceCommandWindow()
    private var voiceDebounce: Task<Void,Never>?
    private var voiceRevision = 0
    private var pendingVoiceStop: String?
    private var latest = ""
    private var completedContext: [String] = []
    private var lastSubmitted = ""
    private var lastAnswer = ""
    private var debounce: Task<Void,Never>?
    private var cueTask: Task<Void,Never>?
    private var cueExpiry: Task<Void,Never>?
    private var sessionExpiry: Task<Void,Never>?
    private var cueGate = CueQuestionGate()
    private var startTask: Task<Void,Never>?
    private var stopTask: Task<Void,Never>?
    private var translateTask: Task<Void,Never>?
    private var translationQueue = TranslationQueue()
    private var translationCards = TranslationCards()
    private var translationUtterance = TranslationPhraseWindow()
    private var translationLastStarted = -Double.infinity
    private var activeTranslationPartial = ""
    private var translatedSession: TranslationSession?
    private var runGeneration = 0
    private var closedRanges = Set<Double>()

    func loadLanguages() async {
        languages = SpeechLocalePolicy.unique(await LocalSpeech.languages(engine:speechEngine).map(\.identifier))
        if let equivalent = languages.first(where:{SpeechLocalePolicy.key($0) == SpeechLocalePolicy.key(source)}) { source = equivalent }
        if translationEngine == .hymt { translationLanguages = ["de","en","es","fr","it","ja","ko","pt","ru","yue","zh","zh-Hant"] }
        else { translationLanguages = await LanguageAvailability().supportedLanguages.map { $0.minimalIdentifier }.sorted() }
        if !languages.contains(source), let english = languages.first(where:{$0.hasPrefix("en")}) { source = english }
        if !translationLanguages.contains(target), let first = translationLanguages.first { target = first }
        if languages.isEmpty { status = "Apple on-device speech is unavailable on this device." }
    }
    func prepareSpeech() async {
        guard !running, !busy else { return }
        busy = true; status = "Preparing speech model…"
        defer { busy = false }
        do { try await speech.prepareLanguage(source,engine:speechEngine); status = "Speech model ready" }
        catch { status = error.localizedDescription }
    }
    func start() {
        guard !running, !busy else { return }
        guard !TIORealtimeHost.meeting.active else { status = "Stop Meeting Copilot first."; return }
        busy = true; runGeneration += 1; let epoch = runGeneration
        startTask = Task {
            do {
                if mode == .translate && translationEngine == .hymt {
                    guard CaptionHyMTTranslation.languageName(source) != nil else { throw RealtimeError("Hy-MT2 does not support the selected speech language: \(SpeechLocalePolicy.label(source)) (\(source)). Choose another spoken language.") }
                    guard CaptionHyMTTranslation.languageName(target) != nil else { throw RealtimeError("Hy-MT2 does not support the selected translation language: \(target). Choose another target language.") }
                    guard let url = Bundle.main.url(forResource:"Hy-MT2-1.8B-STQ43",withExtension:"gguf",subdirectory:"TurboCaptionModels") else { throw RealtimeError("The Hy-MT2 model is missing. Install the complete build.") }
                    status = "Loading local translation model…"
                    // Leave CPU capacity for speech recognition, audio and display.
                    try await hymt.load(url:url,threads:2)
                }
                if mode == .translate && translationEngine == .chatGPT {
                    guard TIORealtimeHost.chatGPTReady() else { throw RealtimeError("Sign in and select a model under ChatGPT account, or choose Apple offline translation.") }
                }
                if mode == .translate && translationEngine == .apple {
                    let a = Locale.Language(identifier:source), b = Locale.Language(identifier:target)
                    guard await LanguageAvailability().status(from:a,to:b) == .installed else { throw RealtimeError("Prepare the selected translation languages first.") }
                    translatedSession = TranslationSession(installedSource:a,target:b)
                }
                if mode == .cue { try CueService.validateProvider() }
                try Task.checkCancellation()
                try GlassesDisplay.shared.acquire(id,enabled:showOnGlasses && mode != .standby) { [weak self] message in self?.stop(message) }
                window.reset(); utterance = UtteranceWindow(maxCharacters:300); voiceWindow = VoiceCommandWindow(); closedRanges.removeAll(); completedContext.removeAll(); latest = ""; captions = ""; output = ""; lastSubmitted = ""; timing = ""
                cueGate = CueQuestionGate()
                lastAnswer = ""
                translationQueue = TranslationQueue(); translationCards = TranslationCards(); translationUtterance = TranslationPhraseWindow(); translationLastStarted = -Double.infinity
                speech.onText = { [weak self] piece in self?.receive(piece) }
                speech.onFailure = { [weak self] message in self?.stop(message) }
                // Permit results as soon as the engine starts.
                running = true
                try await speech.start(language:source,engine:speechEngine)
                guard epoch == runGeneration, !Task.isCancelled else { throw CancellationError() }
                busy = false; status = "Listening · iPhone microphone · \(speech.engineName)"
                UIApplication.shared.isIdleTimerDisabled = true
                sessionExpiry = Task { [weak self] in
                    try? await Task.sleep(nanoseconds:1_200_000_000_000)
                    guard !Task.isCancelled, let self, self.running, self.runGeneration == epoch else { return }
                    self.stop("20-minute listening session ended. Tap Start to continue.")
                }
            } catch {
                if epoch == runGeneration { stop(error is CancellationError ? "Stopped" : error.localizedDescription) }
            }
        }
    }
    func stop(_ message: String = "Stopped") {
        runGeneration += 1; let epoch = runGeneration; revision += 1; running = false; busy = true; status = message
        startTask?.cancel(); startTask = nil; debounce?.cancel(); cueTask?.cancel(); cueExpiry?.cancel(); cueExpiry = nil; translateTask?.cancel()
        sessionExpiry?.cancel(); sessionExpiry = nil
        cancelVoiceStop()
        debounce = nil; cueTask = nil; translateTask = nil; translationQueue = TranslationQueue()
        translatedSession?.cancel(); translatedSession = nil
        hymt.unload()
        GlassesDisplay.shared.release(id); UIApplication.shared.isIdleTimerDisabled = false
        stopTask = Task { await speech.stop(); if runGeneration == epoch { busy = false; stopTask = nil } }
    }
    func stopAndWait(_ message: String) async { stop(message); await stopTask?.value }
    private func receive(_ piece: TranscriptPiece) {
        guard running else { return }
        let candidate = TIORealtimeHost.call("voicePrefix",["text":piece.text])
        let prefixed = candidate["matched"] as? Bool == true
        let voicePiece = TranscriptPiece(start:piece.start,end:piece.end,text:candidate["text"] as? String ?? piece.text,final:piece.final)
        if let control = voiceWindow.ingest(voicePiece,prefixed:prefixed) {
            let command = TIORealtimeHost.call("parseVoice",["text":control])
            // An active phone-microphone session only accepts prefixed controls.
            // Keep command text out of both translation and the answer provider.
            if !command.isEmpty {
                if piece.final { cancelVoiceStop(); performVoice(command) }
                else if ["stop","start"].contains(command["action"] as? String ?? "") {
                    let signature = "\(command["action"] ?? ""):\(command["page"] ?? "")"
                    // Repeated identical partials must not postpone the stop forever.
                    if pendingVoiceStop == signature, voiceDebounce != nil { return }
                    cancelVoiceStop(); pendingVoiceStop = signature
                    let version = voiceRevision, epoch = runGeneration
                    status = "Nova command heard…"
                    voiceDebounce = Task { [weak self] in
                        try? await Task.sleep(nanoseconds:700_000_000)
                        guard !Task.isCancelled, let self, self.running,
                              self.voiceRevision == version, self.runGeneration == epoch else { return }
                        self.performVoice(command)
                    }
                } else { cancelVoiceStop() }
                return
            }
            cancelVoiceStop()
            if !control.isEmpty { status = "Waiting for a complete command: Hey Nova, stop or OK Nova, cue now." }
            return
        }
        cancelVoiceStop()
        if mode == .standby { status = "Listening for Hey Nova, OK Nova or N · keep this page open"; return }
        if mode == .translate {
            var work = translationUtterance.ingest(piece)
            work.recognizedAt = ProcessInfo.processInfo.systemUptime
            work.speechDelay = speech.lastRecognitionDelay
            latest = work.text; captions = work.text
            queueTranslation(work)
            refreshHUD(); return
        }
        let sentences = RealtimePolicy.sentences(utterance.ingest(piece))
        let clean = sentences.last ?? ""
        let questionSegment = utterance.sequence*1000 + max(0,sentences.count-1)
        captions = mode == .captions ? String(window.ingest(piece).suffix(700)) : ""
        latest = clean
        if mode == .captions { refreshHUD(); return }
        if piece.final && !piece.text.isEmpty && !closedRanges.contains(piece.start) {
            completedContext.append(piece.text); if completedContext.count > 6 { completedContext.removeFirst() }
            closedRanges.insert(piece.start); if closedRanges.count > 48 { closedRanges = Set(closedRanges.sorted().suffix(24)) }
        }
        // Ordinary conversation contributes private context, never display text
        // or an answer request. Repeated partial/final copies do not reset a timer.
        switch cueGate.consider(clean,segment:questionSegment) {
        case .unchanged: return
        case .retract:
            revision += 1; debounce?.cancel(); cueTask?.cancel(); cueTask = nil
            cueExpiry?.cancel(); output = ""; status = "Listening for a question"; refreshHUD(); return
        case .question: break
        }
        revision += 1; let current = revision
        debounce?.cancel(); cueTask?.cancel(); cueTask = nil; cueExpiry?.cancel()
        output = ""; status = "Question detected…"
        refreshHUD()
        let delay: UInt64 = piece.final ? 40_000_000 : 350_000_000
        debounce = Task { [weak self] in
            try? await Task.sleep(nanoseconds:delay)
            guard !Task.isCancelled, let self, self.running, self.revision == current else { return }
            self.generateCue(clean, revision:current)
        }
    }
    private func cancelVoiceStop() {
        voiceDebounce?.cancel(); voiceDebounce = nil; pendingVoiceStop = nil; voiceRevision += 1
    }
    private func performVoice(_ command: [String:Any]) {
        cancelVoiceStop()
        voiceWindow.consume(); utterance = UtteranceWindow(maxCharacters:300); cueGate = CueQuestionGate()
        if command["page"] as? String == "navigate", command["action"] as? String != "stop" {
            status = "Stop this live tool, then use the glasses assistant to open navigation."; return
        }
        _ = TIORealtimeHost.handleVoiceCommand(command as NSDictionary)
    }
    func askNow() {
        guard running, mode == .cue, !latest.isEmpty else { return }
        revision += 1; debounce?.cancel(); cueExpiry?.cancel(); generateCue(latest,revision:revision)
    }
    func followUp(_ command: String) {
        guard running, mode == .cue, !lastAnswer.isEmpty else { status = "Ask a question in Live Cue first."; return }
        if command == "remember that" {
            do { try NovaLibrary.shared.saveNote(original:lastSubmitted,answer:lastAnswer); status = "Saved locally in Nova notes" }
            catch { status = error.localizedDescription }; return
        }
        if command == "repeat" {
            cueExpiry?.cancel(); output = lastAnswer; refreshHUD()
            let epoch = runGeneration, version = revision
            cueExpiry = Task { [weak self] in
                try? await Task.sleep(nanoseconds:15_000_000_000)
                guard !Task.isCancelled, let self, self.running, self.runGeneration == epoch, self.revision == version else { return }
                self.output = ""; self.refreshHUD()
            }
            return
        }
        let request = command == "shorter" ? "Make the previous answer shorter." : command == "example" ? "Give one concrete example of the previous answer." : "Explain the previous answer in plain language."
        revision += 1; debounce?.cancel(); cueExpiry?.cancel()
        generateCue("Original question: \(lastSubmitted)\nPrevious answer: \(lastAnswer)\nFollow-up: \(request)",revision:revision)
    }
    private func generateCue(_ question: String, revision current: Int) {
        cueTask?.cancel(); lastSubmitted = String(question.prefix(1500)); lastAnswer = ""; output = ""; status = "Thinking…"
        let started = Date(), epoch = runGeneration
        let context = String(completedContext.filter { $0 != question }.suffix(3).joined(separator:"\n").suffix(900))
        cueTask = Task { [weak self] in
            guard let self else { return }
            defer { if self.revision == current && self.runGeneration == epoch { self.cueTask = nil } }
            do {
                var first = true
                let text = try await CueService().answer(question:question,context:context,language:Locale.current.localizedString(forIdentifier:self.source) ?? self.source) { [weak self] text in
                    guard let self, self.running, self.revision == current, self.runGeneration == epoch, !Task.isCancelled else { return }
                    if first { self.timing = String(format:"First cue %.1fs after request",Date().timeIntervalSince(started)); first = false }
                    self.output = text; self.status = "Cue arriving…"; self.refreshHUD()
                }
                guard self.running, self.revision == current, self.runGeneration == epoch, !Task.isCancelled else { return }
                self.lastAnswer = text; self.output = text; self.status = text.isEmpty ? "Listening · no question detected" : "Listening · cue ready"; self.refreshHUD()
                self.cueExpiry = Task { [weak self] in
                    try? await Task.sleep(nanoseconds:15_000_000_000)
                    guard !Task.isCancelled, let self, self.running, self.revision == current, self.runGeneration == epoch else { return }
                    self.output = ""; self.refreshHUD()
                }
            } catch {
                guard self.running, self.revision == current, self.runGeneration == epoch, !Task.isCancelled else { return }
                self.output = ""; self.status = error.localizedDescription; self.refreshHUD()
            }
        }
    }
    private func queueTranslation(_ work: TranslationWork) {
        translationQueue.offer(work)
        if translationEngine == .hymt, translationQueue.shouldAdvance(after:activeTranslationPartial) { hymt.cancel() }
        guard translateTask == nil, !translationQueue.pending.isEmpty else { return }
        let epoch = runGeneration
        // The deadline is not reset by speech. Revisions replace the one pending
        // snapshot. Let a useful preview through before advancing to a newer
        // phrase, so continuous speech cannot cancel every first token forever.
        translateTask = Task { [weak self] in
            guard let self else { return }
            defer { if self.runGeneration == epoch { self.translateTask = nil } }
            while !Task.isCancelled, self.running, self.runGeneration == epoch, !self.translationQueue.pending.isEmpty {
                do {
                    let delay = TranslationQueue.delay(lastStarted:self.translationLastStarted,now:Date.timeIntervalSinceReferenceDate)
                    try await Task.sleep(nanoseconds:UInt64(delay*1_000_000_000))
                    guard !Task.isCancelled, self.running, self.runGeneration == epoch else { return }
                    guard let next = self.translationQueue.take() else { return }
                    self.activeTranslationPartial = ""; self.translationCards.begin(next.segment)
                    let started = Date(); self.translationLastStarted = started.timeIntervalSinceReferenceDate
                    let queued = max(0,ProcessInfo.processInfo.systemUptime-next.recognizedAt)
                    var first = true
                    let update: @MainActor @Sendable (String) -> Void = { [weak self] text in
                        guard let self, self.running, self.runGeneration == epoch, !Task.isCancelled, self.translationQueue.active == next else { return }
                        if first && !text.isEmpty { self.timing = String(format:"Speech lag %.1fs · queue %.1fs · first translation %.1fs",next.speechDelay,queued,Date().timeIntervalSince(started)); first = false }
                        self.translationCards.update(text,segment:next.segment)
                        self.output = self.translationCards.text; self.status = "Listening · translation arriving…"; self.refreshHUD()
                        self.activeTranslationPartial = text
                        if self.translationEngine == .hymt, self.translationQueue.shouldAdvance(after:text) { self.hymt.cancel() }
                    }
                    let text: String
                    if self.translationEngine == .chatGPT {
                        text = try await CueService().translate(text:next.text,source:self.source,target:self.target,update:update)
                    } else if self.translationEngine == .hymt {
                        text = try await self.hymt.translate(next.text,source:self.source,target:self.target,onPartial:update)
                    } else if let session = self.translatedSession { text = try await session.translate(next.text).targetText }
                    else { throw RealtimeError("The offline translation session is unavailable.") }
                    guard !Task.isCancelled, self.running, self.runGeneration == epoch else { return }
                    update(text); self.translationQueue.finish()
                    self.status = "Listening · correcting current phrase"
                } catch {
                    guard !Task.isCancelled, self.runGeneration == epoch else { return }
                    if self.translationEngine == .hymt, let active = self.translationQueue.active, !self.translationQueue.isCurrent(active),
                       error is CancellationError || (error as? HyMTFailure)?.isCancellation == true { self.translationQueue.finish(); continue }
                    // Stop on a provider error instead of retrying on every partial.
                    self.stop("Translation stopped: \(error.localizedDescription)"); return
                }
            }
        }
    }
    private func refreshHUD() {
        let text: String
        if mode == .captions { text = String(captions.suffix(240)) }
        else if mode == .translate { text = String(translationCards.current.suffix(300)) }
        else { text = RealtimePolicy.cueDisplay(output) }
        GlassesDisplay.shared.update(text,owner:id)
    }
}

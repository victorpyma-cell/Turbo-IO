import Foundation
import KokoroCoreML
@main struct KokoroModelTests {
    static func main() throws {
        let engine=try KokoroEngine(modelDirectory:URL(fileURLWithPath:CommandLine.arguments[1]),forceCPU:true)
        for voice in ["af_heart","am_adam"] {
            let audio=try engine.synthesize(text:"Hello. Your assistant is ready to help.",voice:voice,speed:1.1)
            precondition(audio.samples.count > 2400 && audio.samples.count < 24_000*30)
            precondition(audio.samples.allSatisfy { $0.isFinite })
            precondition(audio.samples.contains { abs($0) > 0.001 })
            print("PASS Kokoro CPU synthesis \(voice), \(audio.samples.count) samples, \(audio.synthesisTime) seconds (hosted Mac, not iPhone benchmark)")
        }
    }
}

import SwiftUI
import UIKit
import Translation
import MapKit

@available(iOS 26.0, *)
struct RealtimePanel: View {
    @ObservedObject var session: RealtimeSession
    @State private var confirmStart = false
    @State private var prepareTranslation = false
    var body: some View {
        Form {
            Section {
                Picker("Mode",selection:$session.mode) { ForEach(LiveMode.allCases,id:\.self) { Text($0.rawValue).tag($0) } }.disabled(session.running || session.busy)
                Picker("Speech engine",selection:$session.speechEngine) {
                    ForEach(SpeechEngine.allCases,id:\.self) { Text($0.rawValue).tag($0) }
                }.disabled(session.running || session.busy)
                Picker("Spoken language",selection:$session.source) {
                    ForEach(session.validSpeechLanguages,id:\.self) { Text(SpeechLocalePolicy.label($0)).tag($0) }
                    if !session.validSpeechLanguages.contains(session.source) {
                        Text("\(SpeechLocalePolicy.label(session.source)) · unavailable for this engine").tag(session.source).disabled(true)
                    }
                }.disabled(session.running || session.busy)
                if session.mode == .cue {
                    Text("Provider: \(AssistantPurpose.cue.provider(TIORealtimeHost.call("provider"))["mode"] as? Int == 3 ? "ChatGPT" : "Custom API")").font(.subheadline)
                }
                if session.mode == .translate {
                    Picker("Translation engine",selection:$session.translationEngine) {
                        ForEach(TranslationEngine.allCases,id:\.self) { Text($0.rawValue).tag($0) }
                    }.disabled(session.running || session.busy)
                    Picker("Translate into",selection:$session.target) {
                        ForEach(session.translationLanguages,id:\.self) { Text(SpeechLocalePolicy.label($0)).tag($0) }
                    }.disabled(session.running || session.busy)
                }
                if session.mode != .standby { Toggle("Show on glasses",isOn:$session.showOnGlasses).disabled(session.running || session.busy) }
            } footer: {
                Text("Uses the iPhone microphone for captions. Place the phone where it can hear the conversation. The RayNeo glasses microphone remains part of the original RayNeo Live Cue.")
            }
            if session.mode == .translate && session.translationEngine == .hymt {
                Section { Text("Hy-MT2 translates the current short phrase on this iPhone. Text changes as speech recognition corrects it. Older phrases are replaced, so this is a live view rather than a transcript. No account or API key is needed.").font(.footnote) }
            }
            if !session.running {
                Section("Language setup") {
                    Button("Prepare speech language") { Task { await session.prepareSpeech() } }.disabled(session.busy)
                    if session.mode == .translate && session.translationEngine == .apple {
                        Button("Prepare translation languages") { prepareTranslation = true }.disabled(session.busy)
                    }
                }
            }
            if session.speechEngine == .whisperLocal {
                Section { Text("Whisper base recognizes multiple languages directly on this iPhone. Prepare speech language downloads the model once; recognition then runs locally. Apple or Parakeet can be faster for live use.").font(.footnote) }
            }
            if session.speechEngine == .whisper {
                Section("Private PC recognition") {
                    NavigationLink("Endpoint & API key") { WhisperSettings() }
                    Text("Microphone audio is sent over HTTPS to your private PC in short chunks. Keep the PC and Tailscale connected. Parakeet and Apple recognition stay on the iPhone.").font(.footnote)
                }
            }
            if session.speechEngine == .parakeet {
                Section { Text(session.speechEngine.usesParakeet(session.source) ? "English recognition uses the bundled Parakeet model on this iPhone. Prepare speech language checks the model; no download or API key is needed. Translation uses the engine you select above." : "This spoken language uses Apple recognition. Parakeet is available for English only. Prepare this language's Apple speech model before starting.").font(.footnote) }
            }
            Section {
                Text(session.status).font(.subheadline).accessibilityIdentifier("realtime-status")
                if session.busy { ProgressView() }
                if session.running || session.busy {
                    Button("Stop",role:.destructive) { session.stop() }
                } else {
                    Button("Start \(session.mode.rawValue)") { confirmStart = true }.disabled(!session.validSpeechLanguages.contains(session.source))
                }
                if session.running && session.mode == .cue { Button("Cue for the current question") { session.askNow() } }
            } footer: {
                Text(session.speechEngine == .whisper ? "Audio is sent only to your configured private PC recognition endpoint. Recognized text is then processed by the selected translation or answer provider. No audio recordings are saved." : session.mode == .cue ? "Live Cue sends recognized text to your selected answer provider. Audio stays on the iPhone. Remember that saves the current question and answer locally in Nova notes." : (session.mode == .translate && session.translationEngine == .chatGPT ? "Speech recognition runs on the iPhone. Short text phrases are sent to your selected ChatGPT model and translations stream back as they arrive. Internet and available ChatGPT usage are required. No recordings or transcript files are saved." : "Speech and translation run on the iPhone. Prepare the speech language before starting. Apple translation also requires its language packs; Hy-MT2 is bundled. No recordings or transcript files are saved."))
            }
            if session.mode == .captions || session.mode == .translate {
                Section(session.mode == .translate ? "Current spoken phrase" : "Live captions") { Text(session.captions.isEmpty ? "Speech appears here as it is recognized." : session.captions).textSelection(.enabled).accessibilityIdentifier("realtime-captions") }
            }
            if session.mode == .cue || session.mode == .translate {
                Section(session.mode == .cue ? "Suggested cue" : "Translation") {
                    Text(session.output.isEmpty ? (session.mode == .cue ? "Listening for a question…" : "Waiting for speech…") : session.output).font(.title3).textSelection(.enabled).accessibilityIdentifier("realtime-output")
                    if !session.timing.isEmpty { Text(session.timing).font(.caption).foregroundStyle(.secondary) }
                }
            }
            Section("Voice commands") {
                Text("Wake the glasses assistant, then say start Live Cue, start translation, or start captions. Keep RayNeo AI open on the iPhone. Prepare languages and your answer provider first.")
                Text("Start Listen for Nova once, then keep this page open. Say Hey Nova, start translation; OK Nova, start Live Cue; or N, start captions. During Live Cue: Hey Nova, shorter; explain; example; repeat; or remember that. Hey Nova, stop ends listening. Nova listens through the iPhone microphone only while this page is active. It cannot wake a closed app or replace the glasses’ firmware wake word.")
            }.font(.footnote)
            Section { Text("One glasses session at a time, up to 20 minutes. Starting the glasses voice assistant ends the current Turbo session. Leaving this page ends the session; audio or connection interruptions also stop it.").font(.footnote).foregroundStyle(.secondary) }
        }
        .navigationTitle("Live tools")
        .task(id:session.translationEngine) { await session.loadLanguages() }
        .task(id:session.speechEngine) { await session.loadLanguages() }
        .onDisappear { TIORealtimeHost.closeLivePage() }
        .onReceive(NotificationCenter.default.publisher(for:UIApplication.willResignActiveNotification)) { _ in TIORealtimeHost.closeLivePage() }
        .alert("Ready to start?",isPresented:$confirmStart) {
            Button("Cancel",role:.cancel) {}
            Button("Start") { session.start() }
        } message: { Text(session.showOnGlasses ? "End any active recording, Live Cue, translation, or navigation on the glasses. Once they show the home screen, tap Start." : "End any other recording in the RayNeo app, then tap Start. This session will show text on the phone.") }
        .sheet(isPresented:$prepareTranslation) { LanguagePreparation(source:session.source,target:session.target) }
    }
}

@available(iOS 26.0, *)
struct LanguagePreparation: View {
    let source: String, target: String
    @State private var config: TranslationSession.Configuration?
    @State private var status = "Apple will ask to download any missing language packs."
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            VStack(spacing:24) {
                Image(systemName:"character.bubble").font(.largeTitle)
                Text("\(Locale.current.localizedString(forIdentifier:source) ?? source) → \(Locale.current.localizedString(forIdentifier:target) ?? target)").font(.headline)
                Text(status)
                Button("Prepare languages") { config = .init(source:Locale.Language(identifier:source),target:Locale.Language(identifier:target)); config?.invalidate() }.buttonStyle(.borderedProminent)
            }.padding().navigationTitle("Translation languages")
                .toolbar { ToolbarItem(placement:.confirmationAction) { Button("Done") { dismiss() } } }
        }.translationTask(config) { session in
            do { try await session.prepareTranslation(); status = "Languages are ready for on-device translation." }
            catch { status = "This language pair is unavailable or its download was cancelled." }
        }
    }
}

@available(iOS 26.0, *)
struct AccountPanel: View {
    @ObservedObject private var account = ChatGPTAccount.shared
    @ObservedObject private var search = VoiceSearchState.shared
    private func presenter() -> UIViewController? {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first { $0.activationState == .foregroundActive }
        var root = scene?.windows.first(where: \.isKeyWindow)?.rootViewController
        while let presented = root?.presentedViewController { root = presented }
        return root
    }
    var body: some View {
        Form {
            Section {
                Text(account.status)
                Button("Continue with ChatGPT") {
                    guard let host = presenter() else { return }
                    Task { await account.signIn(presenter:host) }
                }.disabled(account.signingIn)
                if account.signingIn { Button("Cancel sign-in") { account.cancelSignIn() } }
            } footer: {
                Text("Uses OpenAI's ChatGPT plan-sharing sign-in. Availability and usage limits depend on your account. This connects Turbo IO directly; it does not read the ChatGPT app's chats or memory.")
            }
            if account.isSignedIn {
                Section("ChatGPT model") {
                    Picker("Model",selection:$account.selectedModel) {
                        ForEach(account.models,id:\.id) { model in Text(model.name).tag(Optional(model.id)) }
                    }
                    Button("Refresh model list") { Task { do { try await account.loadModels() } catch { account.status = error.localizedDescription } } }
                    Text("Used for streamed translation, Live Cue and ChatGPT voice answers. Choose ChatGPT under Answer provider for ordinary glasses questions. Only models available to your account are listed.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("Glasses voice · live search") {
                    Toggle("Search the web for current questions", isOn: $search.enabled)
                    Text("Applies to ChatGPT glasses voice answers. Live Cue, translation and Strata keep their existing routes. Search availability depends on the selected model and account.").font(.footnote)
                    Button("Test live search") { search.testSearch() }
                    Text(search.status).font(.footnote)
                    if !search.answer.isEmpty { Text(search.answer).textSelection(.enabled) }
                    ForEach(search.sources) { source in Link(source.title.isEmpty ? source.url.absoluteString : source.title, destination: source.url) }
                }
                Section("Voice connection diagnostics") {
                    Text("Recent events stay in memory. Bluetooth audio status does not measure the glasses' separate data connection. Background time is limited by iOS.").font(.footnote)
                    ForEach(Array(search.events.enumerated()), id: \.offset) { _, event in Text(event).font(.caption).textSelection(.enabled) }
                    Button("Clear recent answer and diagnostics") { search.clear() }
                }
                Section { Button("Disconnect ChatGPT",role:.destructive) { account.signOut(); search.clear() } }
            }
        }.navigationTitle("ChatGPT account")
            .task { if account.isSignedIn { do { try await account.loadModels() } catch { account.status = error.localizedDescription } } }
    }
}

@available(iOS 26.0, *)
struct NavigationPanel: View {
    @ObservedObject var nav: AppleNavigation
    @State private var confirmStart = false
    var body: some View {
        Form {
            if let route = nav.route {
                Map {
                    MapPolyline(route.polyline).stroke(.blue,lineWidth:5)
                    UserAnnotation()
                    if let destination = nav.destination { Marker(destination.name ?? "Destination",coordinate:destination.placemark.coordinate) }
                }.frame(height:220).listRowInsets(EdgeInsets())
            }
            if !nav.running && !nav.acquiring {
                Section("Destination") {
                    TextField("Place or address",text:$nav.query).submitLabel(.search).onSubmit { Task { await nav.findPlaces() } }
                    Button("Search") { Task { await nav.findPlaces() } }.disabled(nav.busy || nav.query.isEmpty)
                    if nav.busy { ProgressView() }
                    ForEach(Array(nav.places.enumerated()),id:\.offset) { _, place in
                        Button { nav.destination = place; nav.places = []; nav.status = "Destination selected" } label: {
                            VStack(alignment:.leading) { Text(place.name ?? "Place"); Text(place.placemark.title ?? "").font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                    if let destination = nav.destination { Text(destination.name ?? "Selected destination").font(.headline); Text(destination.placemark.title ?? "").font(.caption) }
                    Picker("Travel mode",selection:$nav.walking) { Text("Walking").tag(true); Text("Driving").tag(false) }.pickerStyle(.segmented)
                    Toggle("Show on glasses",isOn:$nav.showOnGlasses)
                }
            }
            Section {
                Text(nav.status).font(.subheadline)
                if !nav.distance.isEmpty {
                    Text(nav.turn.rawValue).font(.title.bold())
                    Text(nav.distance).font(.largeTitle.bold())
                }
                if !nav.instruction.isEmpty { Text(nav.instruction).font(.title3) }
                if !nav.tripSummary.isEmpty { Text(nav.tripSummary).font(.subheadline).foregroundStyle(.secondary) }
                if nav.running || nav.acquiring { Button("End navigation",role:.destructive) { nav.stop() } }
                else { Button("Start directions") { confirmStart = true }.disabled(nav.destination == nil) }
            } footer: { Text("The glasses show a turn arrow, distance, road instruction and remaining trip estimate. Directions come from Apple Maps and advance with GPS. Arrival estimates use remaining route distance. Route calculation needs internet access.") }
            if nav.destination != nil {
                Section {
                    Button("Open destination in Google Maps") { nav.stop(); nav.openGoogleMaps() }
                } footer: { Text("Opens Google Maps on your phone. Google Maps does not send its live turns back to this app; starting it ends Turbo IO directions.") }
            }
            Section("Voice commands") {
                Text("With RayNeo AI open, wake the glasses assistant and say navigate to followed by a place. Confirm the destination from the results, then say start navigation. Wake the assistant and say stop navigation to end directions.").font(.footnote)
            }
        }.navigationTitle("Navigate")
            .onDisappear { TIORealtimeHost.closeNavigationPage() }
            .alert("Start directions?",isPresented:$confirmStart) {
                Button("Cancel",role:.cancel) {}
                Button("Start") { nav.start() }
            } message: { Text("End any active feature on the glasses and return them to the home screen. Location is used while navigation is active.") }
    }
}

@available(iOS 26.0, *)
struct WhisperSettings: View {
    @State private var endpoint=WhisperConnection.endpoint
    @State private var key="",notice="",busy=false
    var body: some View {
        Form {
            Section("Private PC connection") {
                TextField("https://your-pc/asr",text:$endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                SecureField("API key (blank keeps saved key)",text:$key)
                Button("Save & test") {
                    busy=true;notice="Checking…"
                    Task {
                        do { WhisperConnection.endpoint=endpoint.trimmingCharacters(in:.whitespacesAndNewlines);try WhisperConnection.saveKey(key);key="";try await WhisperConnection.check();notice="Private faster-whisper is ready." }
                        catch { notice=error.localizedDescription }
                        busy=false
                    }
                }.disabled(busy)
                Text(notice).font(.footnote)
            }
        }.navigationTitle("Faster-whisper")
    }
}

import Foundation
import Security
import CryptoKit

enum TokenValidation {
    static func base64URL(_ data: Data) -> String { data.base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "") }
    static func decode(_ text: String) -> Data? {
        let s = text.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        return Data(base64Encoded: s + String(repeating: "=", count: (4-s.count%4)%4))
    }
    static func random() throws -> String {
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else { throw Failure.invalid }
        return base64URL(Data(bytes))
    }
    enum Failure: Error { case invalid }
    private static func der(_ tag: UInt8, _ bytes: Data) -> Data {
        let length: Data
        if bytes.count < 128 { length = Data([UInt8(bytes.count)]) }
        else if bytes.count < 256 { length = Data([0x81, UInt8(bytes.count)]) }
        else { length = Data([0x82, UInt8(bytes.count >> 8), UInt8(bytes.count & 255)]) }
        return Data([tag])+length+bytes
    }
    static func verify(_ token: String, jwks: [[String: Any]], audience: String, nonce: String?, now: TimeInterval = Date().timeIntervalSince1970) throws -> [String: Any] {
        let parts = token.split(separator: ".", omittingEmptySubsequences: false).map(String.init)
        guard token.count < 32768, parts.count == 3,
              let headerData = decode(parts[0]), let payload = decode(parts[1]), let signature = decode(parts[2]),
              let header = try JSONSerialization.jsonObject(with: headerData) as? [String: Any],
              let claims = try JSONSerialization.jsonObject(with: payload) as? [String: Any],
              let kid = header["kid"] as? String, let alg = header["alg"] as? String,
              header["crit"] == nil,
              let jwk = jwks.first(where: { ($0["kid"] as? String) == kid }),
              jwk["use"] == nil || jwk["use"] as? String == "sig",
              jwk["alg"] == nil || jwk["alg"] as? String == alg else { throw Failure.invalid }
        let message = Data((parts[0]+"."+parts[1]).utf8)
        var verified = false
        if alg == "RS256", jwk["kty"] as? String == "RSA",
           let n = jwk["n"] as? String, var modulus = decode(n), modulus.count >= 256, modulus.count <= 1024,
           let e = jwk["e"] as? String, var exponent = decode(e), exponent.count <= 8, !exponent.isEmpty {
            if modulus.first! & 128 != 0 { modulus.insert(0, at: 0) }
            if exponent.first! & 128 != 0 { exponent.insert(0, at: 0) }
            let bytes = der(0x30, der(0x02,modulus)+der(0x02,exponent))
            let attributes: [String: Any] = [kSecAttrKeyType as String:kSecAttrKeyTypeRSA, kSecAttrKeyClass as String:kSecAttrKeyClassPublic]
            if let key = SecKeyCreateWithData(bytes as CFData, attributes as CFDictionary, nil) {
                verified = SecKeyVerifySignature(key, .rsaSignatureMessagePKCS1v15SHA256, message as CFData, signature as CFData, nil)
            }
        } else if alg == "ES256", jwk["kty"] as? String == "EC", jwk["crv"] as? String == "P-256",
                  let x = jwk["x"] as? String, let y = jwk["y"] as? String, let xb = decode(x), let yb = decode(y), xb.count == 32, yb.count == 32 {
            let key = try P256.Signing.PublicKey(x963Representation: Data([4])+xb+yb)
            verified = key.isValidSignature(try P256.Signing.ECDSASignature(rawRepresentation: signature), for: message)
        }
        let aud = (claims["aud"] as? [String]) ?? ((claims["aud"] as? String).map { [$0] } ?? [])
        guard verified, claims["iss"] as? String == "https://auth.openai.com", aud.contains(audience),
              let sub = claims["sub"] as? String, !sub.isEmpty,
              let expiry = claims["exp"] as? Double, expiry > now-5,
              let issued = claims["iat"] as? Double, issued <= now+5,
              (claims["nbf"] as? Double ?? 0) <= now+5,
              nonce == nil || claims["nonce"] as? String == nonce,
              aud.count <= 1 || claims["azp"] as? String == audience else { throw Failure.invalid }
        return claims
    }
}

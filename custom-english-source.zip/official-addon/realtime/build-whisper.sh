#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
root="$PWD/build/essentials/whisper"
revision=a8a40c9444ae4e7263bd41e5e60b35a92e2cbba3
mkdir -p "$root"
git clone https://github.com/argmaxinc/WhisperKit.git "$root/WhisperKit"
git -C "$root/WhisperKit" checkout --detach "$revision"
xcrun swift build --package-path "$root/WhisperKit" --scratch-path "$root/build" \
  --configuration release --build-system swiftbuild --triple arm64-apple-ios26.0 \
  --sdk "$(xcrun --sdk iphoneos --show-sdk-path)" --product WhisperKit
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('build/essentials/whisper')
matches=list((root/'build').rglob('Release-iphoneos/WhisperKit.o'))
assert len(matches)==1
products=matches[0].parent
(root/'products-path.txt').write_text(str(products.resolve()))
for p in products.glob('*.bundle'):
    shutil.copytree(p,Path('build/essentials/resources')/p.name,dirs_exist_ok=True)
PY

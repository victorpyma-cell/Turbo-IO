#import "RealtimeHost.h"
#import "Core.h"
#import "ProtocolContext.h"
#import "SubtitleHUD.h"
#import "NavigationSubtitleHUD.h"
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>

static void (*PreviousMethod)(id,SEL,id,id);
static void (*PreviousSend)(id,SEL,id,id,id);
static id Field(id o,NSString *key){@try{return [o valueForKey:key];}@catch(NSException *e){return nil;}}
static BOOL Signature(Method m,unsigned n){
    if(!m||method_getNumberOfArguments(m)!=n)return NO;
    char t[8];method_getReturnType(m,t,sizeof(t));if(strcmp(t,"v"))return NO;
    for(unsigned i=2;i<n;i++){method_getArgumentType(m,i,t,sizeof(t));if(t[0]!='@')return NO;}return YES;
}
static void MethodObserver(id self,SEL cmd,id call,id result){
    NSString *method=Field(call,@"method");id args=Field(call,@"arguments");
    if([method isKindOfClass:NSString.class]&&[args isKindOfClass:NSDictionary.class]){
        void(^observe)(void)=^{TIOProtocolObserveCall(self,method,args);TIOSubtitleObserveCall(self,method,args);};
        if(NSThread.isMainThread)observe();else dispatch_async(dispatch_get_main_queue(),observe);
    }
    PreviousMethod(self,cmd,call,result);
}
static void EventObserver(id self,SEL cmd,NSString *channel,NSData *message,id reply){
    if([channel isKindOfClass:NSString.class]&&[channel.lowercaseString containsString:@"rayneonet"]&&[message isKindOfClass:NSData.class]&&message.length<262144){
        @try{
            Class cls=NSClassFromString(@"FlutterStandardMethodCodec");
            id codec=[cls respondsToSelector:NSSelectorFromString(@"sharedInstance")]?((id(*)(id,SEL))objc_msgSend)(cls,NSSelectorFromString(@"sharedInstance")):nil;
            if([codec respondsToSelector:NSSelectorFromString(@"decodeEnvelope:")]){
                id event=((id(*)(id,SEL,id))objc_msgSend)(codec,NSSelectorFromString(@"decodeEnvelope:"),message);
                if([event isKindOfClass:NSDictionary.class]){
                    NSMutableDictionary *e=[event mutableCopy];id incoming=e[@"message"];
                    if([incoming isKindOfClass:NSDictionary.class]){NSMutableDictionary *m=[incoming mutableCopy];id payload=m[@"payload"],data=[payload isKindOfClass:NSData.class]?payload:Field(payload,@"data");if([data isKindOfClass:NSData.class])m[@"payload"]=data;e[@"message"]=m;}
                    dispatch_async(dispatch_get_main_queue(),^{TIOProtocolObserveEvent(e);TIOSubtitleObserveEvent(e);});
                }
            }
        }@catch(NSException *e){} // An unknown event remains entirely the host's responsibility.
    }
    PreviousSend(self,cmd,channel,message,reply);
}
void TIOInstallRealtimeObserver(void){
    if(PreviousMethod)return;
    Method m=class_getInstanceMethod(NSClassFromString(@"rayneo_venus_sdk_plugin.RayneoNetPluginBridge"),NSSelectorFromString(@"handleMethodCall:result:"));
    Method s=class_getInstanceMethod(NSClassFromString(@"FlutterEngine"),NSSelectorFromString(@"sendOnChannel:message:binaryReply:"));
    if(!Signature(m,4)||!Signature(s,5))return;
    PreviousMethod=(void *)method_setImplementation(m,(IMP)MethodObserver);
    PreviousSend=(void *)method_setImplementation(s,(IMP)EventObserver);
}
static Class LoadRealtime(void){
    static void *handle;
    if(@available(iOS 26.0,*)){
        if(!handle)handle=dlopen([[NSBundle.mainBundle.privateFrameworksPath stringByAppendingPathComponent:@"TurboRealtime.dylib"] fileSystemRepresentation],RTLD_NOW|RTLD_LOCAL);
        if(handle)return NSClassFromString(@"TIORealtimeHost");
    }
    return Nil;
}
BOOL TIOChatGPTReady(void){
    Class bridge=LoadRealtime();SEL ready=NSSelectorFromString(@"chatGPTReady");
    return [bridge respondsToSelector:ready]&&((BOOL(*)(id,SEL))objc_msgSend)(bridge,ready);
}
id TIOStartChatGPTAnswer(NSString *question,NSArray<NSDictionary *> *history,void (^update)(NSString *,BOOL,NSString *)){
    Class bridge=LoadRealtime();SEL start=NSSelectorFromString(@"startChatGPTQuestion:history:update:");
    if([bridge respondsToSelector:start])return ((id(*)(id,SEL,id,id,id))objc_msgSend)(bridge,start,question,history,[update copy]);
    return nil;
}
id TIOStartChatGPTNewsAnswer(NSString *question,void (^update)(NSString *,BOOL,NSString *)){
    Class bridge=LoadRealtime();SEL start=NSSelectorFromString(@"startChatGPTNews:update:");
    if([bridge respondsToSelector:start])return ((id(*)(id,SEL,id,id))objc_msgSend)(bridge,start,question,[update copy]);
    return nil;
}
static Class ConfigureRealtime(NSDictionary *(^provider)(void)){
        Class bridge=LoadRealtime();SEL configure=NSSelectorFromString(@"configure:");
        if([bridge respondsToSelector:configure]){
            NSDictionary *(^callback)(NSString *,NSDictionary *)=^NSDictionary *(NSString *op,NSDictionary *args){
                if(!NSThread.isMainThread)return @{};
                if([op isEqual:@"provider"])return provider?provider():@{};
                if([op isEqual:@"parseVoice"])return TIORealtimeVoiceCommand(args[@"text"],YES)?:@{};
                if([op isEqual:@"voicePrefix"]){NSString *fragment=TIORealtimeVoiceFragment(args[@"text"]);return fragment?@{@"matched":@YES,@"text":fragment}:@{@"matched":@NO};}
                if([op isEqual:@"status"])return TIOSubtitleNavigationStatus();
                if([op isEqual:@"start"]){if(!TIOSubtitleConfirmIdle())return @{};return @{@"sid":TIOSubtitleLiveCaptionStart()?:@""};}
                NSString *sid=[args[@"sid"] isKindOfClass:NSString.class]?args[@"sid"]:@"";
                if([op isEqual:@"text"]&&[args[@"text"] isKindOfClass:NSString.class])return @{@"ok":@(TIOSubtitleNavigationText(sid,args[@"text"]))};
                if([op isEqual:@"stop"])TIOSubtitleNavigationStop(sid,@"Session ended");return @{};
            };
            ((void(*)(id,SEL,id))objc_msgSend)(bridge,configure,[callback copy]);
            return bridge;
        }
    return Nil;
}
static void PresentRealtime(UIViewController *presenter,UIViewController *controller){
    if(!presenter||!controller||controller.view.window)return;
    if(controller.navigationController){[controller.navigationController popToViewController:controller animated:YES];return;}
    UINavigationController *nav=[presenter isKindOfClass:UINavigationController.class]?(id)presenter:presenter.navigationController;
    if(!nav&&[presenter isKindOfClass:UITabBarController.class]){id selected=((UITabBarController *)presenter).selectedViewController;if([selected isKindOfClass:UINavigationController.class])nav=selected;}
    if(nav){[nav pushViewController:controller animated:YES];return;}
    [presenter presentViewController:[[UINavigationController alloc]initWithRootViewController:controller] animated:YES completion:nil];
}
static void ModuleUnavailable(UIViewController *presenter){
    if(!presenter||UIApplication.sharedApplication.applicationState!=UIApplicationStateActive)return;
    UIAlertController *a=[UIAlertController alertControllerWithTitle:@"Realtime module unavailable" message:@"This build requires iOS 26 or later and the TurboRealtime module." preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];[presenter presentViewController:a animated:YES completion:nil];
}
void TIOOpenRealtime(UIViewController *presenter,NSString *page,NSDictionary *(^provider)(void)){
    Class bridge=ConfigureRealtime(provider);SEL make=NSSelectorFromString(@"makeController:");
    if([bridge respondsToSelector:make]){id controller=((id(*)(id,SEL,id))objc_msgSend)(bridge,make,page);if([controller isKindOfClass:UIViewController.class]){PresentRealtime(presenter,controller);return;}}
    ModuleUnavailable(presenter);
}
void TIOHandleRealtimeVoiceCommand(UIViewController *presenter,NSDictionary *command,NSDictionary *(^provider)(void)){
    Class bridge=ConfigureRealtime(provider);SEL handle=NSSelectorFromString(@"handleVoiceCommand:");
    if([bridge respondsToSelector:handle]){id controller=((id(*)(id,SEL,id))objc_msgSend)(bridge,handle,command);if([controller isKindOfClass:UIViewController.class])PresentRealtime(presenter,controller);return;}
    ModuleUnavailable(presenter);
}
void TIORealtimeOfficialAudioStarted(void){
    // Do not load the module merely because ordinary RayNeo speech began.
    Class bridge=NSClassFromString(@"TIORealtimeHost");SEL stop=NSSelectorFromString(@"officialAudioStarted");
    if([bridge respondsToSelector:stop])((void(*)(id,SEL))objc_msgSend)(bridge,stop);
}

UIViewController *TIOCreateRealtimeController(NSString *page,NSDictionary *(^provider)(void)){
    Class bridge=ConfigureRealtime(provider);SEL make=NSSelectorFromString(@"makeController:");
    if([bridge respondsToSelector:make]){id c=((id(*)(id,SEL,id))objc_msgSend)(bridge,make,page);if([c isKindOfClass:UIViewController.class])return c;}return nil;
}

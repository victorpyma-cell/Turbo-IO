import Foundation

enum SpeechEngine: String, CaseIterable {
    case whisperLocal = "Whisper · on iPhone (multilingual)"
    case apple = "Apple · on device", parakeet = "Parakeet English · Apple other languages", whisper = "Faster-whisper · Private PC"
    func usesParakeet(_ language: String) -> Bool {
        self == .parakeet && SpeechLocalePolicy.key(language).split(separator:"-").first == "en"
    }
}

struct ParakeetTimeline {
    private var start = 0.0
    mutating func ingest(_ text: String, final: Bool, processed: Double) -> TranscriptPiece {
        let end = max(start, processed)
        let piece = TranscriptPiece(start:start,end:end,text:text,final:final)
        if final { start = end }
        return piece
    }
}

enum AssistantPurpose: String {
    case cue = "cueMode", nova = "novaMode", meeting = "meetingMode"
    var label: String { self == .cue ? "Live Cue" : self == .meeting ? "Meeting Copilot" : "Nova Q&A" }
    // Tools default to the configured local API independently of glasses voice.
    // An invalid explicit choice fails validation rather than changing providers.
    func provider(_ configuration: [String:Any]) -> [String:Any] {
        var selected = configuration
        selected["mode"] = configuration[rawValue] as? Int ?? 2
        return selected
    }
}

enum SpeechLocalePolicy {
    static func key(_ identifier: String) -> String { identifier.replacingOccurrences(of:"_",with:"-").lowercased() }
    static func unique(_ identifiers: [String]) -> [String] {
        var seen = Set<String>()
        return identifiers.sorted().filter { seen.insert(key($0)).inserted }
    }
    static func label(_ identifier: String) -> String {
        let parts = key(identifier).split(separator:"-").map(String.init)
        guard let language = parts.first else { return identifier }
        let cantonese = language == "yue" || (language == "zh" && parts.dropFirst().first == "yue")
        let name = cantonese ? "Cantonese" : (["zh","cmn"].contains(language) ? "Chinese" : (Locale.current.localizedString(forLanguageCode:language) ?? language))
        var labels = [name]
        if parts.contains("hans") { labels.append("Simplified") }
        if parts.contains("hant") { labels.append("Traditional") }
        if let region = parts.dropFirst().first(where:{ $0.count == 2 || ($0.count == 3 && $0.allSatisfy(\.isNumber)) }) {
            labels.append(Locale.current.localizedString(forRegionCode:region.uppercased()) ?? region.uppercased())
        }
        return labels.joined(separator:" · ")
    }
}

// Pure policy shared with the macOS replay tests. No microphone or network here.
enum RealtimePolicy {
    static func clean(_ value: String) -> String {
        value.split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }
    static func isQuestion(_ value: String) -> Bool {
        let s = clean(value).lowercased()
        if s.count < 4 { return false }
        if s.contains("?") || s.contains("？") { return true }
        let prefixes = ["what ", "why ", "how ", "when ", "where ", "who ", "which ",
                        "can you ", "could you ", "would you ", "do you ", "does ",
                        "will ", "should ", "was ", "were ", "have you ", "has ",
                        "is it ", "are you ", "tell me ", "explain ", "describe ",
                        "什么", "为什么", "怎么", "如何", "请问", "请解释",
                        "點解", "点解", "點樣", "点样", "邊個", "边个", "乜嘢"]
        return prefixes.contains { s.hasPrefix($0) } || ["吗", "嗎", "咩"].contains { s.hasSuffix($0) }
    }
    static func cueCandidate(_ value: String, final: Bool) -> Bool {
        let s = clean(value)
        return s.count >= 4 && isQuestion(s)
    }
    static func questionKey(_ value: String) -> String {
        clean(value.lowercased().filter { !$0.isPunctuation })
    }
    static func cueDisplay(_ answer: String) -> String { hud(answer, bytes: 360) }
    static func sentences(_ text: String) -> [String] {
        var result: [String] = [], current = ""
        let chars = Array(text)
        for (i, char) in chars.enumerated() {
            current.append(char)
            let end = "!?。！？;；".contains(char) || (char == "." && (i+1 == chars.count || chars[i+1].isWhitespace))
            if end { result.append(clean(current)); current = "" }
        }
        if !clean(current).isEmpty { result.append(clean(current)) }
        return result
    }
    static func hud(_ value: String, bytes: Int = 360) -> String {
        var out = ""
        for c in value {
            if out.utf8.count + String(c).utf8.count > bytes - 3 { return out + "…" }
            out.append(c)
        }
        return out
    }
}

struct TranscriptPiece: Equatable {
    let start: Double
    let end: Double
    let text: String
    let final: Bool
}

struct TranscriptWindow {
    private(set) var pieces: [TranscriptPiece] = []
    mutating func ingest(_ piece: TranscriptPiece) -> String {
        guard piece.start.isFinite, piece.end.isFinite, piece.end >= piece.start else { return text }
        // Volatile ranges replace overlapping guesses; they are never appended as new speech.
        pieces.removeAll { old in
            let overlap = old.start < piece.end + 0.001 && old.end > piece.start - 0.001
            return overlap && (!old.final || (piece.start <= old.start + 0.001 && piece.end >= old.end - 0.001))
        }
        if !pieces.contains(where: { $0.final && abs($0.start-piece.start) < 0.001 && abs($0.end-piece.end) < 0.001 }) {
            pieces.append(piece)
        }
        pieces.sort { $0.start < $1.start }
        if pieces.count > 24 { pieces.removeFirst(pieces.count-24) }
        return text
    }
    var text: String { RealtimePolicy.clean(pieces.map(\.text).joined(separator: " ")) }
    mutating func reset() { pieces.removeAll() }
}

struct UtteranceWindow {
    private(set) var sequence = 0
    private let maxCharacters: Int
    init(maxCharacters: Int = 1500) { self.maxCharacters = maxCharacters }
    private var window = TranscriptWindow()
    private var lastEnd = 0.0
    private var boundary = false
    mutating func ingest(_ piece: TranscriptPiece) -> String {
        if piece.start > lastEnd+0.85 || (boundary && piece.start >= lastEnd-0.001) || window.text.count > 1500 {
            window.reset(); boundary = false; sequence += 1
        }
        let text = window.ingest(piece)
        lastEnd = max(lastEnd,piece.end)
        if piece.final, let last = text.last { boundary = ".!?。！？".contains(last) || text.count >= maxCharacters }
        return text
    }
}

struct TranslationWork: Equatable {
    let segment: Int
    let text: String
    var recognizedAt: Double = 0
    var speechDelay: Double = 0
    static func == (a: Self, b: Self) -> Bool { a.segment == b.segment && a.text == b.text }
}

struct CueQuestionGate {
    enum Decision { case unchanged, question, retract }
    private var last: TranslationWork?
    mutating func consider(_ text: String, segment: Int) -> Decision {
        guard RealtimePolicy.cueCandidate(text,final:false) else {
            if last?.segment == segment { last = nil; return .retract }
            return .unchanged
        }
        if let last, last.segment == segment,
           RealtimePolicy.questionKey(last.text) == RealtimePolicy.questionKey(text) { return .unchanged }
        last = TranslationWork(segment:segment,text:text)
        return .question
    }
}

// Translate the current sentence/chunk, including volatile ASR corrections.
// Long unpunctuated speech advances in bounded chunks instead of growing forever.
struct TranslationPhraseWindow {
    private var utterance = UtteranceWindow(maxCharacters: 120)
    private var scope = ""
    private var sequence = 0
    mutating func ingest(_ piece: TranscriptPiece) -> TranslationWork {
        let full = utterance.ingest(piece)
        let sentences = RealtimePolicy.sentences(full)
        let sentence = RealtimePolicy.clean(sentences.last ?? full)
        let words = sentence.split(whereSeparator: { $0.isWhitespace })
        let cjk = sentence.unicodeScalars.contains { (0x3400...0x9fff).contains($0.value) || (0x3040...0x30ff).contains($0.value) }
        let chunk: Int, phrase: String
        if cjk {
            chunk = max(0,(sentence.count-1)/48)
            phrase = String(sentence.dropFirst(max(0,chunk*48-6)).prefix(54))
        } else {
            chunk = max(0,(words.count-1)/12)
            phrase = words.dropFirst(max(0,chunk*12-2)).prefix(14).joined(separator:" ")
        }
        let newScope = "\(utterance.sequence):\(max(0,sentences.count-1)):\(chunk)"
        if newScope != scope { sequence += 1; scope = newScope }
        return TranslationWork(segment:sequence,text:String(phrase.suffix(160)))
    }
}

// One active inference plus one replaceable latest snapshot. Never drain a FIFO
// of old sentences while someone is still speaking.
struct TranslationQueue {
    private(set) var pending: [TranslationWork] = []
    private(set) var active: TranslationWork?
    private var last: TranslationWork?
    private(set) var skipped = false
    private(set) var latestSegment = -1
    mutating func offer(_ work: TranslationWork) {
        guard !work.text.isEmpty else { return }
        guard work.segment >= latestSegment else { return }
        latestSegment = work.segment
        if work == active || work == last { pending.removeAll { $0.segment == work.segment }; return }
        if pending.contains(where: { $0.segment != work.segment }) { skipped = true }
        pending = [work]
    }
    mutating func take() -> TranslationWork? {
        guard active == nil, !pending.isEmpty else { return nil }
        active = pending.removeFirst(); return active
    }
    mutating func finish() { last = active; active = nil }
    func isCurrent(_ work: TranslationWork) -> Bool { work.segment == latestSegment }
    func shouldAdvance(after partial: String) -> Bool {
        guard let active, !isCurrent(active) else { return false }
        return RealtimePolicy.clean(partial).count >= 12
    }
    static func delay(lastStarted: Double, now: Double) -> Double { max(0.08, lastStarted + 0.25 - now) }
}

struct TranslationCards {
    private var latestSegment = -1
    private(set) var current = ""
    mutating func begin(_ segment: Int) { latestSegment = max(latestSegment,segment) }
    mutating func update(_ text: String, segment: Int) {
        guard segment >= latestSegment else { return }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        latestSegment = segment; current = text
    }
    var text: String { current }
}

enum TurnDirection: String {
    case straight = "↑ CONTINUE", left = "← LEFT", right = "→ RIGHT"
    case slightLeft = "↖ BEAR LEFT", slightRight = "↗ BEAR RIGHT"
    case uturn = "↶ U-TURN", roundabout = "↻ ROUNDABOUT", arrive = "● ARRIVE"
    static func angle(_ degrees: Double) -> TurnDirection {
        if abs(degrees) >= 155 { return .uturn }
        if degrees >= 45 { return .left }; if degrees <= -45 { return .right }
        if degrees >= 20 { return .slightLeft }; if degrees <= -20 { return .slightRight }
        return .straight
    }
}
struct NavigationStep { let at: Double; let text: String; let turn: TurnDirection }
enum NavigationPolicy {
    static func next(_ steps: [NavigationStep], progress: Double) -> NavigationStep? {
        // Keep the turn visible until it is crossed, rather than skipping it 8 m early.
        steps.first { $0.at > 1 && $0.at >= progress - 4 }
    }
    static func distance(_ metres: Double) -> String {
        let m = max(0,metres)
        return m >= 1000 ? String(format: "%.1f km",m/1000) : "\(Int((m/5).rounded())*5) m"
    }
}

// Speech can finalize "Turbo," separately from "stop translation". Keep a
// short command window independent of sentence punctuation and normal captions.
struct VoiceCommandWindow {
    private var window = TranscriptWindow()
    private var began: Double?
    private var lastEnd = 0.0
    private var consumedEnd = -1.0
    mutating func ingest(_ piece: TranscriptPiece, prefixed: Bool) -> String? {
        guard piece.start.isFinite, piece.end.isFinite, piece.end >= piece.start else { return nil }
        if piece.end <= consumedEnd + 0.001 { return "" }
        if let began, piece.start > lastEnd + 1.2 || piece.end - began > 6 {
            self.began = nil; window.reset()
        }
        if began == nil {
            guard prefixed else { return nil }
            began = piece.start; window.reset()
        }
        lastEnd = max(lastEnd,piece.end)
        return window.ingest(piece)
    }
    mutating func consume() {
        consumedEnd = lastEnd; began = nil; window.reset()
    }
}

struct XY: Equatable { let x: Double; let y: Double }
struct RouteProjection {
    let distance: Double
    let progress: Double
}
enum RouteGeometry {
    static func turn(at distance: Double, points: [XY]) -> TurnDirection {
        func point(_ target: Double) -> XY? {
            guard let first = points.first else { return nil }
            var total = 0.0, previous = first
            for next in points.dropFirst() {
                let length = hypot(next.x-previous.x,next.y-previous.y)
                if length > 0.01, total+length >= target {
                    let t = max(0,min(1,(target-total)/length))
                    return XY(x:previous.x+t*(next.x-previous.x),y:previous.y+t*(next.y-previous.y))
                }
                total += length; previous = next
            }
            return points.last
        }
        guard distance >= 2, let a = point(max(0,distance-12)), let b = point(distance), let c = point(distance+12),
              hypot(b.x-a.x,b.y-a.y) > 1, hypot(c.x-b.x,c.y-b.y) > 1 else { return .straight }
        let ax = b.x-a.x, ay = b.y-a.y, bx = c.x-b.x, by = c.y-b.y
        return .angle(atan2(ax*by-ay*bx,ax*bx+ay*by)*180/Double.pi)
    }
    static func needsReroute(_ projection: RouteProjection?, accuracy: Double, walking: Bool) -> Bool {
        guard let projection else { return true }
        return projection.distance > max(walking ? 45 : 65,accuracy*1.5)
    }
    static func project(_ p: XY, points: [XY], previous: Double?, lookAhead: Double) -> RouteProjection? {
        guard points.count > 1 else { return nil }
        var cumulative = 0.0
        var best: RouteProjection?
        for i in 1..<points.count {
            let a = points[i-1], b = points[i], dx = b.x-a.x, dy = b.y-a.y
            let length = hypot(dx,dy)
            defer { cumulative += length }
            guard length > 0.01 else { continue }
            let t = max(0, min(1, ((p.x-a.x)*dx+(p.y-a.y)*dy)/(length*length)))
            let along = cumulative+t*length
            if let previous, along < previous-45 || along > previous+lookAhead { continue }
            let candidate = RouteProjection(distance: hypot(p.x-a.x-t*dx,p.y-a.y-t*dy), progress: along)
            if best == nil || candidate.distance < best!.distance-0.5 { best = candidate }
        }
        return best
    }
}

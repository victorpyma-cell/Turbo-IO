import Foundation

@main struct MeetingTests {
    static func main() {
        var transcript = MeetingTranscript(maxCharacters:100,maxSegments:2)
        transcript.ingest(TranscriptPiece(start:0,end:1,text:"I can deliver Friday",final:false))
        precondition(transcript.segments.isEmpty && !transcript.partial.isEmpty)
        precondition(transcript.context().isEmpty, "Never send unstable partials to the model")
        transcript.ingest(TranscriptPiece(start:0,end:2,text:"I can deliver Monday",final:true))
        transcript.ingest(TranscriptPiece(start:0,end:2,text:"I can deliver Tuesday",final:true))
        precondition(transcript.segments.count == 1 && transcript.text.contains("Tuesday") && !transcript.text.contains("Monday"))
        precondition(transcript.partial.isEmpty && transcript.text.contains("speaker unassigned"))
        transcript.ingest(TranscriptPiece(start:3,end:4,text:"Who owns approval?",final:true))
        transcript.ingest(TranscriptPiece(start:5,end:6,text:"No owner agreed yet",final:true))
        precondition(transcript.trimmed && transcript.segments.count == 2 && transcript.segments[0].start == 3)
        transcript.ingest(TranscriptPiece(start:0,end:2,text:"Late old result",final:true))
        precondition(!transcript.text.contains("Late old result"), "Evicted ranges must not re-enter the meeting")
        let count = transcript.segments.count
        transcript.ingest(TranscriptPiece(start:Double.nan,end:9,text:"Invalid",final:true))
        transcript.ingest(TranscriptPiece(start:10,end:9,text:"Invalid",final:true))
        precondition(transcript.segments.count == count)
        precondition(transcript.context(limit:55).count <= 55)
        var bounded = MeetingTranscript(maxCharacters:20,maxSegments:2)
        bounded.ingest(TranscriptPiece(start:0,end:1,text:String(repeating:"a",count:50),final:true))
        precondition(bounded.trimmed && bounded.segments[0].text.count == 20)
        let routed = AssistantPurpose.meeting.provider(["mode":3,"cueMode":3,"novaMode":3,"meetingMode":2])
        precondition(routed["mode"] as? Int == 2)
        precondition(AssistantPurpose.meeting.provider(["mode":3])["mode"] as? Int == 2)
        precondition(MeetingRequest.review.instructions.contains("do not identify the wearer"))
        print("Meeting policy: corrected finals, unknown identity, bounded context and independent routing passed")
    }
}

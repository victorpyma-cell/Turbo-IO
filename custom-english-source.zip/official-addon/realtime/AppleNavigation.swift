import Foundation
import MapKit
import CoreLocation
import Combine
import UIKit

@available(iOS 26.0, *)
@MainActor final class AppleNavigation: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var query = ""
    @Published var places: [MKMapItem] = []
    @Published var destination: MKMapItem?
    @Published var route: MKRoute?
    @Published var walking = true
    @Published var status = "Search for a destination"
    @Published var instruction = ""
    @Published var distance = ""
    @Published var turn = TurnDirection.straight
    @Published var tripSummary = ""
    @Published var running = false
    @Published var busy = false
    @Published var showOnGlasses = true
    @Published var location: CLLocation?
    private let manager = CLLocationManager()
    private let id = UUID()
    private var search: MKLocalSearch?
    private var directions: MKDirections?
    private var searchEpoch = 0, routeEpoch = 0
    private var points: [XY] = []
    private var steps: [NavigationStep] = []
    private var origin = CLLocationCoordinate2D()
    private var lastProgress: Double?
    private var routeLength = 0.0
    private var routeSeconds = 0.0
    private var arrived = false
    private var offRouteCount = 0
    private var lastReroute = Date.distantPast
    private var timer: Timer?
    @Published private(set) var acquiring = false
    override init() {
        super.init(); manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.distanceFilter = 5
        manager.pausesLocationUpdatesAutomatically = false
    }
    func findPlaces() async {
        let text = query.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 300 else { return }
        // A new search must not leave the old destination eligible for voice start.
        destination = nil; places = []
        searchEpoch += 1; let epoch = searchEpoch; search?.cancel(); busy = true
        let request = MKLocalSearch.Request(); request.naturalLanguageQuery = text
        if let location { request.region = MKCoordinateRegion(center:location.coordinate,latitudinalMeters:30000,longitudinalMeters:30000) }
        let lookup = MKLocalSearch(request:request); search = lookup
        do {
            let response = try await lookup.start()
            guard epoch == searchEpoch else { return }
            places = Array(response.mapItems.prefix(12)); status = places.isEmpty ? "No matching destinations" : "Choose a destination"
        } catch { if epoch == searchEpoch { status = "Search failed. Check the internet connection." } }
        if epoch == searchEpoch { busy = false; search = nil }
    }
    func start() {
        guard !TIORealtimeHost.meeting.active else { status = "Stop Meeting Copilot before starting navigation."; return }
        guard destination != nil, !running, !acquiring else { return }
        if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted { status = "Allow Location for this app in iPhone Settings."; return }
        acquiring = true; status = "Waiting for an accurate location…"
        if manager.authorizationStatus == .notDetermined { manager.requestWhenInUseAuthorization() }
        else { beginLocations() }
    }
    private func beginLocations() {
        guard acquiring else { return }
        guard [.authorizedAlways,.authorizedWhenInUse].contains(manager.authorizationStatus) else { return }
        manager.activityType = walking ? .fitness : .automotiveNavigation
        manager.allowsBackgroundLocationUpdates = true
        manager.showsBackgroundLocationIndicator = true
        manager.startUpdatingLocation()
        let timer = Timer(timeInterval:2,repeats:true) { [weak self] _ in Task { @MainActor in self?.checkFreshness() } }
        self.timer?.invalidate(); self.timer = timer; RunLoop.main.add(timer,forMode:.common)
    }
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor in
            if [.denied,.restricted].contains(self.manager.authorizationStatus) { self.stop("Location permission is required for directions.") }
            else { self.beginLocations() }
        }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let value = locations.last else { return }
        Task { @MainActor in self.accept(value) }
    }
    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        Task { @MainActor in
            self.status = "Location unavailable. Waiting for GPS…"
            GlassesDisplay.shared.update("GPS unavailable\nCheck your phone",owner:self.id)
        }
    }
    private func accept(_ value: CLLocation) {
        guard (acquiring || running) && !arrived else { return }
        guard abs(value.timestamp.timeIntervalSinceNow) < 10, value.horizontalAccuracy >= 0, value.horizontalAccuracy <= (walking ? 40 : 65) else {
            status = "Waiting for an accurate GPS fix…"
            GlassesDisplay.shared.update("Waiting for accurate GPS",owner:id); return
        }
        location = value
        if acquiring && directions == nil {
            acquiring = false
            do {
                try GlassesDisplay.shared.acquire(id,enabled:showOnGlasses) { [weak self] message in self?.stop(message) }
                running = true; Task { await calculate(from:value) }
            } catch { stop(error.localizedDescription) }
            return
        }
        guard running, route != nil, directions == nil else { return }
        updateProgress(value)
    }
    private func xy(_ coordinate: CLLocationCoordinate2D) -> XY {
        // Local metric projection; use the same origin for all route and GPS points.
        let scale = 111_195.0
        return XY(x:(coordinate.longitude-origin.longitude)*scale*cos(origin.latitude*Double.pi/180), y:(coordinate.latitude-origin.latitude)*scale)
    }
    private func calculate(from: CLLocation) async {
        guard running, let destination else { return }
        routeEpoch += 1; let epoch = routeEpoch; directions?.cancel()
        route = nil; points = []; steps = []; lastProgress = nil; arrived = false; tripSummary = ""; instruction = "Calculating route…"; distance = ""; status = "Getting directions from Apple Maps…"
        GlassesDisplay.shared.update("Calculating route…",owner:id)
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark:MKPlacemark(coordinate:from.coordinate))
        request.destination = destination; request.transportType = walking ? .walking : .automobile
        request.requestsAlternateRoutes = false
        let task = MKDirections(request:request); directions = task
        do {
            let response = try await task.calculate()
            guard epoch == routeEpoch, running else { return }
            guard let first = response.routes.first else { throw RealtimeError("No route is available for this destination.") }
            route = first; origin = from.coordinate
            var total = 0.0
            var rawSteps: [(at:Double,text:String)] = []
            for step in first.steps {
                let clean = step.instructions.trimmingCharacters(in:.whitespacesAndNewlines)
                let values = step.polyline.points()
                for i in 0..<step.polyline.pointCount {
                    let next = xy(values[i].coordinate)
                    if let previous = points.last { total += hypot(next.x-previous.x,next.y-previous.y) }
                    if i == 0 && !clean.isEmpty { rawSteps.append((total,clean)) }
                    points.append(next)
                }
            }
            steps = rawSteps.map { step in
                let lower = step.text.lowercased()
                let turn: TurnDirection = lower.contains("roundabout") ? .roundabout : (lower.contains("u-turn") ? .uturn : RouteGeometry.turn(at:step.at,points:points))
                return NavigationStep(at:step.at,text:step.text,turn:turn)
            }
            routeLength = total; routeSeconds = first.expectedTravelTime; directions = nil; offRouteCount = 0
            guard points.count >= 2, !steps.isEmpty else { throw RealtimeError("The route does not include usable turn instructions.") }
            updateProgress(location ?? from)
        } catch {
            guard epoch == routeEpoch, running else { return }
            directions = nil; stop((error as? RealtimeError)?.message ?? "Could not calculate a route. Check your connection and try again.")
        }
    }
    private func updateProgress(_ fix: CLLocation) {
        let projection = RouteGeometry.project(xy(fix.coordinate),points:points,previous:lastProgress,lookAhead:walking ? 500 : 2000)
        if RouteGeometry.needsReroute(projection,accuracy:fix.horizontalAccuracy,walking:walking) {
            offRouteCount += 1; status = "Off route · checking position"
            instruction = "Checking route…"; distance = ""
            GlassesDisplay.shared.update("Off route\nChecking position…",owner:id)
            if offRouteCount >= 3 && Date().timeIntervalSince(lastReroute) >= 30 { lastReroute = Date(); Task { await calculate(from:fix) } }
            return
        }
        guard let projection else { return }
        offRouteCount = 0
        let progress = max(lastProgress ?? 0,projection.progress); lastProgress = progress
        if let destination, progress > routeLength-40, fix.distance(from:CLLocation(latitude:destination.placemark.coordinate.latitude,longitude:destination.placemark.coordinate.longitude)) < max(20,min(35,fix.horizontalAccuracy)) {
            arrived = true; instruction = "You have arrived"; distance = ""; tripSummary = ""; turn = .arrive; status = "Arrived"
            GlassesDisplay.shared.update("You have arrived\n\(destination.name ?? "Destination")",owner:id)
            manager.stopUpdatingLocation(); timer?.invalidate(); timer = nil
            // Retain the arrival card until the user ends this session.
            return
        }
        let next = NavigationPolicy.next(steps,progress:progress) ?? NavigationStep(at:routeLength,text:"Arrive at \(destination?.name ?? "destination")",turn:.arrive)
        instruction = next.text; turn = next.turn
        let remaining = max(0,next.at-progress)
        distance = remaining <= 4 ? "Now" : NavigationPolicy.distance(remaining)
        let totalRemaining = max(0,routeLength-progress)
        let seconds = max(0,routeSeconds * totalRemaining / max(1,routeLength))
        let minutes = max(1,Int(ceil(seconds/60)))
        let eta = Date().addingTimeInterval(seconds).formatted(date:.omitted,time:.shortened)
        tripSummary = "\(NavigationPolicy.distance(totalRemaining)) left · ~\(minutes) min · ETA \(eta)"
        status = walking ? "Walking · Apple Maps" : "Driving · Apple Maps"
        GlassesDisplay.shared.update("\(turn.rawValue) · \(distance)\n\(RealtimePolicy.hud(instruction,bytes:190))\n\(tripSummary)",owner:id)
    }
    private func checkFreshness() {
        guard running, !arrived else { return }
        if location == nil || Date().timeIntervalSince(location!.timestamp) > 12 {
            status = "GPS signal lost · directions paused"
            instruction = "Directions paused"; distance = ""
            GlassesDisplay.shared.update("GPS signal lost\nDirections paused",owner:id)
        }
    }
    func stop(_ message: String = "Navigation stopped") {
        routeEpoch += 1; searchEpoch += 1; directions?.cancel(); directions = nil; search?.cancel(); search = nil
        manager.stopUpdatingLocation(); manager.allowsBackgroundLocationUpdates = false
        timer?.invalidate(); timer = nil; running = false; acquiring = false; busy = false; status = message
        instruction = ""; distance = ""; tripSummary = ""; route = nil; arrived = false
        GlassesDisplay.shared.release(id)
    }
    func openGoogleMaps() {
        guard let destination else { return }
        let p = destination.placemark.coordinate
        var components = URLComponents(string:"https://www.google.com/maps/dir/")!
        components.queryItems = [URLQueryItem(name:"api",value:"1"),URLQueryItem(name:"destination",value:"\(p.latitude),\(p.longitude)"),URLQueryItem(name:"travelmode",value:walking ? "walking" : "driving")]
        if let url = components.url { UIApplication.shared.open(url) }
    }
}

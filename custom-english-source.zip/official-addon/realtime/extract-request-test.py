from pathlib import Path
source = Path('focus-edition/Addon.m').read_text()
start = source.index('@interface TIORequest :')
end = source.index('@interface TIOController :', start)
Path('build/essentials/TIORequest-under-test.inc').write_text(source[start:end])

import Foundation
import Speech
import AVFAudio
import CoreMedia

enum CaptionFailure: Error { case configuration, unavailable, routeChanged }

@available(iOS 26.0, *)
@MainActor final class LocalSpeech {
    var onText: ((TranscriptPiece) -> Void)?
    var onFailure: ((String) -> Void)?
    private let microphone = CaptionMicrophoneInput()
    private let parakeet = CaptionParakeetSpeech()
    private let whisper = FasterWhisperSpeech()
    private let localWhisper = CaptionWhisperSpeech()
    private var localWhisperActive=false
    private var whisperActive = false
    private var parakeetActive = false
    private var parakeetTimeline = ParakeetTimeline()
    private var analyzer: SpeechAnalyzer?
    private var input: AsyncStream<AnalyzerInput>.Continuation?
    private var results: Task<Void, Never>?
    private var generation = 0
    private var starting = false
    private var audioDuration = 0.0
    private(set) var lastRecognitionDelay = 0.0
    private(set) var inputName = "iPhone microphone"
    private(set) var engineName = "on-device speech"

    static func languages(engine: SpeechEngine = .apple) async -> [Locale] {
        if engine == .whisperLocal { return CaptionWhisperSpeech.languages }
        if engine == .whisper { return ["en-US","zh-CN","ja-JP","ko-KR","fr-FR","de-DE","es-ES","it-IT","pt-BR","ru-RU","ar-SA","hi-IN","th-TH","vi-VN","id-ID"].map { Locale(identifier:$0) } }
        let modern = SpeechTranscriber.isAvailable ? await SpeechTranscriber.supportedLocales : []
        let dictation = await DictationTranscriber.supportedLocales
        return Set((modern+dictation).map(\.identifier) + (engine == .parakeet ? ["en-US"] : [])).sorted().map { Locale(identifier:$0) }
    }
    private static func makeModule(_ identifier: String, requireInstalled: Bool) async throws -> any SpeechModule {
        if SpeechTranscriber.isAvailable,
           let locale = await SpeechTranscriber.supportedLocale(equivalentTo:Locale(identifier:identifier)) {
            if requireInstalled {
                guard await SpeechTranscriber.installedLocales.contains(where:{$0.identifier == locale.identifier}) else {
                    throw RealtimeError("Tap Prepare speech language first to download Apple's on-device model.")
                }
            }
            return SpeechTranscriber(locale:locale,transcriptionOptions:[],reportingOptions:[.volatileResults,.fastResults],attributeOptions:[.audioTimeRange])
        }
        // Apple's compatibility engine also stays on device. Do not fall back to
        // network recognition or silently send microphone audio to a provider.
        if let locale = await DictationTranscriber.supportedLocale(equivalentTo:Locale(identifier:identifier)) {
            if requireInstalled {
                guard await DictationTranscriber.installedLocales.contains(where:{$0.identifier == locale.identifier}) else {
                    throw RealtimeError("Tap Prepare speech language first to download Apple's on-device dictation model.")
                }
            }
            return DictationTranscriber(locale:locale,contentHints:[.farField],transcriptionOptions:[.punctuation],reportingOptions:[.volatileResults,.frequentFinalization],attributeOptions:[.audioTimeRange])
        }
        throw RealtimeError("On-device speech is unavailable for this device or language.")
    }
    func prepareLanguage(_ identifier: String, engine: SpeechEngine = .apple) async throws {
        if engine == .whisperLocal { try await localWhisper.prepare(language:identifier,download:true);localWhisper.stop();return }
        if engine == .whisper { try await whisper.prepare(language:identifier); return }
        if engine.usesParakeet(identifier) {
            defer { parakeet.stop() }
            do { try await parakeet.prepare() }
            catch { throw RealtimeError("Parakeet could not load its bundled English model. Reinstall the complete build if this persists.") }
            return
        }
        let module = try await Self.makeModule(identifier,requireInstalled:false)
        if let request = try await AssetInventory.assetInstallationRequest(supporting: [module]) {
            try await request.downloadAndInstall()
        }
    }
    func start(language: String, engine: SpeechEngine = .apple) async throws {
        guard analyzer == nil, !parakeetActive, !whisperActive, !localWhisperActive, !starting else { throw RealtimeError("A speech session is already active.") }
        starting = true
        defer { starting = false }
        generation += 1; let epoch = generation
        audioDuration = 0; lastRecognitionDelay = 0
        if engine == .whisperLocal {
            do { try await startLocalWhisper(language:language,epoch:epoch) } catch { await stop();throw error };return
        }
        if engine == .whisper {
            do { try await startWhisper(language:language,epoch:epoch) } catch { await stop(); throw error };return
        }
        if engine.usesParakeet(language) {
            do { try await startParakeet(epoch:epoch) }
            catch { await stop(); throw error }
            return
        }
        let module = try await Self.makeModule(language,requireInstalled:true)
        try Task.checkCancellation()
        guard epoch == generation else { throw CancellationError() }
        engineName = module is SpeechTranscriber ? "on-device speech" : "on-device dictation"
        guard let format = await SpeechAnalyzer.bestAvailableAudioFormat(compatibleWith: [module]) else {
            throw RealtimeError("The speech model is not ready. Prepare the selected language again.")
        }
        let analyzer = SpeechAnalyzer(modules: [module])
        self.analyzer = analyzer
        do {
            try await analyzer.prepareToAnalyze(in: format)
            guard epoch == generation else { throw CancellationError() }
            let ports = try await microphone.prepare()
            guard epoch == generation else { throw CancellationError() }
            // A RayNeo proprietary Opus stream is not an iOS microphone. Select the
            // known built-in input explicitly instead of silently taking another route.
            guard let port = ports.first(where: { $0.type == AVAudioSession.Port.builtInMic.rawValue }) else {
                throw RealtimeError("The iPhone microphone is unavailable. End the other recording or call.")
            }
            inputName = port.name
            let (sequence, continuation) = AsyncStream<AnalyzerInput>.makeStream(bufferingPolicy: .bufferingOldest(8))
            input = continuation
            microphone.onBuffer = { [weak self] buffer in
                guard let self, self.generation == epoch else { return }
                self.audioDuration += Double(buffer.frameLength) / buffer.format.sampleRate
                if case .dropped = continuation.yield(AnalyzerInput(buffer: buffer)) {
                    self.fail("Speech processing fell behind. Restart the session.", epoch: epoch)
                }
            }
            microphone.onFailure = { [weak self] _ in self?.fail("The microphone route changed or audio was interrupted. Restart when ready.", epoch: epoch) }
            results = Task { [weak self] in
                do {
                    if let transcriber = module as? SpeechTranscriber {
                        for try await result in transcriber.results {
                            guard let self, self.generation == epoch, !Task.isCancelled else { return }
                            let range = result.range
                            self.lastRecognitionDelay = max(0,self.audioDuration-CMTimeGetSeconds(CMTimeRangeGetEnd(range)))
                            self.onText?(TranscriptPiece(start:CMTimeGetSeconds(range.start),end:CMTimeGetSeconds(CMTimeRangeGetEnd(range)),text:String(result.text.characters),final:result.isFinal))
                        }
                    } else if let transcriber = module as? DictationTranscriber {
                        for try await result in transcriber.results {
                            guard let self, self.generation == epoch, !Task.isCancelled else { return }
                            let range = result.range
                            self.lastRecognitionDelay = max(0,self.audioDuration-CMTimeGetSeconds(CMTimeRangeGetEnd(range)))
                            self.onText?(TranscriptPiece(start:CMTimeGetSeconds(range.start),end:CMTimeGetSeconds(CMTimeRangeGetEnd(range)),text:String(result.text.characters),final:result.isFinal))
                        }
                    }
                } catch { if !Task.isCancelled { self?.fail("On-device speech stopped. Restart the session.", epoch: epoch) } }
            }
            try await analyzer.start(inputSequence: sequence)
            guard epoch == generation else { throw CancellationError() }
            try await microphone.start(uid: port.uid, format: format)
        } catch { await stop(); throw error }
    }
    func stop() async {
        generation += 1
        parakeet.stop(); parakeetActive = false
        whisper.stop(); whisperActive = false
        localWhisper.stop();localWhisperActive=false
        microphone.stop(); microphone.onPCM16=nil; input?.finish(); input = nil
        results?.cancel(); results = nil
        let previous = analyzer; analyzer = nil
        await previous?.cancelAndFinishNow()
    }
    private func fail(_ message: String, epoch: Int) {
        guard epoch == generation else { return }
        generation += 1; microphone.stop(); microphone.onPCM16=nil; input?.finish(); input = nil
        parakeet.stop(); parakeetActive = false
        whisper.stop(); whisperActive = false
        localWhisper.stop();localWhisperActive=false
        onFailure?(message)
    }

    private func startLocalWhisper(language:String,epoch:Int) async throws {
        try await localWhisper.prepare(language:language,download:false)
        guard epoch==generation else { throw CancellationError() }
        localWhisperActive=true;engineName="Whisper base · on iPhone"
        localWhisper.onText={ [weak self] piece in guard let self,self.generation==epoch else { return };self.lastRecognitionDelay=max(0,self.audioDuration-piece.end);self.onText?(piece) }
        localWhisper.onFailure={ [weak self] message in self?.fail(message,epoch:epoch) }
        let ports=try await microphone.prepare()
        guard epoch==generation,let port=ports.first(where:{$0.type==AVAudioSession.Port.builtInMic.rawValue}),let format=AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false) else { throw CaptionFailure.unavailable }
        inputName=port.name;microphone.onPCM16=nil
        microphone.onBuffer={ [weak self] buffer in guard let self,self.generation==epoch else { return };self.audioDuration+=Double(buffer.frameLength)/16000;self.localWhisper.offer(buffer) }
        microphone.onFailure={ [weak self] _ in self?.fail("Microphone interrupted. Restart when ready.",epoch:epoch) }
        try await microphone.start(uid:port.uid,format:format)
    }
    private func startWhisper(language:String,epoch:Int) async throws {
        try await whisper.prepare(language:language)
        guard epoch == generation else { throw CancellationError() }
        whisperActive=true;engineName="Faster-whisper · Private PC"
        whisper.onText={ [weak self] piece in guard let self,self.generation==epoch else { return };self.lastRecognitionDelay=max(0,self.audioDuration-piece.end);self.onText?(piece) }
        whisper.onFailure={ [weak self] message in self?.fail(message,epoch:epoch) }
        let ports=try await microphone.prepare()
        guard epoch == generation,let port=ports.first(where:{$0.type==AVAudioSession.Port.builtInMic.rawValue}) else { throw CaptionFailure.unavailable }
        inputName=port.name
        microphone.onBuffer=nil
        microphone.onPCM16={ [weak self] data in guard let self,self.generation==epoch else { return };self.audioDuration+=Double(data.count)/32000;self.whisper.offer(data) }
        microphone.onFailure={ [weak self] _ in self?.fail("Microphone interrupted. Restart when ready.",epoch:epoch) }
        try await microphone.start(uid:port.uid)
    }
    private func startParakeet(epoch: Int) async throws {
        engineName = "Parakeet English · on device"
        parakeetTimeline = ParakeetTimeline(); parakeetActive = true
        parakeet.onText = { [weak self] text, final in
            guard let self, self.generation == epoch else { return }
            let processed = self.parakeet.processedDuration
            self.lastRecognitionDelay = max(0,self.audioDuration-processed)
            self.onText?(self.parakeetTimeline.ingest(text,final:final,processed:processed))
        }
        parakeet.onFailure = { [weak self] _ in
            self?.fail("Parakeet stopped because audio processing was interrupted, overloaded or too hot. Restart when ready.",epoch:epoch)
        }
        do { try await parakeet.prepare() }
        catch { throw RealtimeError("Parakeet's bundled English model could not load. Try Apple recognition or reinstall the complete build.") }
        try Task.checkCancellation()
        guard epoch == generation else { throw CancellationError() }
        let ports = try await microphone.prepare()
        try Task.checkCancellation()
        guard epoch == generation else { throw CancellationError() }
        guard let port = ports.first(where:{$0.type == AVAudioSession.Port.builtInMic.rawValue}),
              let format = AVAudioFormat(commonFormat:.pcmFormatFloat32,sampleRate:16000,channels:1,interleaved:false) else {
            throw RealtimeError("The iPhone microphone is unavailable. End the other recording or call.")
        }
        inputName = port.name
        microphone.onBuffer = { [weak self] buffer in
            guard let self, self.generation == epoch else { return }
            self.audioDuration += Double(buffer.frameLength)/buffer.format.sampleRate
            self.parakeet.offer(buffer)
        }
        microphone.onFailure = { [weak self] _ in self?.fail("The microphone route changed or audio was interrupted. Restart when ready.",epoch:epoch) }
        try await microphone.start(uid:port.uid,format:format)
        try Task.checkCancellation()
        guard epoch == generation else { throw CancellationError() }
    }
}

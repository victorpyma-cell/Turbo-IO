import Foundation

enum ConversationLanguagePolicy {
    static func hasHan(_ text:String) -> Bool {
        text.unicodeScalars.contains { (0x3400...0x9FFF).contains($0.value) }
    }
    static func cantonese(_ text:String) -> Bool {
        // Dialect evidence in a transcript, not acoustic language identification.
        ["唔","冇","喺","嘅","咩","啲","佢","哋","嘢","搵","邊度","点样","點樣","幾時","乜","係咪"].contains { text.contains($0) }
    }
    static func follow(_ text:String,previous:String?,override:String="auto") -> String? {
        if override != "auto",!override.isEmpty { return override }
        if cantonese(text) { return "zh-HK" }
        if hasHan(text) { return previous == "zh-HK" ? "zh-HK" : "zh-CN" }
        let words=text.lowercased().split { !$0.isLetter }.map(String.init)
        // Clear English sentences release a previous Cantonese preference; short
        // acknowledgements and names keep it until there is better evidence.
        if words.count >= 3 && ["what","how","where","when","why","please","can","could","tell","is","are","the"].contains(where:words.contains) { return "en-US" }
        return previous
    }
    static func instruction(_ language:String?) -> String {
        if language == "zh-HK" || language?.hasPrefix("yue") == true {
            return " Reply in natural spoken Cantonese using Cantonese wording in Traditional Chinese, preserving names and technical terms. If the user explicitly requests another language, follow that request."
        }
        return " Match the language and dialect of the user's latest question, including Cantonese rather than converting it to Mandarin. Follow an explicit request to change languages."
    }
}

@MainActor enum ConversationLanguageState {
    static var current:String?
    static func observe(_ text:String) -> String? {
        let override=UserDefaults(suiteName:"io.turboio.official-private-addon")?.string(forKey:"ttsLanguage") ?? "auto"
        current=ConversationLanguagePolicy.follow(text,previous:current,override:override)
        return current
    }
}

import Foundation
import Security

private final class PCSpeechRedirectGuard:NSObject,URLSessionTaskDelegate,@unchecked Sendable {
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping (URLRequest?)->Void) { completionHandler(nil) }
}

enum PCSpeechConnection {
    private static let prefs=UserDefaults(suiteName:"io.turboio.official-private-addon")!
    static var enabled:Bool {
        get { prefs.bool(forKey:"pcSpeechEnabled") }
        set { prefs.set(newValue,forKey:"pcSpeechEnabled") }
    }
    static var endpoint:String {
        get {
            if let saved=prefs.string(forKey:"pcSpeechEndpoint"),!saved.isEmpty { return saved }
            guard var url=URLComponents(string:WhisperConnection.endpoint),url.scheme == "https",url.host != nil else { return "" }
            url.path="/tts";url.query=nil;url.fragment=nil
            return url.string ?? ""
        }
        set { prefs.set(newValue,forKey:"pcSpeechEndpoint") }
    }
    private static let query:[String:Any]=[kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"TurboIO.PrivateSpeech",kSecAttrAccount as String:"api-key"]
    static var key:String {
        var q=query;q[kSecReturnData as String]=true
        var result:CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&result)==errSecSuccess,let data=result as? Data else { return WhisperConnection.key }
        return String(data:data,encoding:.utf8) ?? ""
    }
    static func saveKey(_ value:String) throws {
        let trimmed=value.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return } // Keep the saved key when editing the endpoint.
        var item=query;item[kSecValueData as String]=Data(trimmed.utf8)
        item[kSecAttrAccessible as String]=kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemDelete(query as CFDictionary)
        guard SecItemAdd(item as CFDictionary,nil)==errSecSuccess else { throw RealtimeError("Could not save the private speech key.") }
    }
    static func configureIfMissing(_ provider:[String:Any]) {
        guard prefs.string(forKey:"pcSpeechEndpoint") == nil,
              let value=provider["endpoint"] as? String,var url=URLComponents(string:value),
              url.scheme == "https",url.host?.hasSuffix(".ts.net") == true,url.user == nil,url.password == nil,
              let privateKey=provider["key"] as? String,!privateKey.isEmpty else { return }
        url.path="/tts";url.query=nil;url.fragment=nil
        guard let value=url.string else { return }
        do { try saveKey(privateKey) } catch { return }
        endpoint=value
        if prefs.object(forKey:"pcSpeechEnabled") == nil { enabled=true }
    }
    static func supports(_ language:String,engine:String) -> Bool {
        enabled && engine != "apple" && ["zh-CN","zh-TW","zh-HK","yue"].contains(language) && !endpoint.isEmpty && !key.isEmpty
    }
    private static func request(_ body:[String:Any]) throws -> URLRequest {
        guard let url=URL(string:endpoint),url.scheme == "https",url.host != nil,url.user == nil,url.password == nil,!key.isEmpty else { throw RealtimeError("Set the private HTTPS speech endpoint and API key.") }
        var request=URLRequest(url:url,timeoutInterval:15)
        request.httpMethod="POST"
        request.setValue("application/json",forHTTPHeaderField:"Content-Type")
        request.setValue("Bearer "+key,forHTTPHeaderField:"Authorization")
        request.httpBody=try JSONSerialization.data(withJSONObject:body)
        return request
    }
    private static func fetch(_ body:[String:Any],limit:Int,type:String) async throws -> Data {
        let config=URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest=15;config.timeoutIntervalForResource=20
        let session=URLSession(configuration:config)
        defer { session.invalidateAndCancel() }
        let (bytes,response)=try await session.bytes(for:request(body),delegate:PCSpeechRedirectGuard())
        guard let http=response as? HTTPURLResponse,http.statusCode==200,
              http.mimeType == type,response.expectedContentLength <= Int64(limit) else { throw RealtimeError("Private speech server unavailable. Using Apple voice.") }
        var data=Data()
        for try await byte in bytes {
            if data.count % 8192 == 0 { try Task.checkCancellation() }
            guard data.count < limit else { throw RealtimeError("Private speech response exceeds the audio limit.") }
            data.append(byte)
        }
        try Task.checkCancellation()
        return data
    }
    static func check() async throws {
        let data=try await fetch(["check":true],limit:8192,type:"application/json")
        guard let json=try JSONSerialization.jsonObject(with:data) as? [String:Any],json["ready"] as? Bool == true,json["engine"] as? String == "CosyVoice3" else { throw RealtimeError("The endpoint is not a ready CosyVoice3 server.") }
    }
    static func audio(_ text:String,language:String) async throws -> SpeechAudio {
        let began=ProcessInfo.processInfo.systemUptime
        guard text.count <= 300 else { throw RealtimeError("Speech phrase exceeds the text limit.") }
        let data=try await fetch(["text":text,"language":language],limit:2_160_044,type:"audio/wav")
        guard data.count > 44,String(data:data.prefix(4),encoding:.ascii)=="RIFF",
              String(data:data[8..<12],encoding:.ascii)=="WAVE" else { throw RealtimeError("Private speech returned invalid audio.") }
        return SpeechAudio(data:data,generationSeconds:ProcessInfo.processInfo.systemUptime-began,audioSeconds:Double(data.count-44)/48000)
    }
}

#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
sdk=$(xcrun --sdk iphoneos --show-sdk-path)
mkdir -p build/essentials
bash realtime/build-parakeet.sh
bash realtime/build-whisper.sh
fluid=build/essentials/parakeet/FluidAudio
products=$(cat build/essentials/parakeet/products-path.txt)
whisperProducts=$(cat build/essentials/whisper/products-path.txt)
whisperObjects=("$whisperProducts"/*.o)
# Check the complete Swift integration before compiling the native translation engine.
xcrun --sdk iphoneos swiftc -swift-version 5 -parse-as-library -typecheck \
  -import-objc-header local-translation/src/HyMTBridge.h \
  -I "$whisperProducts" -I "$products" -I "$fluid/Sources/FastClusterWrapper/include" -I "$fluid/Sources/MachTaskSelfWrapper/include" \
  -target arm64-apple-ios26.0 -sdk "$sdk" \
  realtime/RealtimeCore.swift realtime/TokenValidation.swift realtime/LocalSpeech.swift realtime/FasterWhisperSpeech.swift realtime/WhisperSpeech.swift \
  realtime/LoopbackSignIn.swift realtime/ChatGPTFailure.swift realtime/ResponseStream.swift realtime/ChatGPTAnswer.swift \
  realtime/ChatGPTAccount.swift realtime/CueService.swift realtime/RealtimeSession.swift \
  realtime/AppleNavigation.swift realtime/RealtimePanel.swift realtime/NovaPanel.swift realtime/MeetingPolicy.swift realtime/MeetingCopilot.swift \
  local-translation/src/CaptionAudioPipeline.swift local-translation/src/MicrophoneInput.swift \
  local-translation/src/HyMTLocalTranslation.swift \
  local-translation/src/ParakeetSpeech.swift
bash realtime/build-hymt.sh
native=build/essentials/hymt/ios
xcrun --sdk iphoneos swiftc -swift-version 5 -parse-as-library -O \
  -import-objc-header local-translation/src/HyMTBridge.h \
  -I "$whisperProducts" -I "$products" -I "$fluid/Sources/FastClusterWrapper/include" -I "$fluid/Sources/MachTaskSelfWrapper/include" \
  -target arm64-apple-ios26.0 -sdk "$sdk" -emit-library -module-name TurboRealtime \
  -Xlinker -install_name -Xlinker @rpath/TurboRealtime.dylib -Xlinker -no_fixup_chains \
  realtime/RealtimeCore.swift realtime/TokenValidation.swift realtime/LocalSpeech.swift realtime/FasterWhisperSpeech.swift realtime/WhisperSpeech.swift \
  realtime/LoopbackSignIn.swift realtime/ChatGPTFailure.swift realtime/ResponseStream.swift realtime/ChatGPTAnswer.swift \
  realtime/ChatGPTAccount.swift realtime/CueService.swift realtime/RealtimeSession.swift \
  realtime/AppleNavigation.swift realtime/RealtimePanel.swift realtime/NovaPanel.swift realtime/MeetingPolicy.swift realtime/MeetingCopilot.swift \
  local-translation/src/CaptionAudioPipeline.swift local-translation/src/MicrophoneInput.swift \
  local-translation/src/HyMTLocalTranslation.swift \
  local-translation/src/ParakeetSpeech.swift \
  "${whisperObjects[@]}" "$products/FluidAudio.o" "$products/FastClusterWrapper.o" "$products/MachTaskSelfWrapper.o" \
  "$native/libTurboHyMT.a" "$native/llama-build/src/libllama.a" \
  "$native/llama-build/ggml/src/libggml.a" "$native/llama-build/ggml/src/libggml-cpu.a" "$native/llama-build/ggml/src/libggml-base.a" \
  -lc++ -framework Accelerate -framework CoreML -framework AVFoundation \
  -o build/essentials/TurboRealtime.dylib
codesign --force --sign - build/essentials/TurboRealtime.dylib
codesign --verify --strict build/essentials/TurboRealtime.dylib
xcrun swiftc realtime/RealtimeCore.swift realtime/TokenValidation.swift realtime/ChatGPTFailure.swift realtime/ResponseStream.swift realtime/RealtimeTests.swift -o build/essentials/realtime-tests
build/essentials/realtime-tests
xcrun swiftc realtime/RealtimeCore.swift realtime/MeetingPolicy.swift realtime/MeetingTests.swift -o build/essentials/meeting-tests
build/essentials/meeting-tests
xcrun swiftc -swift-version 5 realtime/LoopbackSignIn.swift realtime/LoopbackTests.swift -o build/essentials/loopback-tests
build/essentials/loopback-tests
python3 realtime/extract-request-test.py
xcrun clang -DTIO_ESSENTIALS=1 -fobjc-arc -fmodules -framework Foundation -I build/essentials realtime/RequestRoutingTests.m -o build/essentials/request-routing-tests
build/essentials/request-routing-tests
echo "Native model test CPU count: $(sysctl -n hw.ncpu)"
# Hosted macOS runners expose fewer cores than the iPhone; avoid oversubscribing
# the CPU backend's spinning workers. Keep the production 15-second timeout.
build/essentials/hymt/mac/hymt-tests build/essentials/hymt/Hy-MT2-1.8B-STQ43.gguf 2
mac=build/essentials/hymt/mac
xcrun swiftc -swift-version 5 -parse-as-library -O -import-objc-header local-translation/src/HyMTBridge.h \
  local-translation/src/HyMTLocalTranslation.swift local-translation/src/HyMTTranslationTests.swift \
  "$mac/libTurboHyMT.a" "$mac/llama-build/src/libllama.a" \
  "$mac/llama-build/ggml/src/libggml.a" "$mac/llama-build/ggml/src/libggml-cpu.a" "$mac/llama-build/ggml/src/libggml-base.a" \
  -lc++ -framework Accelerate -o build/essentials/hymt-swift-tests
build/essentials/hymt-swift-tests build/essentials/hymt/Hy-MT2-original.gguf build/essentials/hymt/Hy-MT2-1.8B-STQ43.gguf

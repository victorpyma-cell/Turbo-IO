import Foundation
import UIKit
import SafariServices
import CryptoKit
import Security
import Combine

@available(iOS 26.0, *)
@MainActor final class ChatGPTAccount: NSObject, ObservableObject, SFSafariViewControllerDelegate {
    static let shared = ChatGPTAccount()
    @Published var status = "Not connected"
    @Published var models: [(id: String, name: String)] = []
    @Published var selectedModel: String? { didSet { UserDefaults.standard.set(selectedModel, forKey: "TurboRealtime.ChatGPT.model") } }
    @Published private(set) var isSignedIn = false
    @Published private(set) var signingIn = false
    private var record: [String:Any] = [:]
    private var listener: LoopbackSignIn?
    private var safari: SFSafariViewController?
    private var callback: CheckedContinuation<URL, Error>?
    private var timeout: Task<Void,Never>?
    private var refresh: Task<String,Error>?
    private var generation = 0
    private let keychain: [String:Any] = [kSecClass as String:kSecClassGenericPassword, kSecAttrService as String:"TurboIORealtime.ChatGPT", kSecAttrAccount as String:"account"]
    override private init() {
        super.init()
        var query = keychain; query[kSecReturnData as String] = true
        var item: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess, let data = item as? Data,
           let saved = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
            record = saved; isSignedIn = saved["refresh_token"] != nil
            status = isSignedIn ? "Connected to ChatGPT" : "Not connected"
        }
        selectedModel = UserDefaults.standard.string(forKey: "TurboRealtime.ChatGPT.model")
    }
    private func save(_ value: [String:Any]) throws {
        let data = try JSONSerialization.data(withJSONObject: value)
        let attributes: [String:Any] = [kSecValueData as String:data, kSecAttrAccessible as String:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        let result = SecItemUpdate(keychain as CFDictionary, attributes as CFDictionary)
        if result == errSecItemNotFound {
            guard SecItemAdd(keychain.merging(attributes) { _,b in b } as CFDictionary,nil) == errSecSuccess else { throw RealtimeError("The Keychain could not save this sign-in.") }
        } else if result != errSecSuccess { throw RealtimeError("The Keychain could not update this sign-in.") }
        record = value; isSignedIn = true
    }
    func signOut() {
        generation += 1; cancelSignIn(); refresh?.cancel(); refresh = nil
        SecItemDelete(keychain as CFDictionary); record = [:]; isSignedIn = false
        models = []; selectedModel = nil; status = "Disconnected on this iPhone"
    }
    func cancelSignIn() {
        generation += 1
        cleanUpSignIn()
    }
    private func cleanUpSignIn() {
        timeout?.cancel(); timeout = nil; listener?.cancel(); listener = nil
        let pending = callback; callback = nil; pending?.resume(throwing: CancellationError())
        safari?.dismiss(animated: true); safari = nil; signingIn = false
    }
    nonisolated func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        Task { @MainActor in self.cancelSignIn() }
    }
    func signIn(presenter: UIViewController) async {
        guard !signingIn else { return }
        signingIn = true; status = "Waiting for ChatGPT sign-in…"
        let epoch = generation
        defer { if epoch == generation { cleanUpSignIn() } }
        do {
            let state = try TokenValidation.random(), nonce = try TokenValidation.random(), verifier = try TokenValidation.random()
            let previousClient = record["client_id"] as? String
            let client = previousClient ?? "dynamic_agent_client"
            let hostKey = "TurboRealtime.ChatGPT.host"
            let host = UserDefaults.standard.string(forKey: hostKey) ?? "urn:uuid:"+UUID().uuidString.lowercased()
            UserDefaults.standard.set(host, forKey: hostKey)
            let server = LoopbackSignIn(); listener = server
            let port = try await server.start(state: state, onCallback: { [weak self] url in
                guard let self, self.generation == epoch else { return }
                let pending = self.callback; self.callback = nil; pending?.resume(returning: url)
            }, onFailure: { [weak self] error in
                guard let self, self.generation == epoch else { return }
                let pending = self.callback; self.callback = nil; pending?.resume(throwing: error)
            })
            let redirect = "http://127.0.0.1:\(port)/auth/callback"
            var components = URLComponents(string: "https://auth.openai.com/api/accounts/authorize")!
            var fields = ["client_id":client,"ext_agent_host_id":host,"response_type":"code","redirect_uri":redirect,
                          "scope":"openid profile email offline_access resource.invoke chatgpt.tokens.use.direct",
                          "resource":"https://api.openai.com/v1","state":state,"nonce":nonce,
                          "code_challenge_method":"S256","code_challenge":TokenValidation.base64URL(Data(SHA256.hash(data: Data(verifier.utf8))))]
            if previousClient == nil { fields["agent_name_hint"] = "Turbo IO" }
            else { fields["id_token_hint"] = record["id_token"] as? String }
            components.queryItems = fields.map { URLQueryItem(name:$0.key,value:$0.value) }
            guard epoch == generation else { throw CancellationError() }
            let returned: URL = try await withCheckedThrowingContinuation { pending in
                callback = pending
                let browser = SFSafariViewController(url: components.url!); browser.delegate = self
                safari = browser; presenter.present(browser, animated: true)
                timeout = Task { [weak self] in
                    try? await Task.sleep(for: .seconds(180))
                    guard !Task.isCancelled else { return }
                    self?.cancelSignIn(); self?.status = "Sign-in timed out. Try again."
                }
            }
            safari?.dismiss(animated: true); safari = nil; listener?.cancel(); listener = nil
            timeout?.cancel(); timeout = nil
            let values = URLComponents(url: returned, resolvingAgainstBaseURL:false)?.queryItems ?? []
            func value(_ key: String) -> String? { let matches = values.filter { $0.name == key }; return matches.count == 1 ? matches[0].value : nil }
            guard value("state") == state, value("error") == nil, let code = value("code"), !code.isEmpty else { throw RealtimeError("ChatGPT sign-in was declined or the callback was invalid.") }
            let issued = value("client_id") ?? previousClient
            guard let issued, issued != "dynamic_agent_client", !issued.isEmpty,
                  previousClient == nil || previousClient == issued else { throw RealtimeError("ChatGPT returned a different registration. Disconnect before changing accounts.") }
            let tokens = try await tokenRequest(["grant_type":"authorization_code","client_id":issued,"code":code,"code_verifier":verifier,"redirect_uri":redirect,"resource":"https://api.openai.com/v1"])
            guard let idToken = tokens["id_token"] as? String else { throw RealtimeError("ChatGPT did not return a verified identity.") }
            let claims = try await verifiedIdentity(idToken, client:issued, nonce:nonce)
            if let old = record["subject"] as? String, old != claims["sub"] as? String { throw RealtimeError("This is a different ChatGPT account. Disconnect before switching accounts.") }
            var saved = try validatedTokens(tokens, replacing: [:])
            saved["client_id"] = issued; saved["subject"] = claims["sub"]; saved["ext_agent_host_id"] = host
            guard epoch == generation else { throw CancellationError() }
            try save(saved); status = "Connected to ChatGPT"
            try await loadModels()
        } catch is CancellationError { if !isSignedIn { status = "Sign-in cancelled" } }
        catch { if epoch == generation { status = (error as? RealtimeError)?.message ?? (error as? LoopbackSignIn.Failure)?.message ?? "ChatGPT sign-in could not be verified. Try again." } }
    }
    private func tokenRequest(_ fields: [String:String]) async throws -> [String:Any] {
        var c = URLComponents(); c.queryItems = fields.map { URLQueryItem(name:$0.key,value:$0.value) }
        var request = URLRequest(url:URL(string:"https://auth.openai.com/api/accounts/oauth/token")!)
        request.httpMethod = "POST"; request.setValue("application/x-www-form-urlencoded",forHTTPHeaderField:"Content-Type")
        request.httpBody = c.percentEncodedQuery?.replacingOccurrences(of:"+",with:"%2B").data(using:.utf8)
        let (data,response) = try await CueService.network.data(for:request)
        guard (response as? HTTPURLResponse)?.statusCode == 200, data.count < 65536,
              let result = try JSONSerialization.jsonObject(with:data) as? [String:Any] else { throw RealtimeError("ChatGPT authorization expired or was rejected. Sign in again.") }
        return result
    }
    private func verifiedIdentity(_ token: String, client: String, nonce: String?) async throws -> [String:Any] {
        let (data,response) = try await CueService.network.data(from:URL(string:"https://auth.openai.com/.well-known/jwks.json")!)
        guard (response as? HTTPURLResponse)?.statusCode == 200, data.count < 262144,
              let json = try JSONSerialization.jsonObject(with:data) as? [String:Any], let keys = json["keys"] as? [[String:Any]] else { throw TokenValidation.Failure.invalid }
        return try TokenValidation.verify(token,jwks:keys,audience:client,nonce:nonce)
    }
    private func validatedTokens(_ tokens: [String:Any], replacing old: [String:Any]) throws -> [String:Any] {
        guard tokens["token_type"] as? String == "Bearer", let access = tokens["access_token"] as? String, !access.isEmpty,
              let refresh = tokens["refresh_token"] as? String, !refresh.isEmpty,
              let scope = tokens["scope"] as? String, scope.split(separator:" ").contains("chatgpt.tokens.use.direct"),
              let expiry = tokens["expires_in"] as? Double, expiry > 0 else { throw RealtimeError("This account did not grant ChatGPT plan usage.") }
        var saved = old.merging(tokens) { _,b in b }; saved["expires_at"] = Date().timeIntervalSince1970+expiry
        return saved
    }
    func accessToken() async throws -> String {
        if let access = record["access_token"] as? String, (record["expires_at"] as? Double ?? 0) > Date().timeIntervalSince1970+60 { return access }
        if let refresh { return try await refresh.value }
        let epoch = generation
        let task = Task<String,Error> {
            guard let client = record["client_id"] as? String, let token = record["refresh_token"] as? String else { throw RealtimeError("Sign in with ChatGPT first.") }
            let tokens = try await tokenRequest(["grant_type":"refresh_token","client_id":client,"refresh_token":token,"resource":"https://api.openai.com/v1"])
            if let id = tokens["id_token"] as? String {
                let claims = try await verifiedIdentity(id,client:client,nonce:nil)
                guard claims["sub"] as? String == record["subject"] as? String else { throw TokenValidation.Failure.invalid }
            }
            let saved = try validatedTokens(tokens,replacing:record)
            guard epoch == generation else { throw CancellationError() }
            try save(saved); return saved["access_token"] as! String
        }
        refresh = task; defer { refresh = nil }
        return try await task.value
    }
    func loadModels() async throws {
        let epoch = generation
        var request = URLRequest(url:URL(string:"https://api.openai.com/v1/models")!)
        request.setValue("Bearer \(try await accessToken())",forHTTPHeaderField:"Authorization")
        let (data,response) = try await CueService.network.data(for:request)
        guard (response as? HTTPURLResponse)?.statusCode == 200, data.count < 1048576,
              let json = try JSONSerialization.jsonObject(with:data) as? [String:Any], let list = json["models"] as? [[String:Any]] else { throw RealtimeError("ChatGPT model list is unavailable for this account.") }
        guard epoch == generation else { throw CancellationError() }
        models = list.compactMap { entry in
            guard entry["visibility"] as? String == "list", let slug = entry["slug"] as? String else { return nil }
            return (slug,entry["display_name"] as? String ?? slug)
        }
        if !models.contains(where:{$0.id == selectedModel}) { selectedModel = models.first?.id }
        status = models.isEmpty ? "Connected, but no models are available" : "Connected to ChatGPT"
    }
}

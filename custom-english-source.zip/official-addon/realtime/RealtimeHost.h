#import <UIKit/UIKit.h>
void TIOInstallRealtimeObserver(void);
void TIOOpenRealtime(UIViewController *presenter, NSString *page, NSDictionary *(^provider)(void));
void TIOHandleRealtimeVoiceCommand(UIViewController *presenter, NSDictionary *command, NSDictionary *(^provider)(void));
void TIORealtimeOfficialAudioStarted(void);
BOOL TIOChatGPTReady(void);
id TIOStartChatGPTNewsAnswer(NSString *question, void (^update)(NSString *, BOOL, NSString *));
id TIOStartChatGPTAnswer(NSString *question, NSArray<NSDictionary *> *history, void (^update)(NSString *, BOOL, NSString *));

UIViewController *TIOCreateRealtimeController(NSString *page, NSDictionary *(^provider)(void));

import Foundation

@main struct LoopbackTests {
    @MainActor static func main() async throws {
        let server = LoopbackSignIn()
        var callbacks: [URL] = []
        let port = try await server.start(state: "fixture-state", onCallback: { callbacks.append($0) }, onFailure: { fatalError("Listener failed: \($0)") })
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 5
        let session = URLSession(configuration: configuration)
        func get(_ target: String) async throws -> Int {
            let (_, response) = try await session.data(from: URL(string: "http://127.0.0.1:\(port)\(target)")!)
            return (response as! HTTPURLResponse).statusCode
        }
        let wrong = try await get("/auth/callback?state=wrong&code=fake")
        assert(wrong == 400 && callbacks.isEmpty)
        let repeated = try await get("/auth/callback?state=fixture-state&state=fixture-state&code=fake")
        assert(repeated == 400 && callbacks.isEmpty)
        let badPath = try await get("/different?state=fixture-state&code=fake")
        assert(badPath == 400 && callbacks.isEmpty)
        let valid = try await get("/auth/callback?state=fixture-state&code=fixture-code&client_id=fixture-client")
        try await Task.sleep(nanoseconds: 100_000_000)
        assert(valid == 200 && callbacks.count == 1)
        assert(URLComponents(url: callbacks[0], resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "code" })?.value == "fixture-code")
        let duplicate = try await get("/auth/callback?state=fixture-state&code=again")
        assert(duplicate == 400 && callbacks.count == 1)
        server.cancel()
        // Closing sign-in before ready must resume the pending start, not hang it.
        let cancel = Task { @MainActor in server.cancel() }
        do { _ = try await server.start(state: "cancel", onCallback: { _ in fatalError() }, onFailure: { _ in }) } catch is CancellationError { }
        await cancel.value
        server.cancel()
        _ = try await server.start(state: "retry", onCallback: { _ in }, onFailure: { _ in })
        server.cancel(); session.invalidateAndCancel()
        print("PASS: real loopback listener startup, HTTP callback, invalid state/path, duplicate rejection, cancellation and retry")
    }
}

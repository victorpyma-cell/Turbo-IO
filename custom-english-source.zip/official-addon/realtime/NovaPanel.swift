import Foundation
import SwiftUI
import Combine
import UIKit

struct NovaNote: Codable, Identifiable {
    var id = UUID()
    var date = Date()
    var original: String
    var answer: String
}

@available(iOS 26.0, *)
@MainActor final class NovaLibrary: ObservableObject {
    static let shared = NovaLibrary()
    private struct Archive: Codable { var briefing = ""; var notes: [NovaNote] = [] }
    @Published private(set) var notes: [NovaNote] = []
    @Published private(set) var briefing = ""
    @Published private(set) var loadError = ""
    private let file: URL
    init() {
        file = FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("TurboNova/library.json")
        if FileManager.default.fileExists(atPath:file.path) {
            do {
                let saved = try JSONDecoder().decode(Archive.self,from:Data(contentsOf:file))
                notes = saved.notes; briefing = saved.briefing
            } catch { loadError = "Nova notes could not be read. The existing file has been preserved." }
        }
    }
    private func persist(briefing: String, notes: [NovaNote]) throws {
        guard loadError.isEmpty else { throw RealtimeError(loadError) }
        try FileManager.default.createDirectory(at:file.deletingLastPathComponent(),withIntermediateDirectories:true)
        try JSONEncoder().encode(Archive(briefing:briefing,notes:notes)).write(to:file,options:[.atomic,.completeFileProtection])
        self.briefing = briefing; self.notes = notes
    }
    func saveBriefing(_ text: String) throws {
        guard text.count <= 4000 else { throw RealtimeError("Keep the briefing under 4,000 characters.") }
        try persist(briefing:text,notes:notes)
    }
    func saveNote(original: String, answer: String = "") throws {
        guard !original.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty else { throw RealtimeError("There is no note to save.") }
        guard notes.count < 200 else { throw RealtimeError("The notebook is full. Delete an old note before saving another.") }
        var updated = notes
        updated.insert(NovaNote(original:String(original.prefix(16000)),answer:String(answer.prefix(16000))),at:0)
        try persist(briefing:briefing,notes:updated)
    }
    func delete(_ id: UUID) throws { try persist(briefing:briefing,notes:notes.filter { $0.id != id }) }
}

@available(iOS 26.0, *)
@MainActor final class NovaConversation: ObservableObject {
    struct Turn: Identifiable { let id = UUID(); let question: String; let answer: String }
    @Published var draft = ""
    @Published var answer = ""
    @Published var status = "Ready"
    @Published var timing = ""
    @Published var busy = false
    @Published var includeBriefing = false
    @Published private(set) var turns: [Turn] = []
    private(set) var lastQuestion = ""
    private(set) var completed = false
    private var request: Task<Void,Never>?
    private var generation = 0
    var providerLabel: String {
        let p = AssistantPurpose.nova.provider(TIORealtimeHost.call("provider"))
        if p["mode"] as? Int == 3 { return "ChatGPT · \(ChatGPTAccount.shared.selectedModel ?? "choose a model")" }
        if p["mode"] as? Int == 2 { return "Custom API · \(p["model"] as? String ?? "choose a model")" }
        return "Select the Nova Q&A provider in Assistant"
    }
    func cancel() { generation += 1; request?.cancel(); request = nil; busy = false; if !completed { status = "Cancelled · partial answer not saved" } }
    func clear() { cancel(); turns = []; answer = ""; lastQuestion = ""; completed = false; status = "Conversation cleared"; timing = "" }
    func send(_ prompt: String? = nil) {
        let question = (prompt ?? draft).trimmingCharacters(in:.whitespacesAndNewlines)
        guard !question.isEmpty, !busy else { return }
        guard question.count <= 8000 else { status = "Keep each message under 8,000 characters."; return }
        do { try CueService.validateProvider(purpose:.nova) } catch { status = error.localizedDescription; return }
        generation += 1; let epoch = generation
        lastQuestion = question; answer = ""; completed = false; busy = true; status = "Connecting…"; timing = ""
        if prompt == nil { draft = "" }
        let recent = turns.suffix(6).map { "User: \($0.question)\nAssistant: \($0.answer)" }.joined(separator:"\n")
        let briefing = includeBriefing ? NovaLibrary.shared.briefing : ""
        let input = "Optional user briefing (context, not verified facts):\n\(briefing)\n\nRecent conversation:\n\(recent.suffix(12000))\n\nCurrent request:\n\(question)"
        let started = Date()
        request = Task { [weak self] in
            guard let self else { return }
            defer { if self.generation == epoch { self.busy = false; self.request = nil } }
            do {
                var first = true
                let result = try await CueService().respond(instructions:"You are Nova, a concise personal assistant. Answer the current request directly, usually under 120 words. Give detail when requested. Use the optional briefing and recent conversation only as context. You cannot operate apps, browse, send messages, or access calendars. Do not claim actions or invent personal facts. When summarizing notes, preserve uncertainty, names, dates and commitments; never invent them.",prompt:input,purpose:.nova) { [weak self] text in
                    guard let self, self.generation == epoch, !Task.isCancelled else { return }
                    if first { self.timing = String(format:"First text %.1fs",Date().timeIntervalSince(started)); first = false }
                    self.answer = text; self.status = "Answer arriving…"
                }
                guard self.generation == epoch, !Task.isCancelled else { return }
                guard !result.isEmpty else { throw RealtimeError("The provider returned an empty answer.") }
                self.answer = result; self.completed = true; self.status = "Ready"
                self.timing += String(format:" · complete %.1fs",Date().timeIntervalSince(started))
                self.turns.append(Turn(question:question,answer:result))
                if self.turns.count > 20 { self.turns.removeFirst() }
            } catch {
                guard self.generation == epoch, !Task.isCancelled else { return }
                let ns = error as NSError
                self.status = ns.domain == NSURLErrorDomain ? "Connection failed (\(ns.code)). For Strata, check Tailscale on this iPhone, the private HTTPS endpoint and that the PC is awake." : error.localizedDescription
            }
        }
    }
    func save() {
        guard completed else { return }
        do { try NovaLibrary.shared.saveNote(original:lastQuestion,answer:answer); status = "Question and answer saved locally" }
        catch { status = error.localizedDescription }
    }
}

@available(iOS 26.0, *)
struct NovaPanel: View {
    @StateObject private var chat = NovaConversation()
    @ObservedObject private var library = NovaLibrary.shared
    @State private var briefing = ""
    @State private var note = ""
    @State private var notice = ""
    var body: some View {
        Form {
            Section("Nova assistant") {
                Text(chat.providerLabel).font(.subheadline)
                Text("This chat connects directly to your selected provider. The original RayNeo AI screen keeps its separate service.").font(.footnote).foregroundStyle(.secondary)
                TextField("Ask Nova…",text:$chat.draft,axis:.vertical).lineLimit(2...6).disabled(chat.busy)
                Toggle("Include my briefing with requests",isOn:$chat.includeBriefing).disabled(chat.busy)
                if chat.busy { Button("Stop answer",role:.destructive) { chat.cancel() }; ProgressView() }
                else { Button("Send") { chat.send() }.disabled(chat.draft.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty) }
                Text(chat.status).font(.footnote)
                if !chat.timing.isEmpty { Text(chat.timing).font(.caption).foregroundStyle(.secondary) }
            }
            if !chat.answer.isEmpty {
                Section("Answer") {
                    Text(chat.answer).textSelection(.enabled)
                    if chat.completed && !chat.busy {
                        HStack {
                            Button("Shorter") { chat.send("Make your previous answer shorter.") }
                            Button("Explain") { chat.send("Explain your previous answer in plain language.") }
                            Button("Example") { chat.send("Give one concrete example of your previous answer.") }
                        }.buttonStyle(.bordered)
                        Button("Save question and answer") { chat.save() }
                    }
                    Button("Clear conversation",role:.destructive) { chat.clear() }
                }
            }
            Section("My briefing") {
                TextEditor(text:$briefing).frame(minHeight:100)
                Button("Save briefing") { do { try library.saveBriefing(briefing); notice = "Briefing saved on this iPhone" } catch { notice = error.localizedDescription } }
                Text("Add names, goals and background for this conversation. It is sent only when Include my briefing is enabled. This does not import ChatGPT history or memory.").font(.footnote).foregroundStyle(.secondary)
            }
            Section("Quick note") {
                TextField("Type or use keyboard dictation…",text:$note,axis:.vertical).lineLimit(2...6)
                Button("Save original note") {
                    do { try library.saveNote(original:note); note = ""; notice = "Original note saved" } catch { notice = error.localizedDescription }
                }.disabled(note.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                Text("Notes stay on this iPhone. Summarize sends only the selected note, recent Nova conversation and any enabled briefing to your provider. Save the resulting answer to keep both its source and summary.").font(.footnote).foregroundStyle(.secondary)
            }
            Section("Saved notes") {
                if !library.loadError.isEmpty { Text(library.loadError) }
                if library.notes.isEmpty { Text("No saved notes") }
                ForEach(library.notes) { item in
                    DisclosureGroup {
                        Text(item.original).textSelection(.enabled)
                        if !item.answer.isEmpty { Text(item.answer).textSelection(.enabled) }
                        Button("Summarize this note") { chat.send("Summarize this note into key points and explicitly stated next steps. Preserve the original facts.\n\n" + item.original + (item.answer.isEmpty ? "" : "\n\nSaved answer:\n" + item.answer)) }.disabled(chat.busy)
                        ShareLink(item:item.original + (item.answer.isEmpty ? "" : "\n\n" + item.answer)) { Text("Share note") }
                        Button("Delete note",role:.destructive) { do { try library.delete(item.id) } catch { notice = error.localizedDescription } }
                    } label: {
                        VStack(alignment:.leading) { Text(String(item.original.prefix(70))).lineLimit(2); Text(item.date,style:.date).font(.caption).foregroundStyle(.secondary) }
                    }
                }
            }
            if !notice.isEmpty { Section { Text(notice).font(.footnote) } }
        }.navigationTitle("Nova")
            .onAppear { briefing = library.briefing }
            .onDisappear { chat.cancel() }
            .onReceive(NotificationCenter.default.publisher(for:UIApplication.willResignActiveNotification)) { _ in chat.cancel() }
    }
}

import SwiftUI
import AVFoundation

@available(iOS 26.0, *)
struct SpeechOutputPanel:View {
    @AppStorage("ttsOutputEngine",store:UserDefaults(suiteName:"io.turboio.official-private-addon")) var engine="auto"
    @AppStorage("ttsLanguage",store:UserDefaults(suiteName:"io.turboio.official-private-addon")) var language="auto"
    @AppStorage("kokoroVoice",store:UserDefaults(suiteName:"io.turboio.official-private-addon")) var voice="af_heart"
    @AppStorage("ttsSpeed",store:UserDefaults(suiteName:"io.turboio.official-private-addon")) var speed=1.1
    @AppStorage("appleSpeechVoice",store:UserDefaults(suiteName:"io.turboio.official-private-addon")) var appleVoice=""
    @State private var narrator=LocalNarrator()
    @State private var preview="Hello. This is your Turbo IO assistant, speaking naturally on your iPhone."
    @State private var status=""
    @State private var pcEnabled=PCSpeechConnection.enabled
    @State private var pcEndpoint=PCSpeechConnection.endpoint
    @State private var pcKey=""
    @State private var pcStatus=""
    @State private var checkingPC=false
    var body:some View {
        Form {
            Section {
                Picker("Engine",selection:$engine) { Text("Automatic · Kokoro + Apple").tag("auto");Text("Kokoro · English quality").tag("kokoro");Text("Apple voices only").tag("apple") }
                Picker("Language",selection:$language) {
                    Text("Detect from response text").tag("auto")
                    ForEach(["en-US","en-GB","zh-CN","zh-TW","zh-HK","ja-JP","ko-KR","fr-FR","de-DE","es-ES"],id:\.self) { Text(Locale.current.localizedString(forIdentifier:$0) ?? $0).tag($0) }
                }
                Slider(value:$speed,in:0.75...1.5,step:0.05) { Text("Speaking speed") }
                Text(String(format:"Speed %.2f×",speed))
            } header: { Text("Speech output") } footer: { Text("Automatic detects each response sentence. English uses Kokoro when it is fast enough, with Apple as fallback. Chinese can use your private PC when enabled below. Select Cantonese explicitly: written Chinese alone cannot reliably identify the spoken dialect.") }
            Section {
                Toggle("CosyVoice3 for Mandarin & Cantonese",isOn:$pcEnabled).onChange(of:pcEnabled) { _,value in PCSpeechConnection.enabled=value }
                TextField("Private HTTPS speech endpoint",text:$pcEndpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                SecureField("API key · blank keeps saved key",text:$pcKey)
                Button(checkingPC ? "Checking…" : "Save & check connection") {
                    checkingPC=true
                    Task { @MainActor in
                        defer { checkingPC=false }
                        do {
                            PCSpeechConnection.endpoint=pcEndpoint.trimmingCharacters(in:.whitespacesAndNewlines)
                            try PCSpeechConnection.saveKey(pcKey);pcKey=""
                            try await PCSpeechConnection.check();pcStatus="CosyVoice3 RL is ready."
                        } catch { pcStatus=error.localizedDescription }
                    }
                }.disabled(checkingPC)
                if !pcStatus.isEmpty { Text(pcStatus).font(.footnote) }
            } header: { Text("Private PC voice") } footer: { Text("Requires your PC and private connection. Chinese response text is sent to this endpoint for speech; unavailable or slow service falls back to an Apple voice. The existing private recognition key is used if no speech key is saved. Other languages keep their iPhone voices.") }
            Section("English Kokoro voice") {
                Picker("Voice",selection:$voice) {
                    Text("Heart · American female").tag("af_heart")
                    Text("Bella · American female").tag("af_bella")
                    Text("Adam · American male").tag("am_adam")
                    Text("Michael · American male").tag("am_michael")
                }
            }
            Section("Apple voice") {
                Picker("Voice",selection:$appleVoice) {
                    Text("Automatic for detected language").tag("")
                    ForEach(AVSpeechSynthesisVoice.speechVoices().sorted { $0.language < $1.language },id:\.identifier) { Text("\($0.name) · \($0.language)").tag($0.identifier) }
                }
                Text("A chosen Apple voice applies when it matches the detected language. Otherwise the matching system voice is used.").font(.footnote)
            }
            Section("Preview") {
                TextField("Text to speak",text:$preview,axis:.vertical)
                Button("Play preview") { narrator.stop();narrator.append(preview,finished:true);status=narrator.status }
                Button("Stop",role:.destructive) { narrator.stop();status=narrator.status }
                Text(status).font(.footnote)
            }
            Section { Text("Kokoro model is bundled. CPU inference avoids background GPU restrictions; speed and battery use depend on your device. Apple voices remain available if Kokoro cannot generate speech.").font(.footnote) }
        }.navigationTitle("Voice & Language")
            .onDisappear { narrator.stop() }
            .onReceive(Timer.publish(every:1,on:.main,in:.common).autoconnect()) { _ in status=narrator.status }
    }
}

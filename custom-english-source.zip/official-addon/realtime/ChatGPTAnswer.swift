import Foundation
import UIKit
import AVFAudio
import Combine

@available(iOS 26.0, *)
@MainActor final class VoiceSearchState: ObservableObject {
    static let shared = VoiceSearchState()
    @Published var enabled = UserDefaults.standard.object(forKey: "TurboRealtime.voiceWebSearch") as? Bool ?? true {
        didSet { UserDefaults.standard.set(enabled, forKey: "TurboRealtime.voiceWebSearch") }
    }
    @Published var answer = ""
    @Published var sources: [WebSource] = []
    @Published var status = "No recent ChatGPT voice answer"
    @Published var events: [String] = []
    private var observers: [NSObjectProtocol] = []
    private var test: ChatGPTAnswer?
    private var turn = UUID()
    init() {
        for name in [UIApplication.didEnterBackgroundNotification, UIApplication.didBecomeActiveNotification,
                     AVAudioSession.routeChangeNotification, AVAudioSession.interruptionNotification] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                let kind = name == UIApplication.didEnterBackgroundNotification ? "Phone locked or app backgrounded" :
                    name == UIApplication.didBecomeActiveNotification ? "App foregrounded" :
                    name == AVAudioSession.interruptionNotification ? "Audio interrupted/resumed" : "Audio route changed"
                let reason = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? NSNumber)?.stringValue
                Task { @MainActor [weak self] in self?.record(kind + (reason.map { " (reason \($0))" } ?? "")) }
            })
        }
    }
    func record(_ event: String) {
        let bluetooth = AVAudioSession.sharedInstance().currentRoute.outputs.contains { [.bluetoothA2DP, .bluetoothHFP, .bluetoothLE].contains($0.portType) }
        events.append("\(Date().formatted(date: .omitted, time: .standard)) · \(event) · Bluetooth audio \(bluetooth ? "present" : "absent")")
        events = Array(events.suffix(30))
    }
    func begin() -> UUID { turn = UUID(); answer = ""; sources = []; status = "Connecting"; record("ChatGPT answer started"); return turn }
    func set(_ id: UUID, text: String? = nil, sources: [WebSource]? = nil, status: String? = nil) {
        guard id == turn else { return }
        if let text { answer = text }; if let sources { self.sources = sources }; if let status { self.status = status }
    }
    func testSearch() {
        test?.cancel()
        test = ChatGPTAnswer(question: "Search the web for the latest news from NASA. Give one short update with its publication date and cite your source.", history: [], requireSearch: true) { _, _, _ in }
    }
    func clear() { test?.cancel(); test = nil; turn = UUID(); answer = ""; sources = []; events = []; status = "Cleared" }
}

@available(iOS 26.0, *)
@MainActor private final class VoiceBackgroundTask {
    private var identifier: UIBackgroundTaskIdentifier = .invalid
    func begin(expiration: @escaping @MainActor () -> Void) {
        identifier = UIApplication.shared.beginBackgroundTask(withName: "Nova voice answer") { [weak self] in
            self?.end(); expiration()
        }
    }
    func end() {
        guard identifier != .invalid else { return }
        let ending = identifier; identifier = .invalid
        UIApplication.shared.endBackgroundTask(ending)
    }
}

@available(iOS 26.0, *)
@MainActor final class ChatGPTAnswer: NSObject {
    private var task: Task<Void, Never>?
    private let background = VoiceBackgroundTask()
    init(question: String, history: [[String: String]], requireSearch: Bool = false, update: @escaping (String, Bool, String?) -> Void) {
        super.init()
        let state = VoiceSearchState.shared, turn = state.begin(), background = background
        let search = state.enabled || requireSearch
        let replyLanguage=ConversationLanguageState.observe(question)
        background.begin { [weak self] in
            self?.cancel()
            let message = "iOS ended this answer's background time. Unlock RayNeo AI and ask again."
            state.set(turn, status: message); state.record("Background time expired")
            update("", true, message)
        }
        task = Task { @MainActor in
            defer { background.end() }
            do {
                let account = ChatGPTAccount.shared
                guard account.isSignedIn else { throw RealtimeError("Open Assistant > ChatGPT account and sign in first.") }
                guard let model = account.selectedModel, !model.isEmpty else { throw RealtimeError("Choose a model under ChatGPT account first.") }
                let token = try await account.accessToken()
                try Task.checkCancellation()
                var searched = false
                let text = try await CueService().streamChatGPT(body: ChatGPTAnswerBody.make(model: model, question: question, history: history, liveSearch: search, requireSearch: requireSearch,replyLanguage:replyLanguage), bearer: token, limit: 24000, evidence: { sources, usedSearch in
                    searched = usedSearch
                    state.set(turn, sources: sources, status: usedSearch ? "Searching / answering with web evidence" : "Answering")
                }) { text in
                    guard !Task.isCancelled else { return }; state.set(turn, text: text); update(text, false, nil)
                }
                try Task.checkCancellation()
                if requireSearch && !searched { throw RealtimeError("No completed web search was returned. Check the selected model and account's search availability.") }
                state.set(turn, text: text, status: searched ? "Completed with web search — sources below" : "Completed without web search")
                state.record("ChatGPT answer completed"); update(text, true, nil)
            } catch is CancellationError { }
            catch { if !Task.isCancelled {
                let message = (error as? RealtimeError)?.message ?? "ChatGPT could not finish this answer. Check the account and connection."
                state.set(turn, status: message); state.record("ChatGPT answer failed")
                update("", true, message)
            } }
        }
    }
    @objc func cancel() { task?.cancel(); task = nil; background.end() }
    deinit { task?.cancel(); let lease = background; Task { @MainActor in lease.end() } }
}

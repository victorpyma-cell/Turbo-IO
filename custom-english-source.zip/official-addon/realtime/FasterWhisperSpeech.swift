import Foundation
import Security

enum WhisperConnection {
    static var endpoint: String {
        get { UserDefaults.standard.string(forKey:"NovaWhisperEndpoint") ?? "" }
        set { UserDefaults.standard.set(newValue,forKey:"NovaWhisperEndpoint") }
    }
    private static let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"TurboIO.PrivateWhisper",kSecAttrAccount as String:"api-key"]
    static var key: String {
        get { var q=query; q[kSecReturnData as String]=true; var result:CFTypeRef?; guard SecItemCopyMatching(q as CFDictionary,&result)==errSecSuccess, let data=result as? Data else { return "" }; return String(data:data,encoding:.utf8) ?? "" }
    }
    static func saveKey(_ value:String) throws {
        guard !value.isEmpty else { return }
        var q=query; q[kSecValueData as String]=Data(value.utf8);q[kSecAttrAccessible as String]=kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemDelete(query as CFDictionary)
        guard SecItemAdd(q as CFDictionary,nil)==errSecSuccess else { throw RealtimeError("Could not save the recognition key in Keychain.") }
    }
    static func request(_ body:[String:Any]) throws -> URLRequest {
        guard let url=URL(string:endpoint),url.scheme=="https",url.host != nil,url.user==nil,url.password==nil,!key.isEmpty else { throw RealtimeError("Configure the private PC HTTPS endpoint and API key first.") }
        var request=URLRequest(url:url,timeoutInterval:20)
        request.httpMethod="POST";request.setValue("application/json",forHTTPHeaderField:"Content-Type");request.setValue("Bearer "+key,forHTTPHeaderField:"Authorization")
        request.httpBody=try JSONSerialization.data(withJSONObject:body);return request
    }
    static func check() async throws {
        let (_,response)=try await URLSession.shared.data(for:request(["check":true]))
        guard (response as? HTTPURLResponse)?.statusCode==200 else { throw RealtimeError("Private recognition server rejected the connection. Check the endpoint and API key.") }
    }
}

@MainActor final class FasterWhisperSpeech {
    var onText: ((TranscriptPiece)->Void)?
    var onFailure: ((String)->Void)?
    private var pending=Data(),start=0.0,processed=0.0
    private var task:Task<Void,Never>?,epoch=0,language="en"
    func prepare(language:String) async throws { self.language=String(SpeechLocalePolicy.key(language).split(separator:"-").first ?? "en"); try await WhisperConnection.check() }
    func offer(_ bytes:Data) {
        pending.append(bytes)
        guard pending.count <= 32000*12 else { stop(); onFailure?("PC recognition fell behind. Restart or choose on-device recognition."); return }
        drain()
    }
    private func drain() {
        guard task==nil,pending.count>=96000 else { return }
        let count=min(pending.count,32000*6),audio=Data(pending.prefix(count));pending.removeFirst(count)
        let stamp=epoch,begin=start,end=start+Double(count)/32000;start=end
        task=Task { [weak self] in
            do {
                let request=try WhisperConnection.request(["audio":audio.base64EncodedString(),"language":language])
                let (data,response)=try await URLSession.shared.data(for:request)
                guard !Task.isCancelled, let self,self.epoch==stamp else { return }
                guard (response as? HTTPURLResponse)?.statusCode==200,let json=try JSONSerialization.jsonObject(with:data) as? [String:Any],let text=json["text"] as? String else { throw RealtimeError("Private PC transcription failed. Check the server.") }
                self.processed=end
                if !text.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { self.onText?(TranscriptPiece(start:begin,end:end,text:text,final:true)) }
                self.task=nil;self.drain()
            } catch {
                guard let self,self.epoch==stamp,!Task.isCancelled else { return }
                self.stop();self.onFailure?(error.localizedDescription)
            }
        }
    }
    func stop() { epoch+=1;task?.cancel();task=nil;pending.removeAll();start=0;processed=0 }
}
